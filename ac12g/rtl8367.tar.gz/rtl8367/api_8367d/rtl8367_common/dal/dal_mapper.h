/*
 * Copyright (C) 2011 Realtek Semiconductor Corp.
 * All Rights Reserved.
 *
 * This program is the proprietary software of Realtek Semiconductor
 * Corporation and/or its licensors, and only be used, duplicated,
 * modified or distributed under the authorized license from Realtek.
 *
 * ANY USE OF THE SOFTWARE OTHER THAN AS AUTHORIZED UNDER
 * THIS LICENSE OR COPYRIGHT LAW IS PROHIBITED.
 * Purpose : Mapper Layer is used to seperate different kind of software or hardware platform
 *
 * Feature : Just dispatch information to Multiplex layer
 *
 */
#ifndef __DAL_MAPPER_H__
#define __DAL_MAPPER_H__

/*
 * Include Files
 */
#include "rtk_types.h"
#include "rtk_error.h"
#include "rtk_switch.h"
#include "led.h"
#include "oam.h"
#include "cpu.h"
#include "stat.h"
#include "l2.h"
#include "interrupt.h"
#include "acl.h"
#include "mirror.h"
#include "port.h"
#include "trap.h"
#include "igmp.h"
#include "storm.h"
#include "rate.h"
#include "i2c.h"
#include "ptp.h"
#include "qos.h"
#include "vlan.h"
#include "dot1x.h"
#include "svlan.h"
#include "rldp.h"
#include "trunk.h"
#include "leaky.h"
/* GPIO causes conflicts with kernel headers, not used in mapper */
/* #include "gpio.h" */

/*
 * Symbol Definition
 */

/*
 * Data Declaration
 */

typedef struct dal_mapper_s {

    /* switch */
    rtk_api_ret_t   (*switch_init)(void);

    /* cpu */
    rtk_api_ret_t (*cpu_enable_set)(rtk_enable_t);
    rtk_api_ret_t (*cpu_enable_get)(rtk_enable_t *);
    rtk_api_ret_t (*cpu_tagPort_set)(rtk_port_t, rtk_cpu_insert_t);
    rtk_api_ret_t (*cpu_tagPort_get)(rtk_port_t *, rtk_cpu_insert_t *);
    rtk_api_ret_t (*cpu_awarePort_set)(rtk_portmask_t *);
    rtk_api_ret_t (*cpu_awarePort_get)(rtk_portmask_t *);
    rtk_api_ret_t (*cpu_tagPosition_set)(rtk_cpu_position_t);
    rtk_api_ret_t (*cpu_tagPosition_get)(rtk_cpu_position_t *);
    rtk_api_ret_t (*cpu_tagLength_set)(rtk_cpu_tag_length_t);
    rtk_api_ret_t (*cpu_tagLength_get)(rtk_cpu_tag_length_t *);
    rtk_api_ret_t (*cpu_acceptLength_set)(rtk_cpu_rx_length_t);
    rtk_api_ret_t (*cpu_acceptLength_get)(rtk_cpu_rx_length_t *);
    rtk_api_ret_t (*cpu_priRemap_set)(rtk_pri_t, rtk_pri_t);
    rtk_api_ret_t (*cpu_priRemap_get)(rtk_pri_t, rtk_pri_t *);

    /* stat */
    rtk_api_ret_t (*stat_global_reset)(void);
    rtk_api_ret_t (*stat_port_reset)(rtk_port_t);
    rtk_api_ret_t (*stat_port_get)(rtk_port_t, rtk_stat_port_type_t, rtk_stat_counter_t *);
    rtk_api_ret_t (*l2_addr_next_get)(rtk_l2_read_method_t, rtk_port_t, rtk_uint32 *, rtk_l2_ucastAddr_t *);
    rtk_api_ret_t (*l2_addr_del)(rtk_mac_t *, rtk_l2_ucastAddr_t *);
    rtk_api_ret_t (*l2_ipMcastAddr_next_get)(rtk_uint32 *, rtk_l2_ipMcastAddr_t *);
    rtk_api_ret_t (*l2_ipMcastAddr_del)(rtk_l2_ipMcastAddr_t *);

    /* interrupt */
    rtk_api_ret_t (*int_polarity_set)(rtk_int_polarity_t);
    rtk_api_ret_t (*int_polarity_get)(rtk_int_polarity_t *);
    rtk_api_ret_t (*int_control_set)(rtk_int_type_t, rtk_enable_t);
    rtk_api_ret_t (*int_control_get)(rtk_int_type_t, rtk_enable_t *);
    rtk_api_ret_t (*int_status_set)(rtk_int_status_t *);
    rtk_api_ret_t (*int_status_get)(rtk_int_status_t *);
    rtk_api_ret_t (*int_advanceInfo_get)(rtk_int_advType_t, rtk_int_info_t *);

    /* acl */
    rtk_api_ret_t (*filter_igrAcl_init)(void);
    rtk_api_ret_t (*filter_igrAcl_field_add)(rtk_filter_cfg_t *, rtk_filter_field_t *);
	rtk_api_ret_t (*filter_igrAcl_cfg_add)(rtk_filter_id_t, rtk_filter_cfg_t *, rtk_filter_action_t *, rtk_filter_number_t *);
	rtk_api_ret_t (*filter_igrAcl_cfg_del)(rtk_filter_id_t);
    rtk_api_ret_t (*port_macForceLinkExt_set)(rtk_port_t, rtk_mode_ext_t, rtk_port_mac_ability_t *);
    rtk_api_ret_t (*port_phyEnableAll_set)(rtk_enable_t);
    rtk_api_ret_t (*igmp_init)(void);
    rtk_api_ret_t (*igmp_state_set)(rtk_enable_t);
    rtk_api_ret_t (*igmp_static_router_port_set)(rtk_portmask_t *);
    rtk_api_ret_t (*rate_shareMeter_set)(rtk_meter_id_t, rtk_meter_type_t, rtk_rate_t, rtk_enable_t);
	rtk_api_ret_t (*rate_shareMeterBucket_set)(rtk_meter_id_t, rtk_uint32);
	rtk_api_ret_t (*rate_egrQueueBwCtrlEnable_set)(rtk_port_t, rtk_qid_t, rtk_enable_t);
	rtk_api_ret_t (*rate_egrQueueBwCtrlRate_set)(rtk_port_t, rtk_qid_t, rtk_meter_id_t);
    rtk_api_ret_t (*qos_init)(rtk_queue_num_t);
    rtk_api_ret_t (*qos_priSel_set)(rtk_qos_priDecTbl_t, rtk_priority_select_t *);
    rtk_api_ret_t (*qos_priMap_set)(rtk_queue_num_t, rtk_qos_pri2queue_t *);
    rtk_api_ret_t (*qos_schedulingQueue_set)(rtk_port_t, rtk_qos_queue_weights_t *);
    rtk_api_ret_t (*qos_portPriSelIndex_set)(rtk_port_t, rtk_qos_priDecTbl_t);
    rtk_api_ret_t (*vlan_init)(void);
    rtk_api_ret_t (*vlan_set)(rtk_vlan_t, rtk_vlan_cfg_t *);
    rtk_api_ret_t (*vlan_portPvid_set)(rtk_port_t, rtk_vlan_t, rtk_pri_t);
	/*ASIC*/
	rtk_api_ret_t (*asic_setAsicReg)(rtk_uint32, rtk_uint32);
	rtk_api_ret_t (*asic_getAsicReg)(rtk_uint32, rtk_uint32 *);
	rtk_api_ret_t (*asic_setAsicPHYOCPReg)(rtk_uint32, rtk_uint32, rtk_uint32);
	rtk_api_ret_t (*asic_getAsicPHYOCPReg)(rtk_uint32, rtk_uint32, rtk_uint32 *);
	rtk_api_ret_t (*asic_setAsicPHYReg)(rtk_uint32, rtk_uint32, rtk_uint32);
	rtk_api_ret_t (*asic_getAsicPHYReg)(rtk_uint32, rtk_uint32, rtk_uint32 *);

	/*smi*/
	rtk_api_ret_t (*smi_read)(rtk_uint32, rtk_uint32 *);
	rtk_api_ret_t (*smi_write)(rtk_uint32, rtk_uint32);

} dal_mapper_t;


#endif /* __DAL_MAPPER_H __ */
