#ifndef _RTL8367C_TYPES_H_
#define _RTL8367C_TYPES_H_

//#include "stdio.h"

typedef unsigned long long		rtk_uint64;
typedef long long				rtk_int64;
typedef unsigned int			rtk_uint32;
typedef int						rtk_int32;
typedef unsigned short			rtk_uint16;
typedef short					rtk_int16;
typedef unsigned char			rtk_uint8;
typedef char					rtk_int8;

#define CONST_T     const

#define RTK_TOTAL_NUM_OF_WORD_FOR_1BIT_PORT_LIST    1

#define RTK_MAX_NUM_OF_PORT                         8
#define RTK_PORT_ID_MAX                             (RTK_MAX_NUM_OF_PORT-1)
#define RTK_PHY_ID_MAX                              (RTK_MAX_NUM_OF_PORT-4)
#define RTK_MAX_PORT_MASK                           0xFF

#define RTK_WHOLE_SYSTEM                            0xFF

#define RTL8367C_EXTNO       3

#define    RTL8367C_REG_REG_TO_ECO4    0x1d41
#define    RTL8367C_REG_CHIP_RESET    0x1322
#define    RTL8367C_DW8051_RST_OFFSET    4
#define    RTL8367C_REG_MISCELLANEOUS_CONFIGURE0    0x130c
#define    RTL8367C_DW8051_EN_OFFSET    5
#define    RTL8367C_REG_DW8051_RDY    0x1336
#define    RTL8367C_ACS_IROM_ENABLE_OFFSET    1
#define    RTL8367C_IROM_MSB_OFFSET    2
#define    RTL8367C_REG_EXT0_RGMXF    0x1306
#define    RTL8367C_EXT0_RGTX_INV_OFFSET    6
#define    RTL8367C_REG_EXT1_RGMXF    0x1307
#define    RTL8367C_EXT1_RGTX_INV_OFFSET    6
#define    RTL8367C_REG_EXT_TXC_DLY    0x13f9
#define    RTL8367C_EXT1_GMII_TX_DELAY_MASK    0x7000
#define    RTL8367C_EXT0_GMII_TX_DELAY_MASK    0xE00
#define    RTL8367C_REG_BYPASS_LINE_RATE    0x03f7
#define    RTL8367C_REG_SDS_INDACS_DATA    0x6602
#define    RTL8367C_REG_SDS_INDACS_ADR    0x6601
#define    RTL8367C_REG_SDS_INDACS_CMD    0x6600
#define    RTL8367C_REG_SDS_MISC    0x1d11
#define    RTL8367C_CFG_SGMII_FDUP_OFFSET    10
#define    RTL8367C_CFG_SGMII_SPD_MASK    0x180
#define    RTL8367C_CFG_SGMII_LINK_OFFSET    9
#define    RTL8367C_CFG_SGMII_TXFC_OFFSET    13
#define    RTL8367C_CFG_SGMII_RXFC_OFFSET    14
#define    RTL8367C_REG_DIGITAL_INTERFACE0_FORCE    0x1310
#define    RTL8367C_REG_DIGITAL_INTERFACE2_FORCE    0x13c4
#define    RTL8367C_CFG_MAC8_SEL_SGMII_OFFSET    6
#define    RTL8367C_REG_DIGITAL_INTERFACE_SELECT    0x1305
#define    RTL8367C_SELECT_GMII_0_MASK    0xF
#define    RTL8367C_SELECT_GMII_2_MASK    0xF
#define    RTL8367C_REG_PARA_LED_IO_EN3    0x1b33
#define    RTL8367C_REG_PARA_LED_IO_EN1    0x1b24
#define    RTL8367C_REG_PARA_LED_IO_EN2    0x1b25
#define    RTL8367C_CFG_MAC8_SEL_HSGMII_OFFSET    11
#define    RTL8367C_SELECT_GMII_1_OFFSET    4

typedef struct rtk_portmask_s
{
    rtk_uint32  bits[RTK_TOTAL_NUM_OF_WORD_FOR_1BIT_PORT_LIST];
} rtk_portmask_t;

typedef enum rtk_enable_e
{
    DISABLED = 0,
    ENABLED,
    RTK_ENABLE_END
} rtk_enable_t;

#ifndef ETHER_ADDR_LEN
#define ETHER_ADDR_LEN		6
#endif

/* ethernet address type */
typedef struct  rtk_mac_s
{
    rtk_uint8 octet[ETHER_ADDR_LEN];
} rtk_mac_t;

typedef rtk_uint32  rtk_pri_t;      /* priority vlaue */
typedef rtk_uint32  rtk_qid_t;      /* queue id type */
typedef rtk_uint32  rtk_data_t;
typedef rtk_uint32  rtk_dscp_t;     /* dscp vlaue */
typedef rtk_uint32  rtk_fid_t;      /* filter id type */
typedef rtk_uint32  rtk_vlan_t;     /* vlan id type */
typedef rtk_uint32  rtk_mac_cnt_t;  /* MAC count type  */
typedef rtk_uint32  rtk_meter_id_t; /* meter id type  */
typedef rtk_uint32  rtk_rate_t;     /* rate type  */

typedef enum rtk_port_e
{
    UTP_PORT0 = 0,
    UTP_PORT1,
    UTP_PORT2,
    UTP_PORT3,
    UTP_PORT4,
    UTP_PORT5,
    UTP_PORT6,
    UTP_PORT7,

    EXT_PORT0 = 16,
    EXT_PORT1,
    EXT_PORT2,

    UNDEFINE_PORT = 30,
    RTK_PORT_MAX = 31
} rtk_port_t;

typedef enum rtk_mode_ext_e
{
    MODE_EXT_DISABLE = 0,
    MODE_EXT_RGMII,
    MODE_EXT_MII_MAC,
    MODE_EXT_MII_PHY,
    MODE_EXT_TMII_MAC,
    MODE_EXT_TMII_PHY,
    MODE_EXT_GMII,
    MODE_EXT_RMII_MAC,
    MODE_EXT_RMII_PHY,
    MODE_EXT_SGMII,
    MODE_EXT_HSGMII,
    MODE_EXT_1000X_100FX,
    MODE_EXT_1000X,
    MODE_EXT_100FX,
    MODE_EXT_RGMII_2,
    MODE_EXT_MII_MAC_2,
    MODE_EXT_MII_PHY_2,
    MODE_EXT_TMII_MAC_2,
    MODE_EXT_TMII_PHY_2,
    MODE_EXT_RMII_MAC_2,
    MODE_EXT_RMII_PHY_2,
    MODE_EXT_END
} rtk_mode_ext_t;

enum EXTMODE
{
    EXT_DISABLE = 0,
    EXT_RGMII,
    EXT_MII_MAC,
    EXT_MII_PHY,
    EXT_TMII_MAC,
    EXT_TMII_PHY,
    EXT_GMII,
    EXT_RMII_MAC,
    EXT_RMII_PHY,
    EXT_SGMII,
    EXT_HSGMII,
    EXT_1000X_100FX,
    EXT_1000X,
    EXT_100FX,
    EXT_RGMII_2,
    EXT_MII_MAC_2,
    EXT_MII_PHY_2,
    EXT_TMII_MAC_2,
    EXT_TMII_PHY_2,
    EXT_RMII_MAC_2,
    EXT_RMII_PHY_2,
    EXT_END
};


enum LINKMODE
{
    MAC_NORMAL = 0,
    MAC_FORCE,
};

typedef enum rtk_port_speed_e
{
    PORT_SPEED_10M = 0,
    PORT_SPEED_100M,
    PORT_SPEED_1000M,
    PORT_SPEED_500M,
    PORT_SPEED_2500M,
    PORT_SPEED_END
} rtk_port_speed_t;

typedef enum rtk_port_duplex_e
{
    PORT_HALF_DUPLEX = 0,
    PORT_FULL_DUPLEX,
    PORT_DUPLEX_END
} rtk_port_duplex_t;

typedef enum rtk_port_linkStatus_e
{
    PORT_LINKDOWN = 0,
    PORT_LINKUP,
    PORT_LINKSTATUS_END
} rtk_port_linkStatus_t;

typedef struct  rtl8367c_port_ability_s{
    rtk_uint16 forcemode;
    rtk_uint16 mstfault;
    rtk_uint16 mstmode;
    rtk_uint16 nway;
    rtk_uint16 txpause;
    rtk_uint16 rxpause;
    rtk_uint16 link;
    rtk_uint16 duplex;
    rtk_uint16 speed;
}rtl8367c_port_ability_t;

typedef struct  rtk_port_mac_ability_s
{
    rtk_uint32 forcemode;
    rtk_uint32 speed;
    rtk_uint32 duplex;
    rtk_uint32 link;
    rtk_uint32 nway;
    rtk_uint32 txpause;
    rtk_uint32 rxpause;
}rtk_port_mac_ability_t;


#ifndef _RTL_TYPES_H

#if 0
typedef unsigned long long		uint64;
typedef long long				int64;
typedef unsigned int			uint32;
typedef int						int32;
typedef unsigned short			uint16;
typedef short					int16;
typedef unsigned char			uint8;
typedef char					int8;
#endif

typedef rtk_uint32          		ipaddr_t;
typedef rtk_uint32					memaddr;

#ifndef ETHER_ADDR_LEN
#define ETHER_ADDR_LEN		6
#endif

typedef struct ether_addr_s {
	rtk_uint8 octet[ETHER_ADDR_LEN];
} ether_addr_t;

#ifdef __KERNEL__
#define rtlglue_printf printk
#else
#define rtlglue_printf printf
#endif
#define PRINT			rtlglue_printf
#endif /*_RTL_TYPES_H*/

/* type abstraction */
#ifdef EMBEDDED_SUPPORT

typedef rtk_int16                   rtk_api_ret_t;
typedef rtk_int16                   ret_t;
typedef rtk_uint32                  rtk_u_long;

#else

typedef rtk_int32                   rtk_api_ret_t;
typedef rtk_int32                   ret_t;
typedef rtk_uint64                  rtk_u_long_t;

#endif

#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define CONST			const
#endif /* _RTL8367C_TYPES_H_ */

