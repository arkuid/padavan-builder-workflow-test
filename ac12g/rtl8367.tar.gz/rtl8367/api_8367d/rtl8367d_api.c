
/*  Copyright(c) 2009-2013 Shenzhen TP-LINK Technologies Co.Ltd.
 *
 * file		rtl8367s_api.c
 * brief		
 * details	
 *
 * author		Huang Qingjia
 * version	
 * date		2017.06.14
 *
 * history 	\arg	
 */
 #include <linux/time.h>
#include <linux/delay.h>
#include <linux/kernel.h>
#include <linux/inetdevice.h>
#ifdef CONFIG_X_TP_VLAN
#include <linux/skbuff.h>
#endif

#include "rtl8367d_api.h"
#include "rtl8367_common/rtk_types.h"
#include "rtl8367_common/rtk_error.h"
#include "rtl8367_common/rtk_switch.h"
#include "rtl8367_common/port.h"
#include "rtl8367_common/vlan.h"
#include "rtl8367_common/acl.h"
#include "rtl8367_common/l2.h"
#include "rtl8367_common/cpu.h"
#include "rtl8367_common/igmp.h"
#include "rtl8367_common/mirror.h"
#include "rtl8367_common/dal/dal_mgmt.h"
#include "rtl8367_common/chip.h"
#include "rtl8367_common/dal/rtl8367c/rtl8367c_reg.h"
#include "rtl8367_common/dal/rtl8367d/rtl8367d_reg.h"
#include "rtl8367_common/dal/rtl8367d/dal_rtl8367d_port.h"
#include "rtl8367_common/dal/rtl8367c/rtl8367c_asicdrv_vlan.h"

// Global allocate big buffer prevent limitation 8k overflow of single thread.
char mcast_ret_buf[1024*4];
char ucast_ret_buf[1024*4];
char eth_port_ret_buf[1024*4];
char eth_vlan_ret_buf[1024];
/*#include "command.h"*/

/**************************************************************************************************/
/*                                           EXTERN_PROTOTYPES                                    */
/**************************************************************************************************/

extern int mii_mgr_read(u32 phy_addr, u32 phy_register, u32 *read_data);
extern int mii_mgr_write(u32 phy_addr, u32 phy_register, u32 write_data);

extern rtk_api_ret_t (*ipMcastRuleSet_pointer)(struct rtl8367IpMcastRule ipMcastRule, ipMcastRuleType ruleType);
	
/**************************************************************************************************/
/*                                           LOCAL_PROTOTYPES                                     */
/**************************************************************************************************/

#define printf	printk
#define RTL8367_ERROR(fmt, args...) printk("\033[1m[ %s ] %03d: "fmt"\033[0m", __FUNCTION__, __LINE__, ##args)
#define RTL8367_DEBUG(fmt, args...) //printk("\033[4m[ %s ] %03d: "fmt"\033[0m", __FUNCTION__, __LINE__, ##args)

#define LAN_VLAN_ID 	3
#define WAN_VLAN_ID 	2
#define LAN_VLAN_PVID	LAN_VLAN_ID
#define WAN_VLAN_PVID	WAN_VLAN_ID

#define RALINK_ETH_SW_BASE 0xB0110000

switch_chip_t g_switch_chip = CHIP_END;


#define MDC_MDIO_PHY_ID     29  /* MDIO used PHY 29, not 0 !!!! */

#define MDC_MDIO_CTRL0_REG          31
#define MDC_MDIO_START_REG          29
#define MDC_MDIO_CTRL1_REG          21
#define MDC_MDIO_ADDRESS_REG        23
#define MDC_MDIO_DATA_WRITE_REG     24
#define MDC_MDIO_DATA_READ_REG      25
#define MDC_MDIO_PREAMBLE_LEN       32

#define MDC_MDIO_START_OP          0xFFFF
#define MDC_MDIO_ADDR_OP           0x000E
#define MDC_MDIO_READ_OP           0x0001
#define MDC_MDIO_WRITE_OP          0x0003
#if 0

#define RTL8367C_REGBITLENGTH               16
#define RTL8367C_REGDATAMAX                 0xFFFF

#define RTL8367C_PORTNO                     11
#define RTL8367C_PORTIDMAX                  (RTL8367C_PORTNO-1)
#define RTL8367C_PORTMASK                   0x7FF

#define RTL8367C_QOS_GRANULARTY_MAX         0x7FFFF
#define RTL8367C_QOS_GRANULARTY_LSB_MASK    0xFFFF
#define RTL8367C_QOS_GRANULARTY_LSB_OFFSET  0
#define RTL8367C_QOS_GRANULARTY_MSB_MASK    0x70000
#define RTL8367C_QOS_GRANULARTY_MSB_OFFSET  16

#define RTL8367C_QOS_RATE_INPUT_MAX         (0x1FFFF * 8)
#define RTL8367C_QOS_RATE_INPUT_MAX_HSG     (0x7FFFF * 8)
#define RTL8367C_QOS_RATE_INPUT_MIN         8

#define RTL8367C_QOS_PPS_INPUT_MAX          (0x7FFFF)
#define RTL8367C_QOS_PPS_INPUT_MIN          1

#define    RTL8367C_REG_GPHY_OCP_MSB_0    0x1d15
#define    RTL8367C_CFG_CPU_OCPADR_MSB_MASK    0xFC0

#define    RTL8367C_REG_PORT0_EEECFG    0x0018
#define    RTL8367C_PORT0_EEECFG_EEE_100M_OFFSET    11
#define    RTL8367C_PORT0_EEECFG_EEE_GIGA_500M_OFFSET    10
#define    RTL8367C_PORT0_EEECFG_EEE_TX_OFFSET    9
#define    RTL8367C_PORT0_EEECFG_EEE_RX_OFFSET    8

#define    RTL8367C_REG_UTP_FIB_DET    0x13eb

#define RTL8367C_PHY_REGNOMAX		    0x1F
#define	RTL8367C_PHY_BASE   	        0x2000
#define	RTL8367C_PHY_OFFSET	            5

#define    RTL8367C_REG_PHY_AD    0x130f
#define    RTL8367C_PDNPHY_OFFSET    5

#define    RTL8367C_REG_PORT0_EGRESSBW_CTRL0    0x038c
#define    RTL8367C_PORT_EGRESSBW_LSB_BASE                        RTL8367C_REG_PORT0_EGRESSBW_CTRL0
#define    RTL8367C_PORT_EGRESSBW_LSB_REG(port)                    (RTL8367C_PORT_EGRESSBW_LSB_BASE + (port << 1))

#define    RTL8367C_REG_PORT0_EGRESSBW_CTRL1    0x038d
#define    RTL8367C_PORT_EGRESSBW_MSB_BASE                        RTL8367C_REG_PORT0_EGRESSBW_CTRL1
#define    RTL8367C_PORT_EGRESSBW_MSB_REG(port)                    (RTL8367C_PORT_EGRESSBW_MSB_BASE + (port << 1))

#define    RTL8367C_PORT6_EGRESSBW_CTRL1_MASK    0x7

#define    RTL8367C_REG_INGRESSBW_PORT0_RATE_CTRL0    0x000f
#define    RTL8367C_INGRESSBW_PORT_RATE_LSB_BASE                RTL8367C_REG_INGRESSBW_PORT0_RATE_CTRL0
#define    RTL8367C_INGRESSBW_PORT_RATE_LSB_REG(port)            (RTL8367C_INGRESSBW_PORT_RATE_LSB_BASE + (port << 5))

#define    RTL8367C_REG_MAC0_FORCE_SELECT    0x1312

#define    RTL8367C_INGRESSBW_PORT0_RATE_CTRL1_INGRESSBW_RATE16_MASK    0x7
#define    RTL8367C_PORT0_MISC_CFG_INGRESSBW_IFG_OFFSET    10
#define    RTL8367C_PORT0_MISC_CFG_INGRESSBW_FLOWCTRL_OFFSET    11

#define    RTL8367C_REG_PORT0_MISC_CFG    0x000e
#define    RTL8367C_PORT0_MISC_CFG_VLAN_EGRESS_MODE_MASK    0x30
#define    RTL8367C_PORT0_MISC_CFG_DOT1Q_REMARK_ENABLE_OFFSET    12
#define    RTL8367C_PORT0_MISC_CFG_DOT1Q_REMARK_ENABLE_MASK    0x1000
#define    RTL8367C_PORT0_MISC_CFG_INGRESSBW_FLOWCTRL_OFFSET    11

#define    RTL8367C_PORT0_MISC_CFG_SMALL_TAG_IPG_OFFSET    15
#define    RTL8367C_PORT0_MISC_CFG_SMALL_TAG_IPG_MASK    0x8000
#define    RTL8367C_PORT0_MISC_CFG_TX_ITFSP_MODE_OFFSET    14
#define    RTL8367C_PORT0_MISC_CFG_TX_ITFSP_MODE_MASK    0x4000
#define    RTL8367C_PORT0_MISC_CFG_FLOWCTRL_INDEP_OFFSET    13
#define    RTL8367C_PORT0_MISC_CFG_FLOWCTRL_INDEP_MASK    0x2000

#define    RTL8367C_PORT_MISC_CFG_BASE                            RTL8367C_REG_PORT0_MISC_CFG
#define    RTL8367C_PORT_MISC_CFG_REG(port)                        (RTL8367C_PORT_MISC_CFG_BASE + (port << 5))
#define    RTL8367C_1QREMARK_ENABLE_OFFSET                         RTL8367C_PORT0_MISC_CFG_DOT1Q_REMARK_ENABLE_OFFSET
#define    RTL8367C_1QREMARK_ENABLE_MASK                        RTL8367C_PORT0_MISC_CFG_DOT1Q_REMARK_ENABLE_MASK

#define    RTL8367C_REG_SCHEDULE_WFQ_CTRL    0x0300
#define    RTL8367C_SCHEDULE_WFQ_CTRL_OFFSET    0
#define    RTL8367C_SCHEDULE_WFQ_CTRL_MASK    0x1

#define    RTL8367C_REG_LUT_CFG    0x0a30
#define    RTL8367C_LUT_IPMC_LOOKUP_OP_OFFSET    3
#define    RTL8367C_LUT_IPMC_HASH_OFFSET    4

#define    RTL8367C_REG_LUT_CFG2    0x0a3a
#define    RTL8367C_LUT_IPMC_VID_HASH_OFFSET    0

#define    RTL8367C_REG_MIRROR_CTRL2    0x09DA
#define    RTL8367C_MIRROR_TX_ISOLATION_LEAKY_OFFSET    2

#define RTL8367C_RMAMAX                     0x2F
#define    RTL8367C_REG_RMA_CTRL00    0x0800
#define    RTL8367C_TRAP_PRIORITY_MASK    0x38

#define    RTL8367C_REG_MAX_LENGTH_LIMINT_IPG    0x1200
#define    RTL8367C_MAX_LENTH_CTRL_MASK    0x6000

#define    RTL8367C_REG_MAX_LEN_RX_TX    0x0884
#define    RTL8367C_MAX_LEN_RX_TX_MASK    0x3

#define    RTL8367C_REG_ACL_ACCESS_MODE    0x06EB
#define    RTL8367C_ACL_ACCESS_MODE_MASK    0x1

#define    RTL8367C_REG_PORT_SECURITY_CTRL    0x08c8
#define    RTL8367C_PORT_SECURIT_CTRL_REG                        RTL8367C_REG_PORT_SECURITY_CTRL
#define    RTL8367C_UNKNOWN_UNICAST_DA_BEHAVE_MASK    0xC0

#define    RTL8367C_REG_IO_MISC_FUNC    0x1d32
#define    RTL8367C_INT_EN_OFFSET    1

#define    RTL8367C_REG_DIGITAL_INTERFACE_SELECT_1    0x13c3
#define    RTL8367C_REG_DIGITAL_INTERFACE2_FORCE    0x13c4
#define    RTL8367C_REG_BYPASS_LINE_RATE    0x03f7

#define PHY_CONTROL_REG                             0

#define RTL8367_PORT0_STATUS_REG	0x1352

#define RTL8367C_VIDMAX                     0xFFF
#define RTL8367C_EVIDMAX                    0x1FFF
#define RTL8367C_CVIDXNO                    32
#define RTL8367C_CVIDXMAX                   (RTL8367C_CVIDXNO-1)

#define RTL8367C_EFIDMAX                    0x7
#define RTL8367C_FIDMAX                     0xF

#define RTL8367C_METERNO                    64
#define RTL8367C_METERMAX                   (RTL8367C_METERNO-1)
#define RTL8367C_METERBUCKETSIZEMAX         0xFFFF

#define RTL8367C_PRIMAX                     7
#define RTL8367C_DSCPMAX    				63

#define    RTL8367C_REG_VLAN_MEMBER_CONFIGURATION0_CTRL0    0x0728
#define    RTL8367C_VLAN_MEMBER_CONFIGURATION_BASE                RTL8367C_REG_VLAN_MEMBER_CONFIGURATION0_CTRL0


#define    RTL8367C_REG_TABLE_WRITE_DATA0    0x0510
#define    RTL8367C_TABLE_ACCESS_WRDATA_BASE                    RTL8367C_REG_TABLE_WRITE_DATA0
#define    RTL8367C_TABLE_ACCESS_WRDATA_REG(index)                (RTL8367C_TABLE_ACCESS_WRDATA_BASE + index)


#define    RTL8367C_REG_TABLE_ACCESS_ADDR    0x0501
#define    RTL8367C_TABLE_ACCESS_ADDR_REG                        RTL8367C_REG_TABLE_ACCESS_ADDR

#define    RTL8367C_REG_TABLE_ACCESS_CTRL    0x0500
#define    RTL8367C_TABLE_ACCESS_CTRL_SPA_OFFSET    8
#define    RTL8367C_TABLE_ACCESS_CTRL_SPA_MASK    0xF00
#define    RTL8367C_ACCESS_METHOD_OFFSET    4
#define    RTL8367C_ACCESS_METHOD_MASK    0x70
#define    RTL8367C_COMMAND_TYPE_MASK    0x8
#define    RTL8367C_TABLE_TYPE_MASK    0x7
#define    RTL8367C_TABLE_ACCESS_CTRL_REG                        RTL8367C_REG_TABLE_ACCESS_CTRL


#define    RTL8367C_REG_TABLE_LUT_ADDR    0x0502
#define    RTL8367C_HIT_STATUS_OFFSET    12
#define    RTL8367C_HIT_STATUS_MASK    0x1000
#define    RTL8367C_TABLE_LUT_ADDR_BUSY_FLAG_OFFSET    13
#define    RTL8367C_TABLE_ACCESS_STATUS_REG                        RTL8367C_REG_TABLE_LUT_ADDR

#define    RTL8367C_REG_TABLE_READ_DATA0    0x0520
#define    RTL8367C_TABLE_ACCESS_RDDATA_BASE                    RTL8367C_REG_TABLE_READ_DATA0
#define    RTL8367C_TABLE_ACCESS_RDDATA_REG(index)                (RTL8367C_TABLE_ACCESS_RDDATA_BASE + index)

#define RTL8367C_TABLE_ACCESS_REG_DATA(op, target)    ((op << 3) | target)

#define    RTL8367C_REG_VLAN_PVID_CTRL0    0x0700
#define    RTL8367C_PORT0_VIDX_MASK    0x1F

#define    RTL8367C_VLAN_PVID_CTRL_BASE                            RTL8367C_REG_VLAN_PVID_CTRL0
#define    RTL8367C_VLAN_PVID_CTRL_REG(port)                    (RTL8367C_VLAN_PVID_CTRL_BASE + (port >> 1))

#define    RTL8367C_PORT_VIDX_OFFSET(port)                        ((port &1)<<3)
#define    RTL8367C_PORT_VIDX_MASK(port)                        (RTL8367C_PORT0_VIDX_MASK << RTL8367C_PORT_VIDX_OFFSET(port))

#define    RTL8367C_REG_VLAN_PORTBASED_PRIORITY_CTRL0    0x0851
#define    RTL8367C_VLAN_PORTBASED_PRIORITY_BASE                RTL8367C_REG_VLAN_PORTBASED_PRIORITY_CTRL0
#define    RTL8367C_VLAN_PORTBASED_PRIORITY_REG(port)            (RTL8367C_VLAN_PORTBASED_PRIORITY_BASE + (port >> 2))
#define    RTL8367C_VLAN_PORTBASED_PRIORITY_OFFSET(port)        ((port & 0x3) << 2)
#define    RTL8367C_VLAN_PORTBASED_PRIORITY_MASK(port)            (0x7 << RTL8367C_VLAN_PORTBASED_PRIORITY_OFFSET(port))

#define	RTL8367C_VLAN_BUSY_CHECK_NO		(10)
#define RTL8367C_VLAN_MBRCFG_LEN    (4)
#define RTL8367C_VLAN_4KTABLE_LEN   (3)


#define    RTL8367C_VLAN_EGRESS_MDOE_MASK                        RTL8367C_PORT0_MISC_CFG_VLAN_EGRESS_MODE_MASK

#define    RTL8367C_REG_VLAN_INGRESS    0x07a9
#define    RTL8367C_VLAN_INGRESS_REG                            RTL8367C_REG_VLAN_INGRESS

#define    RTL8367C_REG_VLAN_CTRL    0x07a8
#define    RTL8367C_VLAN_CTRL_OFFSET    0

#define    RTL8367C_REG_IGMP_STATIC_ROUTER_PORT    0x1c04
#define    RTL8367C_IGMP_STATIC_ROUTER_PORT_OFFSET    0
#define    RTL8367C_IGMP_STATIC_ROUTER_PORT_MASK    0x7FF

#define    RTL8367C_REG_IGMP_PORT0_CONTROL    0x1c05
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_QUERY_OFFSET    14
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_QUERY_MASK    0x4000
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_REPORT_OFFSET    13
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_REPORT_MASK    0x2000
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_LEAVE_OFFSET    12
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_LEAVE_MASK    0x1000
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_MRP_OFFSET    11
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_MRP_MASK    0x800
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_MC_DATA_OFFSET    10
#define    RTL8367C_IGMP_PORT0_CONTROL_ALLOW_MC_DATA_MASK    0x400
#define    RTL8367C_IGMP_PORT0_CONTROL_MLDv2_OP_OFFSET    8
#define    RTL8367C_IGMP_PORT0_CONTROL_MLDv2_OP_MASK    0x300
#define    RTL8367C_IGMP_PORT0_CONTROL_MLDv1_OP_OFFSET    6
#define    RTL8367C_IGMP_PORT0_CONTROL_MLDv1_OP_MASK    0xC0
#define    RTL8367C_IGMP_PORT0_CONTROL_IGMPV3_OP_OFFSET    4
#define    RTL8367C_IGMP_PORT0_CONTROL_IGMPV3_OP_MASK    0x30
#define    RTL8367C_IGMP_PORT0_CONTROL_IGMPV2_OP_OFFSET    2
#define    RTL8367C_IGMP_PORT0_CONTROL_IGMPV2_OP_MASK    0xC
#define    RTL8367C_IGMP_PORT0_CONTROL_IGMPV1_OP_OFFSET    0
#define    RTL8367C_IGMP_PORT0_CONTROL_IGMPV1_OP_MASK    0x3

#define    RTL8367C_REG_IGMP_PORT8_CONTROL    0x1cb0
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_QUERY_OFFSET    14
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_QUERY_MASK    0x4000
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_REPORT_OFFSET    13
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_REPORT_MASK    0x2000
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_LEAVE_OFFSET    12
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_LEAVE_MASK    0x1000
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_MRP_OFFSET    11
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_MRP_MASK    0x800
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_MC_DATA_OFFSET    10
#define    RTL8367C_IGMP_PORT8_CONTROL_ALLOW_MC_DATA_MASK    0x400
#define    RTL8367C_IGMP_PORT8_CONTROL_MLDv2_OP_OFFSET    8
#define    RTL8367C_IGMP_PORT8_CONTROL_MLDv2_OP_MASK    0x300
#define    RTL8367C_IGMP_PORT8_CONTROL_MLDv1_OP_OFFSET    6
#define    RTL8367C_IGMP_PORT8_CONTROL_MLDv1_OP_MASK    0xC0
#define    RTL8367C_IGMP_PORT8_CONTROL_IGMPV3_OP_OFFSET    4
#define    RTL8367C_IGMP_PORT8_CONTROL_IGMPV3_OP_MASK    0x30
#define    RTL8367C_IGMP_PORT8_CONTROL_IGMPV2_OP_OFFSET    2
#define    RTL8367C_IGMP_PORT8_CONTROL_IGMPV2_OP_MASK    0xC
#define    RTL8367C_IGMP_PORT8_CONTROL_IGMPV1_OP_OFFSET    0
#define    RTL8367C_IGMP_PORT8_CONTROL_IGMPV1_OP_MASK    0x3

#define    RTL8367C_REG_IGMP_MLD_CFG0    0x1c00
#define    RTL8367C_FAST_LEAVE_EN_OFFSET    3
#define    RTL8367C_FAST_LEAVE_EN_MASK    0x8
#define    RTL8367C_IGMP_MLD_EN_OFFSET    0
#define    RTL8367C_IGMP_MLD_EN_MASK    0x1
	
#define    RTL8367C_REG_IGMP_MLD_CFG3    0x1c15
#define    RTL8367C_REPORT_LEAVE_FORWARD_OFFSET    0
#define    RTL8367C_REPORT_LEAVE_FORWARD_MASK    0x3

#define    RTL8367C_REG_IGMP_MLD_CFG4    0x1c16
#define    RTL8367C_IGMP_MLD_CFG4_OFFSET    0
#define    RTL8367C_IGMP_MLD_CFG4_MASK    0x7FF

#define    RTL8367C_REG_QOS_PORT_QUEUE_NUMBER_CTRL0    0x0900

#define    RTL8367C_REG_QOS_1Q_PRIORITY_TO_QID_CTRL0    0x0904
#define    RTL8367C_QOS_1Q_PRIORITY_TO_QID_CTRL0_PRIORITY0_TO_QID_MASK    0x7

#define    RTL8367C_REG_QOS_INTERNAL_PRIORITY_DECISION_CTRL0    0x087b
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_CTRL0_QOS_PORT_WEIGHT_MASK    0xFF

#define    RTL8367C_REG_QOS_INTERNAL_PRIORITY_DECISION2_CTRL0    0x0885
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_CTRL0_QOS_PORT_WEIGHT_MASK    0xFF

#define    RTL8367C_REG_QOS_PORTBASED_PRIORITY_CTRL0    0x0877
#define    RTL8367C_REG_QOS_PORTBASED_PRIORITY_CTRL2    0x087a

#define    RTL8367C_REG_SWITCH_CTRL0    0x120c
#define    RTL8367C_REMARKING_DSCP_ENABLE_OFFSET    8

#define    RTL8367C_REG_QOS_1Q_PRIORITY_REMAPPING_CTRL0    0x0865

#define    RTL8367C_REG_QOS_1Q_REMARK_CTRL0    0x1211

#define    RTL8367C_REG_QOS_DSCP_REMARK_CTRL0    0x120d

#define    RTL8367C_REG_QOS_DSCP_TO_PRIORITY_CTRL0    0x0867

#define    RTL8367C_REG_SCHEDULE_QUEUE_TYPE_CTRL0    0x0302

#define    RTL8367C_REG_SCHEDULE_PORT0_QUEUE0_WFQ_WEIGHT    0x030c

#define    RTL8367C_REG_QOS_INTERNAL_PRIORITY_DECISION_IDX    0x0889

#define    RTL8367C_REG_ACL_RULE_TEMPLATE0_CTRL0    0x0600

#define    RTL8367C_REG_FIELD_SELECTOR0    0x12e7
#define    RTL8367C_FIELD_SELECTOR0_FORMAT_OFFSET    8
#define    RTL8367C_FIELD_SELECTOR0_FORMAT_MASK    0x700
#define    RTL8367C_FIELD_SELECTOR0_OFFSET_OFFSET    0
#define    RTL8367C_FIELD_SELECTOR0_OFFSET_MASK    0xFF

#define    RTL8367C_REG_ACL_ENABLE    0x06d5
#define    RTL8367C_REG_ACL_UNMATCH_PERMIT    0x06d6

#define    RTL8367C_REG_ACL_ACTION_CTRL0    0x0614
#define    RTL8367C_REG_ACL_ACTION_CTRL32    0x06F0

#define    RTL8367C_REG_ACL_RESET_CFG    0x06d9
#define    RTL8367C_ACL_RESET_CFG_OFFSET    0
#define    RTL8367C_ACL_RESET_CFG_MASK    0x1

#define    RTL8367C_REG_METER0_RATE_CTRL0    0x1400

#define    RTL8367C_REG_METER0_BUCKET_SIZE    0x1600

#define    RTL8367C_REG_METER32_BUCKET_SIZE    0x1790

#define    RTL8367C_REG_METER_IFG_CTRL0    0x1712

#define    RTL8367C_REG_METER32_RATE_CTRL0    0x1740

#define    RTL8367C_REG_METER_IFG_CTRL2    0x17b4

#define    RTL8367C_REG_METER_MODE_SETTING0    0x1440

#define    RTL8367C_REG_METER_MODE_SETTING2    0x1780

#define RTL8367C_LUT_AGETIMERMAX        (7)
#define RTL8367C_LUT_AGESPEEDMAX        (3)
#define RTL8367C_LUT_LEARNLIMITMAX      (0x1040)
#define RTL8367C_LUT_ADDRMAX            (0x103F)
#define RTL8367C_LUT_IPMCGRP_TABLE_MAX  (0x3F)
#define	RTL8367C_LUT_ENTRY_SIZE			(6)
#define	RTL8367C_LUT_BUSY_CHECK_NO		(10)

#define RTL8367C_LUT_TABLE_SIZE         (6)

#define RTL8367C_ACLRULEFIELDNO			    8

#define RTL8367C_ACLTEMPLATENO				5

#define RTL8367C_FIELDSEL_FORMAT_NUMBER      (16)

#define RTL8367C_QUEUENO                    8
#define RTL8367C_QIDMAX                     (RTL8367C_QUEUENO-1)

#define RTL8367C_QWEIGHTMAX    0x7F

#define    RTL8367C_QOS_PORT_QUEUE_NUMBER_BASE                    RTL8367C_REG_QOS_PORT_QUEUE_NUMBER_CTRL0
#define    RTL8367C_QOS_PORT_QUEUE_NUMBER_REG(port)                (RTL8367C_QOS_PORT_QUEUE_NUMBER_BASE + (port >> 2))
#define    RTL8367C_QOS_PORT_QUEUE_NUMBER_OFFSET(port)            ((port & 0x3) << 2)
#define    RTL8367C_QOS_PORT_QUEUE_NUMBER_MASK(port)            (0x7 << RTL8367C_QOS_PORT_QUEUE_NUMBER_OFFSET(port))

#define    RTL8367C_QOS_1Q_PRIORITY_TO_QID_BASE                    RTL8367C_REG_QOS_1Q_PRIORITY_TO_QID_CTRL0
#define    RTL8367C_QOS_1Q_PRIORITY_TO_QID_REG(index, pri)        (RTL8367C_QOS_1Q_PRIORITY_TO_QID_BASE + (index << 1) + (pri >> 2))
#define    RTL8367C_QOS_1Q_PRIORITY_TO_QID_OFFSET(pri)            ((pri & 0x3) << 2)
#define    RTL8367C_QOS_1Q_PRIORITY_TO_QID_MASK(pri)            (RTL8367C_QOS_1Q_PRIORITY_TO_QID_CTRL0_PRIORITY0_TO_QID_MASK << RTL8367C_QOS_1Q_PRIORITY_TO_QID_OFFSET(pri))

#define    RTL8367C_REG_FLOWCTRL_CTRL0    0x121d
#define    RTL8367C_FLOWCTRL_TYPE_OFFSET    15

#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_BASE            RTL8367C_REG_QOS_INTERNAL_PRIORITY_DECISION_CTRL0
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_REG(src)        (RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_BASE + (src >> 1))
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_OFFSET(src)  ((src & 1) << 3)
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_MASK(src)    (RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_CTRL0_QOS_PORT_WEIGHT_MASK << RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_OFFSET(src))

#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_BASE            RTL8367C_REG_QOS_INTERNAL_PRIORITY_DECISION2_CTRL0
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_REG(src)        (RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_BASE + (src >> 1))
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_OFFSET(src)  ((src & 1) << 3)
#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_MASK(src)    (RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_CTRL0_QOS_PORT_WEIGHT_MASK << RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_OFFSET(src))

#define    RTL8367C_QOS_PORTBASED_PRIORITY_BASE                    RTL8367C_REG_QOS_PORTBASED_PRIORITY_CTRL0
#define    RTL8367C_QOS_PORTBASED_PRIORITY_REG(port)            (RTL8367C_QOS_PORTBASED_PRIORITY_BASE + (port >> 2))
#define    RTL8367C_QOS_PORTBASED_PRIORITY_OFFSET(port)            ((port & 0x3) << 2)
#define    RTL8367C_QOS_PORTBASED_PRIORITY_MASK(port)            (0x7 << RTL8367C_QOS_PORTBASED_PRIORITY_OFFSET(port))

#define    RTL8367C_REMARKING_CTRL_REG                            RTL8367C_REG_SWITCH_CTRL0

#define    RTL8367C_QOS_1Q_PRIORITY_REMAPPING_BASE                RTL8367C_REG_QOS_1Q_PRIORITY_REMAPPING_CTRL0
#define    RTL8367C_QOS_1Q_PRIORITY_REMAPPING_REG(pri)            (RTL8367C_QOS_1Q_PRIORITY_REMAPPING_BASE + (pri >> 2))
#define    RTL8367C_QOS_1Q_PRIORITY_REMAPPING_OFFSET(pri)        ((pri & 0x3) << 2)
#define    RTL8367C_QOS_1Q_PRIORITY_REMAPPING_MASK(pri)            (0x7 << RTL8367C_QOS_1Q_PRIORITY_REMAPPING_OFFSET(pri))

#define    RTL8367C_QOS_1Q_REMARK_BASE                            RTL8367C_REG_QOS_1Q_REMARK_CTRL0
#define    RTL8367C_QOS_1Q_REMARK_REG(pri)                        (RTL8367C_QOS_1Q_REMARK_BASE + (pri >> 2))
#define    RTL8367C_QOS_1Q_REMARK_OFFSET(pri)                    ((pri & 0x3) << 2)
#define    RTL8367C_QOS_1Q_REMARK_MASK(pri)                        (0x7 << RTL8367C_QOS_1Q_REMARK_OFFSET(pri))

#define    RTL8367C_QOS_DSCP_REMARK_BASE                        RTL8367C_REG_QOS_DSCP_REMARK_CTRL0
#define    RTL8367C_QOS_DSCP_REMARK_REG(pri)                    (RTL8367C_QOS_DSCP_REMARK_BASE + (pri >> 1))
#define    RTL8367C_QOS_DSCP_REMARK_OFFSET(pri)                    (((pri) & 0x1) << 3)
#define    RTL8367C_QOS_DSCP_REMARK_MASK(pri)                    (0x3F << RTL8367C_QOS_DSCP_REMARK_OFFSET(pri))

#define    RTL8367C_QOS_DSCP_TO_PRIORITY_BASE                    RTL8367C_REG_QOS_DSCP_TO_PRIORITY_CTRL0
#define    RTL8367C_QOS_DSCP_TO_PRIORITY_REG(dscp)                (RTL8367C_QOS_DSCP_TO_PRIORITY_BASE + (dscp >> 2))
#define    RTL8367C_QOS_DSCP_TO_PRIORITY_OFFSET(dscp)            ((dscp & 0x3) << 2)
#define    RTL8367C_QOS_DSCP_TO_PRIORITY_MASK(dscp)                (0x7 << RTL8367C_QOS_DSCP_TO_PRIORITY_OFFSET(dscp))

#define    RTL8367C_SCHEDULE_QUEUE_TYPE_BASE                    RTL8367C_REG_SCHEDULE_QUEUE_TYPE_CTRL0
#define    RTL8367C_SCHEDULE_QUEUE_TYPE_REG(port)                (RTL8367C_SCHEDULE_QUEUE_TYPE_BASE + (port >> 1))
#define    RTL8367C_SCHEDULE_QUEUE_TYPE_OFFSET(port, queue)        (((port & 0x1) << 3) + queue)
#define    RTL8367C_SCHEDULE_QUEUE_TYPE_MASK(port, queue)         RTL8367C_SCHEDULE_QUEUE_TYPE_OFFSET(port, queue)

#define    RTL8367C_SCHEDULE_PORT_QUEUE_WFQ_WEIGHT_BASE            RTL8367C_REG_SCHEDULE_PORT0_QUEUE0_WFQ_WEIGHT
#define    RTL8367C_SCHEDULE_PORT_QUEUE_WFQ_WEIGHT_REG(port, queue)    (RTL8367C_SCHEDULE_PORT_QUEUE_WFQ_WEIGHT_BASE + (port << 3) + queue)

#define    RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_IDX_CTRL            RTL8367C_REG_QOS_INTERNAL_PRIORITY_DECISION_IDX

#define    RTL8367C_ACL_RULE_TEMPLATE_CTRL_BASE                    RTL8367C_REG_ACL_RULE_TEMPLATE0_CTRL0
#define    RTL8367C_ACL_RULE_TEMPLATE_CTRL_REG(template)        (RTL8367C_ACL_RULE_TEMPLATE_CTRL_BASE + template * 0x4)

#define    RTL8367C_FIELD_SELECTOR_REG(index)                    (RTL8367C_REG_FIELD_SELECTOR0 + index)
#define    RTL8367C_FIELD_SELECTOR_FORMAT_OFFSET                RTL8367C_FIELD_SELECTOR0_FORMAT_OFFSET
#define    RTL8367C_FIELD_SELECTOR_FORMAT_MASK                    RTL8367C_FIELD_SELECTOR0_FORMAT_MASK
#define    RTL8367C_FIELD_SELECTOR_OFFSET_OFFSET                  RTL8367C_FIELD_SELECTOR0_OFFSET_OFFSET
#define    RTL8367C_FIELD_SELECTOR_OFFSET_MASK                    RTL8367C_FIELD_SELECTOR0_OFFSET_MASK

#define    RTL8367C_ACL_ENABLE_REG                                RTL8367C_REG_ACL_ENABLE
#define    RTL8367C_ACL_UNMATCH_PERMIT_REG                        RTL8367C_REG_ACL_UNMATCH_PERMIT

#define RTL8367C_ACLRULETBLEN				9
#define RTL8367C_ACLACTTBLEN				4
#define RTL8367C_ACLRULETBADDR(type, rule)	((type << 6) | rule)
#define RTL8367C_ACLRULETBADDR2(type, rule)	((type << 5) | (rule + 64))

#define    RTL8367C_ACL_ACTION_CTRL_BASE                        RTL8367C_REG_ACL_ACTION_CTRL0
#define    RTL8367C_ACL_ACTION_CTRL_REG(rule)                   (RTL8367C_ACL_ACTION_CTRL_BASE + (rule >> 1))
#define    RTL8367C_ACL_ACTION_CTRL2_BASE                        RTL8367C_REG_ACL_ACTION_CTRL32
#define    RTL8367C_ACL_ACTION_CTRL2_REG(rule)                  (RTL8367C_ACL_ACTION_CTRL2_BASE + ((rule-64) >> 1))

#define    RTL8367C_METER_RATE_BASE                                RTL8367C_REG_METER0_RATE_CTRL0
#define    RTL8367C_METER_RATE_REG(meter)                        ((meter << 1) + RTL8367C_METER_RATE_BASE)

#define    RTL8367C_METER_BUCKET_SIZE_BASE                        RTL8367C_REG_METER0_BUCKET_SIZE
#define    RTL8367C_METER_BUCKET_SIZE_REG(meter)                (RTL8367C_METER_BUCKET_SIZE_BASE + meter)

#define    RTL8367C_METER_IFG_CTRL_BASE                            RTL8367C_REG_METER_IFG_CTRL0
#define    RTL8367C_METER_IFG_CTRL_REG(meter)                    (RTL8367C_METER_IFG_CTRL_BASE + (meter >> 4))
#define    RTL8367C_METER_IFG_OFFSET(meter)                        (meter & 0xF)
#define    RTL8367C_METER_IFG_MASK(meter)                        (1 << RTL8367C_METER_IFG_OFFSET(meter))

#define RTL8367C_MAX_LOG_CNT_NUM                (32)

#define RTK_CHK_INIT_STATE()                                \
    do                                                      \
    {                                                       \
        if(rtk_switch_initialState_get() != INIT_COMPLETED) \
        {                                                   \
            return RT_ERR_NOT_INIT;                         \
        }                                                   \
    }while(0)

#define RTK_CHK_PORT_VALID(__port__)                            \
    do                                                          \
    {                                                           \
        if(rtk_switch_logicalPortCheck(__port__) != RT_ERR_OK)  \
        {                                                       \
            return RT_ERR_PORT_ID;                              \
        }                                                       \
    }while(0)

#define RTK_CHK_PORT_IS_UTP(__port__)                           \
    do                                                          \
    {                                                           \
        if(rtk_switch_isUtpPort(__port__) != RT_ERR_OK)         \
        {                                                       \
            return RT_ERR_PORT_ID;                              \
        }                                                       \
    }while(0)


#define RTK_CHK_PORTMASK_VALID(__portmask__)                        \
    do                                                              \
    {                                                               \
        if(rtk_switch_isPortMaskValid(__portmask__) != RT_ERR_OK)   \
        {                                                           \
            return RT_ERR_PORT_MASK;                                  \
        }                                                           \
    }while(0)

#define RTK_MAX_METER_ID            (rtk_switch_maxMeterId_get())

#define UNDEFINE_PHY_PORT   (0xFF)
#define RTK_SWITCH_PORT_NUM (32)

#define MAXPKTLEN_CFG_ID_MAX (1)

#define RTK_SWITCH_MAX_PKTLEN (0x3FFF)

#define RTK_PORTMASK_IS_PORT_SET(__portmask__, __port__)    \
	(((__portmask__).bits[0] & (0x00000001 << __port__)) ? 1 : 0)

#define RTK_PORTMASK_ALLPORT_SET(__portmask__)              (rtk_switch_logPortMask_get(&__portmask__))

#define RTK_PORTMASK_CLEAR(__portmask__)                    ((__portmask__).bits[0] = 0)

#define RTK_SCAN_ALL_LOG_PORT(__port__)     \
	for(__port__ = 0; __port__ < RTK_SWITCH_PORT_NUM; __port__++) \
		if( rtk_switch_logicalPortCheck(__port__) == RT_ERR_OK)

#define RTK_PORTMASK_PORT_SET(__portmask__, __port__)     \
	((__portmask__).bits[0] |= (0x00000001 << __port__))
	
#define RTK_PORTMASK_SCAN(__portmask__, __port__)   \
	for(__port__ = 0; __port__ < RTK_SWITCH_PORT_NUM; __port__++)  \
		if(RTK_PORTMASK_IS_PORT_SET(__portmask__, __port__))

#define RTK_PHY_PORTMASK_ALL                                (rtk_switch_phyPortMask_get())

#define RTK_SCAN_ALL_PHY_PORTMASK(__port__)                \
	for(__port__ = 0; __port__ < RTK_SWITCH_PORT_NUM; __port__++)  \
		if( (rtk_switch_phyPortMask_get() & (0x00000001 << __port__)))

#define RTK_MAX_NUM_OF_LEARN_LIMIT                  (rtk_switch_maxLutAddrNumber_get())

#define RTK_MAC_ADDR_LEN                            6
#define RTK_MAX_LUT_ADDRESS                         (RTK_MAX_NUM_OF_LEARN_LIMIT)
#define RTK_MAX_LUT_ADDR_ID                         (RTK_MAX_LUT_ADDRESS - 1)

#define QOS_WEIGHT_MAX                              127

#define RTK_MAX_NUM_OF_PRIORITY                     8
#define RTK_MAX_NUM_OF_QUEUE                        8

#define RTK_PRIMAX                                             7
#define RTK_QIDMAX                                             7
#define RTK_DSCPMAX                                         63

#define RTK_DOT_1AS_TIMESTAMP_UNIT_IN_WORD_LENGTH   3UL
#define RTK_IPV6_ADDR_WORD_LENGTH                   4UL

#define RTK_FILTER_FIELD_USED_MAX					8

#define RTL8367C_ACLRULENO					96

#define RTL8367C_ACLRULEMAX					(RTL8367C_ACLRULENO-1)

#define RTL8367C_ACL_ACT_TABLE_LEN          (4)

#define    RTL8367C_ACL_OP_NOT_OFFSET(rule)                        (6 + ((rule & 0x1) << 3))
#define    RTL8367C_ACL_OP_NOT_MASK(rule)                        (1 << RTL8367C_ACL_OP_NOT_OFFSET(rule))
#define    RTL8367C_ACL_OP_ACTION_OFFSET(rule)                    ((rule & 0x1) << 3)
#define    RTL8367C_ACL_OP_ACTION_MASK(rule)                    (0x3F << RTL8367C_ACL_OP_ACTION_OFFSET(rule))
#endif

#ifdef CONFIG_X_TP_VLAN
/* vlan operation interface, add by wanghao  */
#define VLAN_SET				280
#define VLAN_SET_MAX			VLAN_SET
/* add end  */
#endif

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
#define FIBER2_AUTO_INIT_SIZE 1947
rtk_uint8 Fiber2_Auto[FIBER2_AUTO_INIT_SIZE] = {
0x02,0x05,0x9D,0xE4,0xF5,0xA8,
0xD2,0xAF,0x22,0x00,0x00,0x02,0x06,0xD1,
0xC5,0xF0,0xF8,0xA3,0xE0,0x28,0xF0,0xC5,
0xF0,0xF8,0xE5,0x82,0x15,0x82,0x70,0x02,
0x15,0x83,0xE0,0x38,0xF0,0x22,0x75,0xF0,
0x08,0x75,0x82,0x00,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xCD,0x33,0xCD,0xCC,0x33,0xCC,
0xC5,0x82,0x33,0xC5,0x82,0x9B,0xED,0x9A,
0xEC,0x99,0xE5,0x82,0x98,0x40,0x0C,0xF5,
0x82,0xEE,0x9B,0xFE,0xED,0x9A,0xFD,0xEC,
0x99,0xFC,0x0F,0xD5,0xF0,0xD6,0xE4,0xCE,
0xFB,0xE4,0xCD,0xFA,0xE4,0xCC,0xF9,0xA8,
0x82,0x22,0xB8,0x00,0xC1,0xB9,0x00,0x59,
0xBA,0x00,0x2D,0xEC,0x8B,0xF0,0x84,0xCF,
0xCE,0xCD,0xFC,0xE5,0xF0,0xCB,0xF9,0x78,
0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,0xED,
0x33,0xFD,0xEC,0x33,0xFC,0xEB,0x33,0xFB,
0x10,0xD7,0x03,0x99,0x40,0x04,0xEB,0x99,
0xFB,0x0F,0xD8,0xE5,0xE4,0xF9,0xFA,0x22,
0x78,0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,
0xED,0x33,0xFD,0xEC,0x33,0xFC,0xC9,0x33,
0xC9,0x10,0xD7,0x05,0x9B,0xE9,0x9A,0x40,
0x07,0xEC,0x9B,0xFC,0xE9,0x9A,0xF9,0x0F,
0xD8,0xE0,0xE4,0xC9,0xFA,0xE4,0xCC,0xFB,
0x22,0x75,0xF0,0x10,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xED,0x33,0xFD,0xCC,0x33,0xCC,
0xC8,0x33,0xC8,0x10,0xD7,0x07,0x9B,0xEC,
0x9A,0xE8,0x99,0x40,0x0A,0xED,0x9B,0xFD,
0xEC,0x9A,0xFC,0xE8,0x99,0xF8,0x0F,0xD5,
0xF0,0xDA,0xE4,0xCD,0xFB,0xE4,0xCC,0xFA,
0xE4,0xC8,0xF9,0x22,0xEB,0x9F,0xF5,0xF0,
0xEA,0x9E,0x42,0xF0,0xE9,0x9D,0x42,0xF0,
0xE8,0x9C,0x45,0xF0,0x22,0xE0,0xFC,0xA3,
0xE0,0xFD,0xA3,0xE0,0xFE,0xA3,0xE0,0xFF,
0x22,0xE0,0xF8,0xA3,0xE0,0xF9,0xA3,0xE0,
0xFA,0xA3,0xE0,0xFB,0x22,0xEC,0xF0,0xA3,
0xED,0xF0,0xA3,0xEE,0xF0,0xA3,0xEF,0xF0,
0x22,0x7D,0xD7,0x7C,0x04,0x7F,0x02,0x7E,
0x66,0x12,0x07,0x50,0x7D,0x80,0x7C,0x04,
0x7F,0x01,0x7E,0x66,0x12,0x07,0x50,0x7D,
0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,
0x07,0x50,0x7D,0x94,0x7C,0xF9,0x7F,0x02,
0x7E,0x66,0x12,0x07,0x50,0x7D,0x81,0x7C,
0x04,0x7F,0x01,0x7E,0x66,0x12,0x07,0x50,
0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,
0x12,0x07,0x50,0x7D,0xA2,0x7C,0x31,0x7F,
0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,0x82,
0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x07,0x50,0x7D,0x60,0x7C,0x69,
0x7F,0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,
0x83,0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,
0x07,0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,
0x7E,0x66,0x12,0x07,0x50,0x7D,0x28,0x7C,
0x97,0x7F,0x02,0x7E,0x66,0x12,0x07,0x50,
0x7D,0x84,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x07,0x50,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x07,0x50,0x7D,0x85,
0x7C,0x9D,0x7F,0x02,0x7E,0x66,0x12,0x07,
0x50,0x7D,0x23,0x7C,0x04,0x7F,0x01,0x7E,
0x66,0x12,0x07,0x50,0x7D,0xC0,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x07,0x50,0x7D,
0x10,0x7C,0xD8,0x7F,0x02,0x7E,0x66,0x12,
0x07,0x50,0x7D,0x24,0x7C,0x04,0x7F,0x01,
0x7E,0x66,0x12,0x07,0x50,0x7D,0xC0,0x7C,
0x00,0x7F,0x00,0x7E,0x66,0x12,0x07,0x50,
0x7D,0x00,0x7C,0x04,0x7F,0x02,0x7E,0x66,
0x12,0x07,0x50,0x7D,0x2F,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x07,0x50,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,0x07,
0x50,0xE4,0x90,0x06,0x2C,0xF0,0xFD,0x7C,
0x01,0x7F,0x3F,0x7E,0x1D,0x12,0x07,0x50,
0x7D,0x40,0x7C,0x00,0x7F,0x36,0x7E,0x13,
0x12,0x07,0x50,0xE4,0xFF,0xFE,0xFD,0x80,
0x25,0xE4,0x7F,0x20,0x7E,0x4E,0xFD,0xFC,
0x90,0x06,0x24,0x12,0x01,0x0F,0xC3,0x12,
0x00,0xF2,0x50,0x1B,0x90,0x06,0x24,0x12,
0x01,0x03,0xEF,0x24,0x01,0xFF,0xE4,0x3E,
0xFE,0xE4,0x3D,0xFD,0xE4,0x3C,0xFC,0x90,
0x06,0x24,0x12,0x01,0x1B,0x80,0xD2,0xE4,
0xF5,0xA8,0xD2,0xAF,0x12,0x07,0x80,0x7D,
0xFE,0x7C,0x00,0x7F,0xAA,0x7E,0x12,0x12,
0x07,0x50,0x12,0x01,0x27,0x12,0x06,0x29,
0x12,0x07,0x2F,0x12,0x06,0x8F,0x7D,0x41,
0x7C,0x00,0x7F,0x36,0x7E,0x13,0x12,0x07,
0x50,0xE4,0xFF,0xFE,0xFD,0x80,0x25,0xE4,
0x7F,0x20,0x7E,0x4E,0xFD,0xFC,0x90,0x06,
0x24,0x12,0x01,0x0F,0xC3,0x12,0x00,0xF2,
0x50,0x1B,0x90,0x06,0x24,0x12,0x01,0x03,
0xEF,0x24,0x01,0xFF,0xE4,0x3E,0xFE,0xE4,
0x3D,0xFD,0xE4,0x3C,0xFC,0x90,0x06,0x24,
0x12,0x01,0x1B,0x80,0xD2,0xC2,0x00,0xC2,
0x01,0xD2,0xA9,0xD2,0x8C,0x7F,0x01,0x7E,
0x62,0x12,0x07,0x0B,0x7F,0x01,0x7E,0x62,
0x12,0x07,0x0B,0xEF,0x30,0xE2,0x07,0xE4,
0x90,0x06,0x2C,0xF0,0x80,0xE7,0x90,0x06,
0x2C,0xE0,0x70,0x12,0x12,0x04,0xF7,0x90,
0x06,0x2C,0x74,0x01,0xF0,0xE4,0x90,0x06,
0x33,0xF0,0xA3,0xF0,0x80,0xCF,0xC3,0x90,
0x06,0x34,0xE0,0x94,0x62,0x90,0x06,0x33,
0xE0,0x94,0x00,0x40,0xC0,0xE4,0xF0,0xA3,
0xF0,0x12,0x04,0xF7,0x90,0x06,0x2C,0x74,
0x01,0xF0,0x80,0xB1,0x7D,0x03,0x7C,0x00,
0x7F,0x01,0x7E,0x66,0x12,0x07,0x50,0x7D,
0x80,0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,
0x07,0x50,0x7F,0x02,0x7E,0x66,0x12,0x07,
0x0B,0xEF,0x44,0x40,0xFD,0xAC,0x06,0x7F,
0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,0x03,
0x7C,0x00,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x07,0x50,0x7D,0x03,0x7C,0x00,
0x7F,0x01,0x7E,0x66,0x12,0x07,0x50,0x7D,
0x80,0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,
0x07,0x50,0x7F,0x02,0x7E,0x66,0x12,0x07,
0x0B,0xEF,0x54,0xBF,0xFD,0xAC,0x06,0x7F,
0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,0x03,
0x7C,0x00,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x07,0x50,0xE4,0xFD,0xFC,0x7F,
0x01,0x7E,0x66,0x12,0x07,0x50,0x7D,0x80,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x07,
0x50,0x7F,0x02,0x7E,0x66,0x12,0x07,0x0B,
0xEF,0x54,0xFD,0x54,0xFE,0xFD,0xAC,0x06,
0x7F,0x02,0x7E,0x66,0x12,0x07,0x50,0xE4,
0xFD,0xFC,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x07,0x50,0xE4,0xFD,0xFC,0x7F,
0x01,0x7E,0x66,0x12,0x07,0x50,0x7D,0x80,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x07,
0x50,0x7F,0x02,0x7E,0x66,0x12,0x07,0x0B,
0xEF,0x44,0x02,0x44,0x01,0xFD,0xAC,0x06,
0x7F,0x02,0x7E,0x66,0x12,0x07,0x50,0xE4,
0xFD,0xFC,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x02,0x07,0x50,0x75,0x0F,0x80,0x75,
0x0E,0x7E,0x75,0x0D,0xAA,0x75,0x0C,0x83,
0xE4,0xF5,0x10,0x7F,0x36,0x7E,0x13,0x12,
0x07,0x0B,0xEE,0xC4,0xF8,0x54,0xF0,0xC8,
0xEF,0xC4,0x54,0x0F,0x48,0x54,0x07,0xFB,
0x7A,0x00,0xEA,0x70,0x4A,0xEB,0x14,0x60,
0x1C,0x14,0x60,0x27,0x24,0xFE,0x60,0x31,
0x14,0x60,0x3C,0x24,0x05,0x70,0x38,0x75,
0x0B,0x00,0x75,0x0A,0xC2,0x75,0x09,0xEB,
0x75,0x08,0x0B,0x80,0x36,0x75,0x0B,0x40,
0x75,0x0A,0x59,0x75,0x09,0x73,0x75,0x08,
0x07,0x80,0x28,0x75,0x0B,0x00,0x75,0x0A,
0xE1,0x75,0x09,0xF5,0x75,0x08,0x05,0x80,
0x1A,0x75,0x0B,0xA0,0x75,0x0A,0xAC,0x75,
0x09,0xB9,0x75,0x08,0x03,0x80,0x0C,0x75,
0x0B,0x00,0x75,0x0A,0x62,0x75,0x09,0x3D,
0x75,0x08,0x01,0x75,0x89,0x11,0xE4,0x7B,
0x60,0x7A,0x09,0xF9,0xF8,0xAF,0x0B,0xAE,
0x0A,0xAD,0x09,0xAC,0x08,0x12,0x00,0x60,
0xAA,0x06,0xAB,0x07,0xC3,0xE4,0x9B,0xFB,
0xE4,0x9A,0xFA,0x78,0x17,0xF6,0xAF,0x03,
0xEF,0x08,0xF6,0x18,0xE6,0xF5,0x8C,0x08,
0xE6,0xF5,0x8A,0x74,0x0D,0x2B,0xFB,0xE4,
0x3A,0x18,0xF6,0xAF,0x03,0xEF,0x08,0xF6,
0x75,0x88,0x10,0x53,0x8E,0xC7,0xD2,0xA9,
0x22,0x7D,0x02,0x7C,0x00,0x7F,0x4A,0x7E,
0x13,0x12,0x07,0x50,0x7D,0x46,0x7C,0x71,
0x7F,0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,
0x03,0x7C,0x00,0x7F,0x01,0x7E,0x66,0x12,
0x07,0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,
0x7E,0x66,0x12,0x07,0x50,0xE4,0xFF,0xFE,
0x0F,0xBF,0x00,0x01,0x0E,0xEF,0x64,0x64,
0x4E,0x70,0xF5,0x7D,0x04,0x7C,0x00,0x7F,
0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,0x00,
0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x07,0x50,0xE4,0xFD,0xFC,0x7F,
0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,0x00,
0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x07,0x50,0xE4,0xFD,0xFC,0x7F,
0x4A,0x7E,0x13,0x12,0x07,0x50,0x7D,0x06,
0x7C,0x71,0x7F,0x02,0x7E,0x66,0x12,0x07,
0x50,0x7D,0x03,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x07,0x50,0x7D,0xC0,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x02,0x07,0x50,0x78,
0x7F,0xE4,0xF6,0xD8,0xFD,0x75,0x81,0x3C,
0x02,0x05,0xE4,0x02,0x02,0x2F,0xE4,0x93,
0xA3,0xF8,0xE4,0x93,0xA3,0x40,0x03,0xF6,
0x80,0x01,0xF2,0x08,0xDF,0xF4,0x80,0x29,
0xE4,0x93,0xA3,0xF8,0x54,0x07,0x24,0x0C,
0xC8,0xC3,0x33,0xC4,0x54,0x0F,0x44,0x20,
0xC8,0x83,0x40,0x04,0xF4,0x56,0x80,0x01,
0x46,0xF6,0xDF,0xE4,0x80,0x0B,0x01,0x02,
0x04,0x08,0x10,0x20,0x40,0x80,0x90,0x07,
0x8C,0xE4,0x7E,0x01,0x93,0x60,0xBC,0xA3,
0xFF,0x54,0x3F,0x30,0xE5,0x09,0x54,0x1F,
0xFE,0xE4,0x93,0xA3,0x60,0x01,0x0E,0xCF,
0x54,0xC0,0x25,0xE0,0x60,0xA8,0x40,0xB8,
0xE4,0x93,0xA3,0xFA,0xE4,0x93,0xA3,0xF8,
0xE4,0x93,0xA3,0xC8,0xC5,0x82,0xC8,0xCA,
0xC5,0x83,0xCA,0xF0,0xA3,0xC8,0xC5,0x82,
0xC8,0xCA,0xC5,0x83,0xCA,0xDF,0xE9,0xDE,
0xE7,0x80,0xBE,0x7D,0xD7,0x7C,0x04,0x7F,
0x02,0x7E,0x66,0x12,0x07,0x50,0x7D,0x80,
0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,0x07,
0x50,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x07,0x50,0x7D,0x40,0x7C,0x17,
0x7F,0x11,0x7E,0x1D,0x12,0x07,0x50,0x7F,
0x41,0x7E,0x1D,0x12,0x07,0x0B,0xEF,0x44,
0x20,0x44,0x80,0xFD,0xAC,0x06,0x7F,0x41,
0x7E,0x1D,0x12,0x07,0x50,0x7D,0xBB,0x7C,
0x15,0x7F,0xEB,0x7E,0x13,0x12,0x07,0x50,
0x7D,0x07,0x7C,0x00,0x7F,0xE7,0x7E,0x13,
0x12,0x07,0x50,0x7D,0x40,0x7C,0x11,0x7F,
0x00,0x7E,0x62,0x12,0x07,0x50,0x02,0x03,
0x32,0x7D,0x04,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x07,0x50,0x7D,0x80,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x07,0x50,0x7F,
0x02,0x7E,0x66,0x12,0x07,0x0B,0xEF,0x44,
0x02,0x44,0x04,0xFD,0xAC,0x06,0x7F,0x02,
0x7E,0x66,0x12,0x07,0x50,0x7D,0x04,0x7C,
0x00,0x7F,0x01,0x7E,0x66,0x12,0x07,0x50,
0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,
0x02,0x07,0x50,0xC0,0xE0,0xC0,0xF0,0xC0,
0x83,0xC0,0x82,0xC0,0xD0,0x75,0xD0,0x00,
0xC0,0x00,0x78,0x17,0xE6,0xF5,0x8C,0x78,
0x18,0xE6,0xF5,0x8A,0x90,0x06,0x31,0xE4,
0x75,0xF0,0x01,0x12,0x00,0x0E,0x90,0x06,
0x33,0xE4,0x75,0xF0,0x01,0x12,0x00,0x0E,
0xD0,0x00,0xD0,0xD0,0xD0,0x82,0xD0,0x83,
0xD0,0xF0,0xD0,0xE0,0x32,0xC2,0xAF,0xAD,
0x07,0xAC,0x06,0x8C,0xA2,0x8D,0xA3,0x75,
0xA0,0x01,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0xAE,0xA1,0xBE,
0x00,0xF0,0xAE,0xA6,0xAF,0xA7,0xD2,0xAF,
0x22,0x7D,0x20,0x7C,0x0F,0x7F,0x02,0x7E,
0x66,0x12,0x07,0x50,0x7D,0x01,0x7C,0x00,
0x7F,0x01,0x7E,0x66,0x12,0x07,0x50,0x7D,
0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,
0x07,0x50,0xC2,0xAF,0xAB,0x07,0xAA,0x06,
0x8A,0xA2,0x8B,0xA3,0x8C,0xA4,0x8D,0xA5,
0x75,0xA0,0x03,0x00,0x00,0x00,0xAA,0xA1,
0xBA,0x00,0xF8,0xD2,0xAF,0x22,0x7F,0x0C,
0x7E,0x13,0x12,0x07,0x0B,0xEF,0x44,0x50,
0xFD,0xAC,0x06,0x7F,0x0C,0x7E,0x13,0x02,
0x07,0x50,0x12,0x07,0x6C,0x12,0x07,0x97,
0x12,0x04,0x32,0x02,0x00,0x03,0x42,0x06,
0x33,0x00,0x00,0x42,0x06,0x31,0x00,0x00,
0x00,0xE4,0xF5,0x8E,0x22};

#define FIBER2_1G_INIT_SIZE 1842
rtk_uint8 Fiber2_1G[FIBER2_1G_INIT_SIZE] = {
0x02,0x05,0x97,0xE4,0xF5,0xA8,
0xD2,0xAF,0x22,0x00,0x00,0x02,0x06,0x89,
0xC5,0xF0,0xF8,0xA3,0xE0,0x28,0xF0,0xC5,
0xF0,0xF8,0xE5,0x82,0x15,0x82,0x70,0x02,
0x15,0x83,0xE0,0x38,0xF0,0x22,0x75,0xF0,
0x08,0x75,0x82,0x00,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xCD,0x33,0xCD,0xCC,0x33,0xCC,
0xC5,0x82,0x33,0xC5,0x82,0x9B,0xED,0x9A,
0xEC,0x99,0xE5,0x82,0x98,0x40,0x0C,0xF5,
0x82,0xEE,0x9B,0xFE,0xED,0x9A,0xFD,0xEC,
0x99,0xFC,0x0F,0xD5,0xF0,0xD6,0xE4,0xCE,
0xFB,0xE4,0xCD,0xFA,0xE4,0xCC,0xF9,0xA8,
0x82,0x22,0xB8,0x00,0xC1,0xB9,0x00,0x59,
0xBA,0x00,0x2D,0xEC,0x8B,0xF0,0x84,0xCF,
0xCE,0xCD,0xFC,0xE5,0xF0,0xCB,0xF9,0x78,
0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,0xED,
0x33,0xFD,0xEC,0x33,0xFC,0xEB,0x33,0xFB,
0x10,0xD7,0x03,0x99,0x40,0x04,0xEB,0x99,
0xFB,0x0F,0xD8,0xE5,0xE4,0xF9,0xFA,0x22,
0x78,0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,
0xED,0x33,0xFD,0xEC,0x33,0xFC,0xC9,0x33,
0xC9,0x10,0xD7,0x05,0x9B,0xE9,0x9A,0x40,
0x07,0xEC,0x9B,0xFC,0xE9,0x9A,0xF9,0x0F,
0xD8,0xE0,0xE4,0xC9,0xFA,0xE4,0xCC,0xFB,
0x22,0x75,0xF0,0x10,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xED,0x33,0xFD,0xCC,0x33,0xCC,
0xC8,0x33,0xC8,0x10,0xD7,0x07,0x9B,0xEC,
0x9A,0xE8,0x99,0x40,0x0A,0xED,0x9B,0xFD,
0xEC,0x9A,0xFC,0xE8,0x99,0xF8,0x0F,0xD5,
0xF0,0xDA,0xE4,0xCD,0xFB,0xE4,0xCC,0xFA,
0xE4,0xC8,0xF9,0x22,0xEB,0x9F,0xF5,0xF0,
0xEA,0x9E,0x42,0xF0,0xE9,0x9D,0x42,0xF0,
0xE8,0x9C,0x45,0xF0,0x22,0xE0,0xFC,0xA3,
0xE0,0xFD,0xA3,0xE0,0xFE,0xA3,0xE0,0xFF,
0x22,0xE0,0xF8,0xA3,0xE0,0xF9,0xA3,0xE0,
0xFA,0xA3,0xE0,0xFB,0x22,0xEC,0xF0,0xA3,
0xED,0xF0,0xA3,0xEE,0xF0,0xA3,0xEF,0xF0,
0x22,0x7D,0xD7,0x7C,0x04,0x7F,0x02,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x80,0x7C,0x04,
0x7F,0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,
0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,
0x06,0xE7,0x7D,0x94,0x7C,0xF9,0x7F,0x02,
0x7E,0x66,0x12,0x06,0xE7,0x7D,0x81,0x7C,
0x04,0x7F,0x01,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xA2,0x7C,0x31,0x7F,
0x02,0x7E,0x66,0x12,0x06,0xE7,0x7D,0x82,
0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x60,0x7C,0x69,
0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,0x7D,
0x83,0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,
0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,0x00,
0x7E,0x66,0x12,0x06,0xE7,0x7D,0x28,0x7C,
0x97,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x84,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7D,0x85,
0x7C,0x9D,0x7F,0x02,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0x23,0x7C,0x04,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0x7D,
0x10,0x7C,0xD8,0x7F,0x02,0x7E,0x66,0x12,
0x06,0xE7,0x7D,0x24,0x7C,0x04,0x7F,0x01,
0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,0x7C,
0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x00,0x7C,0x04,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x2F,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,0x06,
0xE7,0x7D,0x03,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,
0x02,0x7E,0x66,0x12,0x06,0xC3,0xEF,0x44,
0x40,0xFD,0xAC,0x06,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x03,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0x03,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,
0x02,0x7E,0x66,0x12,0x06,0xC3,0xEF,0x54,
0xBF,0xFD,0xAC,0x06,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x03,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,
0xE7,0xE4,0xFD,0xFC,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,0x02,
0x7E,0x66,0x12,0x06,0xC3,0xEF,0x54,0xFD,
0x54,0xFE,0xFD,0xAC,0x06,0x7F,0x02,0x7E,
0x66,0x12,0x06,0xE7,0xE4,0xFD,0xFC,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,
0xE7,0xE4,0xFD,0xFC,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,0x02,
0x7E,0x66,0x12,0x06,0xC3,0xEF,0x44,0x02,
0x44,0x01,0xFD,0xAC,0x06,0x7F,0x02,0x7E,
0x66,0x12,0x06,0xE7,0xE4,0xFD,0xFC,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,0x06,
0xE7,0xE4,0x90,0x06,0x2C,0xF0,0xFD,0x7C,
0x01,0x7F,0x3F,0x7E,0x1D,0x12,0x06,0xE7,
0x7D,0x40,0x7C,0x00,0x7F,0x36,0x7E,0x13,
0x12,0x06,0xE7,0xE4,0xFF,0xFE,0xFD,0x80,
0x25,0xE4,0x7F,0x20,0x7E,0x4E,0xFD,0xFC,
0x90,0x06,0x24,0x12,0x01,0x0F,0xC3,0x12,
0x00,0xF2,0x50,0x1B,0x90,0x06,0x24,0x12,
0x01,0x03,0xEF,0x24,0x01,0xFF,0xE4,0x3E,
0xFE,0xE4,0x3D,0xFD,0xE4,0x3C,0xFC,0x90,
0x06,0x24,0x12,0x01,0x1B,0x80,0xD2,0xE4,
0xF5,0xA8,0xD2,0xAF,0x12,0x07,0x17,0x7D,
0xFE,0x7C,0x00,0x7F,0xAA,0x7E,0x12,0x12,
0x06,0xE7,0x12,0x01,0x27,0x12,0x06,0x23,
0x7D,0x41,0x7C,0x00,0x7F,0x36,0x7E,0x13,
0x12,0x06,0xE7,0xE4,0xFF,0xFE,0xFD,0x80,
0x25,0xE4,0x7F,0x20,0x7E,0x4E,0xFD,0xFC,
0x90,0x06,0x24,0x12,0x01,0x0F,0xC3,0x12,
0x00,0xF2,0x50,0x1B,0x90,0x06,0x24,0x12,
0x01,0x03,0xEF,0x24,0x01,0xFF,0xE4,0x3E,
0xFE,0xE4,0x3D,0xFD,0xE4,0x3C,0xFC,0x90,
0x06,0x24,0x12,0x01,0x1B,0x80,0xD2,0xC2,
0x00,0xC2,0x01,0xD2,0xA9,0xD2,0x8C,0x7F,
0x01,0x7E,0x62,0x12,0x06,0xC3,0x7F,0x01,
0x7E,0x62,0x12,0x06,0xC3,0xEF,0x30,0xE2,
0x07,0xE4,0x90,0x06,0x2C,0xF0,0x80,0xE7,
0x90,0x06,0x2C,0xE0,0x70,0x12,0x12,0x04,
0xF1,0x90,0x06,0x2C,0x74,0x01,0xF0,0xE4,
0x90,0x06,0x33,0xF0,0xA3,0xF0,0x80,0xCF,
0xC3,0x90,0x06,0x34,0xE0,0x94,0x62,0x90,
0x06,0x33,0xE0,0x94,0x00,0x40,0xC0,0xE4,
0xF0,0xA3,0xF0,0x12,0x04,0xF1,0x90,0x06,
0x2C,0x74,0x01,0xF0,0x80,0xB1,0x75,0x0F,
0x80,0x75,0x0E,0x7E,0x75,0x0D,0xAA,0x75,
0x0C,0x83,0xE4,0xF5,0x10,0x7F,0x36,0x7E,
0x13,0x12,0x06,0xC3,0xEE,0xC4,0xF8,0x54,
0xF0,0xC8,0xEF,0xC4,0x54,0x0F,0x48,0x54,
0x07,0xFB,0x7A,0x00,0xEA,0x70,0x4A,0xEB,
0x14,0x60,0x1C,0x14,0x60,0x27,0x24,0xFE,
0x60,0x31,0x14,0x60,0x3C,0x24,0x05,0x70,
0x38,0x75,0x0B,0x00,0x75,0x0A,0xC2,0x75,
0x09,0xEB,0x75,0x08,0x0B,0x80,0x36,0x75,
0x0B,0x40,0x75,0x0A,0x59,0x75,0x09,0x73,
0x75,0x08,0x07,0x80,0x28,0x75,0x0B,0x00,
0x75,0x0A,0xE1,0x75,0x09,0xF5,0x75,0x08,
0x05,0x80,0x1A,0x75,0x0B,0xA0,0x75,0x0A,
0xAC,0x75,0x09,0xB9,0x75,0x08,0x03,0x80,
0x0C,0x75,0x0B,0x00,0x75,0x0A,0x62,0x75,
0x09,0x3D,0x75,0x08,0x01,0x75,0x89,0x11,
0xE4,0x7B,0x60,0x7A,0x09,0xF9,0xF8,0xAF,
0x0B,0xAE,0x0A,0xAD,0x09,0xAC,0x08,0x12,
0x00,0x60,0xAA,0x06,0xAB,0x07,0xC3,0xE4,
0x9B,0xFB,0xE4,0x9A,0xFA,0x78,0x17,0xF6,
0xAF,0x03,0xEF,0x08,0xF6,0x18,0xE6,0xF5,
0x8C,0x08,0xE6,0xF5,0x8A,0x74,0x0D,0x2B,
0xFB,0xE4,0x3A,0x18,0xF6,0xAF,0x03,0xEF,
0x08,0xF6,0x75,0x88,0x10,0x53,0x8E,0xC7,
0xD2,0xA9,0x22,0x7D,0x02,0x7C,0x00,0x7F,
0x4A,0x7E,0x13,0x12,0x06,0xE7,0x7D,0x46,
0x7C,0x71,0x7F,0x02,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0x03,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0xE4,
0xFF,0xFE,0x0F,0xBF,0x00,0x01,0x0E,0xEF,
0x64,0x64,0x4E,0x70,0xF5,0x7D,0x04,0x7C,
0x00,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x00,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0xE4,0xFD,
0xFC,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x00,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0xE4,0xFD,
0xFC,0x7F,0x4A,0x7E,0x13,0x12,0x06,0xE7,
0x7D,0x06,0x7C,0x71,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x03,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,0x06,
0xE7,0x78,0x7F,0xE4,0xF6,0xD8,0xFD,0x75,
0x81,0x3C,0x02,0x05,0xDE,0x02,0x03,0x2F,
0xE4,0x93,0xA3,0xF8,0xE4,0x93,0xA3,0x40,
0x03,0xF6,0x80,0x01,0xF2,0x08,0xDF,0xF4,
0x80,0x29,0xE4,0x93,0xA3,0xF8,0x54,0x07,
0x24,0x0C,0xC8,0xC3,0x33,0xC4,0x54,0x0F,
0x44,0x20,0xC8,0x83,0x40,0x04,0xF4,0x56,
0x80,0x01,0x46,0xF6,0xDF,0xE4,0x80,0x0B,
0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,
0x90,0x07,0x23,0xE4,0x7E,0x01,0x93,0x60,
0xBC,0xA3,0xFF,0x54,0x3F,0x30,0xE5,0x09,
0x54,0x1F,0xFE,0xE4,0x93,0xA3,0x60,0x01,
0x0E,0xCF,0x54,0xC0,0x25,0xE0,0x60,0xA8,
0x40,0xB8,0xE4,0x93,0xA3,0xFA,0xE4,0x93,
0xA3,0xF8,0xE4,0x93,0xA3,0xC8,0xC5,0x82,
0xC8,0xCA,0xC5,0x83,0xCA,0xF0,0xA3,0xC8,
0xC5,0x82,0xC8,0xCA,0xC5,0x83,0xCA,0xDF,
0xE9,0xDE,0xE7,0x80,0xBE,0x7D,0xD7,0x7C,
0x04,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x80,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7D,0x40,
0x7C,0x17,0x7F,0x11,0x7E,0x1D,0x12,0x06,
0xE7,0x7D,0xBB,0x7C,0x15,0x7F,0xEB,0x7E,
0x13,0x12,0x06,0xE7,0x7D,0x0C,0x7C,0x00,
0x7F,0xE7,0x7E,0x13,0x12,0x06,0xE7,0x7F,
0x41,0x7E,0x1D,0x12,0x06,0xC3,0xEF,0x44,
0x20,0x44,0x80,0xFD,0xAC,0x06,0x7F,0x41,
0x7E,0x1D,0x12,0x06,0xE7,0x7D,0x40,0x7C,
0x11,0x7F,0x00,0x7E,0x62,0x12,0x06,0xE7,
0x02,0x02,0x2F,0xC0,0xE0,0xC0,0xF0,0xC0,
0x83,0xC0,0x82,0xC0,0xD0,0x75,0xD0,0x00,
0xC0,0x00,0x78,0x17,0xE6,0xF5,0x8C,0x78,
0x18,0xE6,0xF5,0x8A,0x90,0x06,0x31,0xE4,
0x75,0xF0,0x01,0x12,0x00,0x0E,0x90,0x06,
0x33,0xE4,0x75,0xF0,0x01,0x12,0x00,0x0E,
0xD0,0x00,0xD0,0xD0,0xD0,0x82,0xD0,0x83,
0xD0,0xF0,0xD0,0xE0,0x32,0xC2,0xAF,0xAD,
0x07,0xAC,0x06,0x8C,0xA2,0x8D,0xA3,0x75,
0xA0,0x01,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0xAE,0xA1,0xBE,
0x00,0xF0,0xAE,0xA6,0xAF,0xA7,0xD2,0xAF,
0x22,0xC2,0xAF,0xAB,0x07,0xAA,0x06,0x8A,
0xA2,0x8B,0xA3,0x8C,0xA4,0x8D,0xA5,0x75,
0xA0,0x03,0x00,0x00,0x00,0xAA,0xA1,0xBA,
0x00,0xF8,0xD2,0xAF,0x22,0x7F,0x0C,0x7E,
0x13,0x12,0x06,0xC3,0xEF,0x44,0x50,0xFD,
0xAC,0x06,0x7F,0x0C,0x7E,0x13,0x02,0x06,
0xE7,0x12,0x07,0x03,0x12,0x07,0x2E,0x12,
0x04,0x2C,0x02,0x00,0x03,0x42,0x06,0x33,
0x00,0x00,0x42,0x06,0x31,0x00,0x00,0x00,
0xE4,0xF5,0x8E,0x22};

#define FIBER2_100M_INIT_SIZE 1842
rtk_uint8 Fiber2_100M[FIBER2_100M_INIT_SIZE] = {
0x02,0x05,0x97,0xE4,0xF5,0xA8,
0xD2,0xAF,0x22,0x00,0x00,0x02,0x06,0x89,
0xC5,0xF0,0xF8,0xA3,0xE0,0x28,0xF0,0xC5,
0xF0,0xF8,0xE5,0x82,0x15,0x82,0x70,0x02,
0x15,0x83,0xE0,0x38,0xF0,0x22,0x75,0xF0,
0x08,0x75,0x82,0x00,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xCD,0x33,0xCD,0xCC,0x33,0xCC,
0xC5,0x82,0x33,0xC5,0x82,0x9B,0xED,0x9A,
0xEC,0x99,0xE5,0x82,0x98,0x40,0x0C,0xF5,
0x82,0xEE,0x9B,0xFE,0xED,0x9A,0xFD,0xEC,
0x99,0xFC,0x0F,0xD5,0xF0,0xD6,0xE4,0xCE,
0xFB,0xE4,0xCD,0xFA,0xE4,0xCC,0xF9,0xA8,
0x82,0x22,0xB8,0x00,0xC1,0xB9,0x00,0x59,
0xBA,0x00,0x2D,0xEC,0x8B,0xF0,0x84,0xCF,
0xCE,0xCD,0xFC,0xE5,0xF0,0xCB,0xF9,0x78,
0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,0xED,
0x33,0xFD,0xEC,0x33,0xFC,0xEB,0x33,0xFB,
0x10,0xD7,0x03,0x99,0x40,0x04,0xEB,0x99,
0xFB,0x0F,0xD8,0xE5,0xE4,0xF9,0xFA,0x22,
0x78,0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,
0xED,0x33,0xFD,0xEC,0x33,0xFC,0xC9,0x33,
0xC9,0x10,0xD7,0x05,0x9B,0xE9,0x9A,0x40,
0x07,0xEC,0x9B,0xFC,0xE9,0x9A,0xF9,0x0F,
0xD8,0xE0,0xE4,0xC9,0xFA,0xE4,0xCC,0xFB,
0x22,0x75,0xF0,0x10,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xED,0x33,0xFD,0xCC,0x33,0xCC,
0xC8,0x33,0xC8,0x10,0xD7,0x07,0x9B,0xEC,
0x9A,0xE8,0x99,0x40,0x0A,0xED,0x9B,0xFD,
0xEC,0x9A,0xFC,0xE8,0x99,0xF8,0x0F,0xD5,
0xF0,0xDA,0xE4,0xCD,0xFB,0xE4,0xCC,0xFA,
0xE4,0xC8,0xF9,0x22,0xEB,0x9F,0xF5,0xF0,
0xEA,0x9E,0x42,0xF0,0xE9,0x9D,0x42,0xF0,
0xE8,0x9C,0x45,0xF0,0x22,0xE0,0xFC,0xA3,
0xE0,0xFD,0xA3,0xE0,0xFE,0xA3,0xE0,0xFF,
0x22,0xE0,0xF8,0xA3,0xE0,0xF9,0xA3,0xE0,
0xFA,0xA3,0xE0,0xFB,0x22,0xEC,0xF0,0xA3,
0xED,0xF0,0xA3,0xEE,0xF0,0xA3,0xEF,0xF0,
0x22,0x7D,0xD7,0x7C,0x04,0x7F,0x02,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x80,0x7C,0x04,
0x7F,0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,
0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,
0x06,0xE7,0x7D,0x94,0x7C,0xF9,0x7F,0x02,
0x7E,0x66,0x12,0x06,0xE7,0x7D,0x81,0x7C,
0x04,0x7F,0x01,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xA2,0x7C,0x31,0x7F,
0x02,0x7E,0x66,0x12,0x06,0xE7,0x7D,0x82,
0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x60,0x7C,0x69,
0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,0x7D,
0x83,0x7C,0x04,0x7F,0x01,0x7E,0x66,0x12,
0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,0x00,
0x7E,0x66,0x12,0x06,0xE7,0x7D,0x28,0x7C,
0x97,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x84,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7D,0x85,
0x7C,0x9D,0x7F,0x02,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0x23,0x7C,0x04,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0x7D,
0x10,0x7C,0xD8,0x7F,0x02,0x7E,0x66,0x12,
0x06,0xE7,0x7D,0x24,0x7C,0x04,0x7F,0x01,
0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,0x7C,
0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x00,0x7C,0x04,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x2F,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,0x06,
0xE7,0x7D,0x03,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,
0x02,0x7E,0x66,0x12,0x06,0xC3,0xEF,0x44,
0x40,0xFD,0xAC,0x06,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x03,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0x03,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,
0x02,0x7E,0x66,0x12,0x06,0xC3,0xEF,0x54,
0xBF,0xFD,0xAC,0x06,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x03,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,
0xE7,0xE4,0xFD,0xFC,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,0x02,
0x7E,0x66,0x12,0x06,0xC3,0xEF,0x54,0xFD,
0x54,0xFE,0xFD,0xAC,0x06,0x7F,0x02,0x7E,
0x66,0x12,0x06,0xE7,0xE4,0xFD,0xFC,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x06,
0xE7,0xE4,0xFD,0xFC,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x80,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7F,0x02,
0x7E,0x66,0x12,0x06,0xC3,0xEF,0x44,0x02,
0x44,0x01,0xFD,0xAC,0x06,0x7F,0x02,0x7E,
0x66,0x12,0x06,0xE7,0xE4,0xFD,0xFC,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,0x06,
0xE7,0xE4,0x90,0x06,0x2C,0xF0,0xFD,0x7C,
0x01,0x7F,0x3F,0x7E,0x1D,0x12,0x06,0xE7,
0x7D,0x40,0x7C,0x00,0x7F,0x36,0x7E,0x13,
0x12,0x06,0xE7,0xE4,0xFF,0xFE,0xFD,0x80,
0x25,0xE4,0x7F,0x20,0x7E,0x4E,0xFD,0xFC,
0x90,0x06,0x24,0x12,0x01,0x0F,0xC3,0x12,
0x00,0xF2,0x50,0x1B,0x90,0x06,0x24,0x12,
0x01,0x03,0xEF,0x24,0x01,0xFF,0xE4,0x3E,
0xFE,0xE4,0x3D,0xFD,0xE4,0x3C,0xFC,0x90,
0x06,0x24,0x12,0x01,0x1B,0x80,0xD2,0xE4,
0xF5,0xA8,0xD2,0xAF,0x12,0x07,0x17,0x7D,
0xFE,0x7C,0x00,0x7F,0xAA,0x7E,0x12,0x12,
0x06,0xE7,0x12,0x01,0x27,0x12,0x06,0x23,
0x7D,0x41,0x7C,0x00,0x7F,0x36,0x7E,0x13,
0x12,0x06,0xE7,0xE4,0xFF,0xFE,0xFD,0x80,
0x25,0xE4,0x7F,0x20,0x7E,0x4E,0xFD,0xFC,
0x90,0x06,0x24,0x12,0x01,0x0F,0xC3,0x12,
0x00,0xF2,0x50,0x1B,0x90,0x06,0x24,0x12,
0x01,0x03,0xEF,0x24,0x01,0xFF,0xE4,0x3E,
0xFE,0xE4,0x3D,0xFD,0xE4,0x3C,0xFC,0x90,
0x06,0x24,0x12,0x01,0x1B,0x80,0xD2,0xC2,
0x00,0xC2,0x01,0xD2,0xA9,0xD2,0x8C,0x7F,
0x01,0x7E,0x62,0x12,0x06,0xC3,0x7F,0x01,
0x7E,0x62,0x12,0x06,0xC3,0xEF,0x30,0xE2,
0x07,0xE4,0x90,0x06,0x2C,0xF0,0x80,0xE7,
0x90,0x06,0x2C,0xE0,0x70,0x12,0x12,0x04,
0xF1,0x90,0x06,0x2C,0x74,0x01,0xF0,0xE4,
0x90,0x06,0x33,0xF0,0xA3,0xF0,0x80,0xCF,
0xC3,0x90,0x06,0x34,0xE0,0x94,0x62,0x90,
0x06,0x33,0xE0,0x94,0x00,0x40,0xC0,0xE4,
0xF0,0xA3,0xF0,0x12,0x04,0xF1,0x90,0x06,
0x2C,0x74,0x01,0xF0,0x80,0xB1,0x75,0x0F,
0x80,0x75,0x0E,0x7E,0x75,0x0D,0xAA,0x75,
0x0C,0x83,0xE4,0xF5,0x10,0x7F,0x36,0x7E,
0x13,0x12,0x06,0xC3,0xEE,0xC4,0xF8,0x54,
0xF0,0xC8,0xEF,0xC4,0x54,0x0F,0x48,0x54,
0x07,0xFB,0x7A,0x00,0xEA,0x70,0x4A,0xEB,
0x14,0x60,0x1C,0x14,0x60,0x27,0x24,0xFE,
0x60,0x31,0x14,0x60,0x3C,0x24,0x05,0x70,
0x38,0x75,0x0B,0x00,0x75,0x0A,0xC2,0x75,
0x09,0xEB,0x75,0x08,0x0B,0x80,0x36,0x75,
0x0B,0x40,0x75,0x0A,0x59,0x75,0x09,0x73,
0x75,0x08,0x07,0x80,0x28,0x75,0x0B,0x00,
0x75,0x0A,0xE1,0x75,0x09,0xF5,0x75,0x08,
0x05,0x80,0x1A,0x75,0x0B,0xA0,0x75,0x0A,
0xAC,0x75,0x09,0xB9,0x75,0x08,0x03,0x80,
0x0C,0x75,0x0B,0x00,0x75,0x0A,0x62,0x75,
0x09,0x3D,0x75,0x08,0x01,0x75,0x89,0x11,
0xE4,0x7B,0x60,0x7A,0x09,0xF9,0xF8,0xAF,
0x0B,0xAE,0x0A,0xAD,0x09,0xAC,0x08,0x12,
0x00,0x60,0xAA,0x06,0xAB,0x07,0xC3,0xE4,
0x9B,0xFB,0xE4,0x9A,0xFA,0x78,0x17,0xF6,
0xAF,0x03,0xEF,0x08,0xF6,0x18,0xE6,0xF5,
0x8C,0x08,0xE6,0xF5,0x8A,0x74,0x0D,0x2B,
0xFB,0xE4,0x3A,0x18,0xF6,0xAF,0x03,0xEF,
0x08,0xF6,0x75,0x88,0x10,0x53,0x8E,0xC7,
0xD2,0xA9,0x22,0x7D,0x02,0x7C,0x00,0x7F,
0x4A,0x7E,0x13,0x12,0x06,0xE7,0x7D,0x46,
0x7C,0x71,0x7F,0x02,0x7E,0x66,0x12,0x06,
0xE7,0x7D,0x03,0x7C,0x00,0x7F,0x01,0x7E,
0x66,0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,
0x7F,0x00,0x7E,0x66,0x12,0x06,0xE7,0xE4,
0xFF,0xFE,0x0F,0xBF,0x00,0x01,0x0E,0xEF,
0x64,0x64,0x4E,0x70,0xF5,0x7D,0x04,0x7C,
0x00,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x00,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0xE4,0xFD,
0xFC,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x00,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0xE4,0xFD,
0xFC,0x7F,0x4A,0x7E,0x13,0x12,0x06,0xE7,
0x7D,0x06,0x7C,0x71,0x7F,0x02,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0x03,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x02,0x06,
0xE7,0x78,0x7F,0xE4,0xF6,0xD8,0xFD,0x75,
0x81,0x3C,0x02,0x05,0xDE,0x02,0x03,0x2F,
0xE4,0x93,0xA3,0xF8,0xE4,0x93,0xA3,0x40,
0x03,0xF6,0x80,0x01,0xF2,0x08,0xDF,0xF4,
0x80,0x29,0xE4,0x93,0xA3,0xF8,0x54,0x07,
0x24,0x0C,0xC8,0xC3,0x33,0xC4,0x54,0x0F,
0x44,0x20,0xC8,0x83,0x40,0x04,0xF4,0x56,
0x80,0x01,0x46,0xF6,0xDF,0xE4,0x80,0x0B,
0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,
0x90,0x07,0x23,0xE4,0x7E,0x01,0x93,0x60,
0xBC,0xA3,0xFF,0x54,0x3F,0x30,0xE5,0x09,
0x54,0x1F,0xFE,0xE4,0x93,0xA3,0x60,0x01,
0x0E,0xCF,0x54,0xC0,0x25,0xE0,0x60,0xA8,
0x40,0xB8,0xE4,0x93,0xA3,0xFA,0xE4,0x93,
0xA3,0xF8,0xE4,0x93,0xA3,0xC8,0xC5,0x82,
0xC8,0xCA,0xC5,0x83,0xCA,0xF0,0xA3,0xC8,
0xC5,0x82,0xC8,0xCA,0xC5,0x83,0xCA,0xDF,
0xE9,0xDE,0xE7,0x80,0xBE,0x7D,0xD7,0x7C,
0x24,0x7F,0x02,0x7E,0x66,0x12,0x06,0xE7,
0x7D,0x80,0x7C,0x04,0x7F,0x01,0x7E,0x66,
0x12,0x06,0xE7,0x7D,0xC0,0x7C,0x00,0x7F,
0x00,0x7E,0x66,0x12,0x06,0xE7,0x7D,0xC0,
0x7C,0x16,0x7F,0x11,0x7E,0x1D,0x12,0x06,
0xE7,0x7D,0xBB,0x7C,0x15,0x7F,0xEB,0x7E,
0x13,0x12,0x06,0xE7,0x7D,0x0D,0x7C,0x00,
0x7F,0xE7,0x7E,0x13,0x12,0x06,0xE7,0x7F,
0x41,0x7E,0x1D,0x12,0x06,0xC3,0xEF,0x44,
0x20,0x44,0x80,0xFD,0xAC,0x06,0x7F,0x41,
0x7E,0x1D,0x12,0x06,0xE7,0x7D,0x00,0x7C,
0x21,0x7F,0x00,0x7E,0x62,0x12,0x06,0xE7,
0x02,0x02,0x2F,0xC0,0xE0,0xC0,0xF0,0xC0,
0x83,0xC0,0x82,0xC0,0xD0,0x75,0xD0,0x00,
0xC0,0x00,0x78,0x17,0xE6,0xF5,0x8C,0x78,
0x18,0xE6,0xF5,0x8A,0x90,0x06,0x31,0xE4,
0x75,0xF0,0x01,0x12,0x00,0x0E,0x90,0x06,
0x33,0xE4,0x75,0xF0,0x01,0x12,0x00,0x0E,
0xD0,0x00,0xD0,0xD0,0xD0,0x82,0xD0,0x83,
0xD0,0xF0,0xD0,0xE0,0x32,0xC2,0xAF,0xAD,
0x07,0xAC,0x06,0x8C,0xA2,0x8D,0xA3,0x75,
0xA0,0x01,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0xAE,0xA1,0xBE,
0x00,0xF0,0xAE,0xA6,0xAF,0xA7,0xD2,0xAF,
0x22,0xC2,0xAF,0xAB,0x07,0xAA,0x06,0x8A,
0xA2,0x8B,0xA3,0x8C,0xA4,0x8D,0xA5,0x75,
0xA0,0x03,0x00,0x00,0x00,0xAA,0xA1,0xBA,
0x00,0xF8,0xD2,0xAF,0x22,0x7F,0x0C,0x7E,
0x13,0x12,0x06,0xC3,0xEF,0x44,0x50,0xFD,
0xAC,0x06,0x7F,0x0C,0x7E,0x13,0x02,0x06,
0xE7,0x12,0x07,0x03,0x12,0x07,0x2E,0x12,
0x04,0x2C,0x02,0x00,0x03,0x42,0x06,0x33,
0x00,0x00,0x42,0x06,0x31,0x00,0x00,0x00,
0xE4,0xF5,0x8E,0x22};


#define SGMII_INIT_SIZE 1223
rtk_uint8 Sgmii_Init[SGMII_INIT_SIZE] = {
0x02,0x03,0xA9,0xE4,0xF5,0xA8,
0xD2,0xAF,0x22,0x00,0x00,0x02,0x04,0x35,
0xC5,0xF0,0xF8,0xA3,0xE0,0x28,0xF0,0xC5,
0xF0,0xF8,0xE5,0x82,0x15,0x82,0x70,0x02,
0x15,0x83,0xE0,0x38,0xF0,0x22,0x75,0xF0,
0x08,0x75,0x82,0x00,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xCD,0x33,0xCD,0xCC,0x33,0xCC,
0xC5,0x82,0x33,0xC5,0x82,0x9B,0xED,0x9A,
0xEC,0x99,0xE5,0x82,0x98,0x40,0x0C,0xF5,
0x82,0xEE,0x9B,0xFE,0xED,0x9A,0xFD,0xEC,
0x99,0xFC,0x0F,0xD5,0xF0,0xD6,0xE4,0xCE,
0xFB,0xE4,0xCD,0xFA,0xE4,0xCC,0xF9,0xA8,
0x82,0x22,0xB8,0x00,0xC1,0xB9,0x00,0x59,
0xBA,0x00,0x2D,0xEC,0x8B,0xF0,0x84,0xCF,
0xCE,0xCD,0xFC,0xE5,0xF0,0xCB,0xF9,0x78,
0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,0xED,
0x33,0xFD,0xEC,0x33,0xFC,0xEB,0x33,0xFB,
0x10,0xD7,0x03,0x99,0x40,0x04,0xEB,0x99,
0xFB,0x0F,0xD8,0xE5,0xE4,0xF9,0xFA,0x22,
0x78,0x18,0xEF,0x2F,0xFF,0xEE,0x33,0xFE,
0xED,0x33,0xFD,0xEC,0x33,0xFC,0xC9,0x33,
0xC9,0x10,0xD7,0x05,0x9B,0xE9,0x9A,0x40,
0x07,0xEC,0x9B,0xFC,0xE9,0x9A,0xF9,0x0F,
0xD8,0xE0,0xE4,0xC9,0xFA,0xE4,0xCC,0xFB,
0x22,0x75,0xF0,0x10,0xEF,0x2F,0xFF,0xEE,
0x33,0xFE,0xED,0x33,0xFD,0xCC,0x33,0xCC,
0xC8,0x33,0xC8,0x10,0xD7,0x07,0x9B,0xEC,
0x9A,0xE8,0x99,0x40,0x0A,0xED,0x9B,0xFD,
0xEC,0x9A,0xFC,0xE8,0x99,0xF8,0x0F,0xD5,
0xF0,0xDA,0xE4,0xCD,0xFB,0xE4,0xCC,0xFA,
0xE4,0xC8,0xF9,0x22,0xEB,0x9F,0xF5,0xF0,
0xEA,0x9E,0x42,0xF0,0xE9,0x9D,0x42,0xF0,
0xE8,0x9C,0x45,0xF0,0x22,0xE0,0xFC,0xA3,
0xE0,0xFD,0xA3,0xE0,0xFE,0xA3,0xE0,0xFF,
0x22,0xE0,0xF8,0xA3,0xE0,0xF9,0xA3,0xE0,
0xFA,0xA3,0xE0,0xFB,0x22,0xEC,0xF0,0xA3,
0xED,0xF0,0xA3,0xEE,0xF0,0xA3,0xEF,0xF0,
0x22,0xE4,0x90,0x06,0x28,0xF0,0xFD,0x7C,
0x01,0x7F,0x3F,0x7E,0x1D,0x12,0x04,0x93,
0x7D,0x40,0x7C,0x00,0x7F,0x36,0x7E,0x13,
0x12,0x04,0x93,0xE4,0xFF,0xFE,0xFD,0x80,
0x25,0xE4,0x7F,0xFF,0x7E,0xFF,0xFD,0xFC,
0x90,0x06,0x24,0x12,0x01,0x0F,0xC3,0x12,
0x00,0xF2,0x50,0x1B,0x90,0x06,0x24,0x12,
0x01,0x03,0xEF,0x24,0x01,0xFF,0xE4,0x3E,
0xFE,0xE4,0x3D,0xFD,0xE4,0x3C,0xFC,0x90,
0x06,0x24,0x12,0x01,0x1B,0x80,0xD2,0xE4,
0xF5,0xA8,0xD2,0xAF,0x7D,0x1F,0xFC,0x7F,
0x49,0x7E,0x13,0x12,0x04,0x93,0x12,0x04,
0xBA,0x7D,0xFE,0x7C,0x00,0x7F,0xAA,0x7E,
0x12,0x12,0x04,0x93,0x7D,0x41,0x7C,0x00,
0x7F,0x36,0x7E,0x13,0x12,0x04,0x93,0xE4,
0xFF,0xFE,0xFD,0x80,0x25,0xE4,0x7F,0x20,
0x7E,0x4E,0xFD,0xFC,0x90,0x06,0x24,0x12,
0x01,0x0F,0xC3,0x12,0x00,0xF2,0x50,0x1B,
0x90,0x06,0x24,0x12,0x01,0x03,0xEF,0x24,
0x01,0xFF,0xE4,0x3E,0xFE,0xE4,0x3D,0xFD,
0xE4,0x3C,0xFC,0x90,0x06,0x24,0x12,0x01,
0x1B,0x80,0xD2,0xC2,0x00,0xC2,0x01,0xD2,
0xA9,0xD2,0x8C,0x7D,0x3D,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x04,0x93,0x7D,0x80,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x04,
0x93,0x7F,0x02,0x7E,0x66,0x12,0x04,0x6F,
0x7F,0x02,0x7E,0x66,0x12,0x04,0x6F,0xEF,
0x30,0xE4,0x07,0xE4,0x90,0x06,0x28,0xF0,
0x80,0xD1,0x90,0x06,0x28,0xE0,0x70,0x12,
0x12,0x03,0x03,0x90,0x06,0x28,0x74,0x01,
0xF0,0xE4,0x90,0x06,0x2B,0xF0,0xA3,0xF0,
0x80,0xB9,0xC3,0x90,0x06,0x2C,0xE0,0x94,
0x62,0x90,0x06,0x2B,0xE0,0x94,0x00,0x40,
0xAA,0xE4,0xF0,0xA3,0xF0,0x12,0x03,0x03,
0x90,0x06,0x28,0x74,0x01,0xF0,0x80,0x9B,
0x75,0x0F,0x80,0x75,0x0E,0x7E,0x75,0x0D,
0xAA,0x75,0x0C,0x83,0xE4,0xF5,0x10,0x7F,
0x36,0x7E,0x13,0x12,0x04,0x6F,0xEE,0xC4,
0xF8,0x54,0xF0,0xC8,0xEF,0xC4,0x54,0x0F,
0x48,0x54,0x07,0xFB,0x7A,0x00,0xEA,0x70,
0x4A,0xEB,0x14,0x60,0x1C,0x14,0x60,0x27,
0x24,0xFE,0x60,0x31,0x14,0x60,0x3C,0x24,
0x05,0x70,0x38,0x75,0x0B,0x00,0x75,0x0A,
0xC2,0x75,0x09,0xEB,0x75,0x08,0x0B,0x80,
0x36,0x75,0x0B,0x40,0x75,0x0A,0x59,0x75,
0x09,0x73,0x75,0x08,0x07,0x80,0x28,0x75,
0x0B,0x00,0x75,0x0A,0xE1,0x75,0x09,0xF5,
0x75,0x08,0x05,0x80,0x1A,0x75,0x0B,0xA0,
0x75,0x0A,0xAC,0x75,0x09,0xB9,0x75,0x08,
0x03,0x80,0x0C,0x75,0x0B,0x00,0x75,0x0A,
0x62,0x75,0x09,0x3D,0x75,0x08,0x01,0x75,
0x89,0x11,0xE4,0x7B,0x60,0x7A,0x09,0xF9,
0xF8,0xAF,0x0B,0xAE,0x0A,0xAD,0x09,0xAC,
0x08,0x12,0x00,0x60,0xAA,0x06,0xAB,0x07,
0xC3,0xE4,0x9B,0xFB,0xE4,0x9A,0xFA,0x78,
0x17,0xF6,0xAF,0x03,0xEF,0x08,0xF6,0x18,
0xE6,0xF5,0x8C,0x08,0xE6,0xF5,0x8A,0x74,
0x0D,0x2B,0xFB,0xE4,0x3A,0x18,0xF6,0xAF,
0x03,0xEF,0x08,0xF6,0x75,0x88,0x10,0x53,
0x8E,0xC7,0xD2,0xA9,0x22,0x7D,0x02,0x7C,
0x00,0x7F,0x4A,0x7E,0x13,0x12,0x04,0x93,
0x7D,0x46,0x7C,0x71,0x7F,0x02,0x7E,0x66,
0x12,0x04,0x93,0x7D,0x03,0x7C,0x00,0x7F,
0x01,0x7E,0x66,0x12,0x04,0x93,0x7D,0xC0,
0x7C,0x00,0x7F,0x00,0x7E,0x66,0x12,0x04,
0x93,0xE4,0xFF,0xFE,0x0F,0xBF,0x00,0x01,
0x0E,0xEF,0x64,0x64,0x4E,0x70,0xF5,0x7D,
0x04,0x7C,0x00,0x7F,0x02,0x7E,0x66,0x12,
0x04,0x93,0x7D,0x00,0x7C,0x04,0x7F,0x01,
0x7E,0x66,0x12,0x04,0x93,0x7D,0xC0,0x7C,
0x00,0x7F,0x00,0x7E,0x66,0x12,0x04,0x93,
0xE4,0xFD,0xFC,0x7F,0x02,0x7E,0x66,0x12,
0x04,0x93,0x7D,0x00,0x7C,0x04,0x7F,0x01,
0x7E,0x66,0x12,0x04,0x93,0x7D,0xC0,0x7C,
0x00,0x7F,0x00,0x7E,0x66,0x12,0x04,0x93,
0xE4,0xFD,0xFC,0x7F,0x4A,0x7E,0x13,0x12,
0x04,0x93,0x7D,0x06,0x7C,0x71,0x7F,0x02,
0x7E,0x66,0x12,0x04,0x93,0x7D,0x03,0x7C,
0x00,0x7F,0x01,0x7E,0x66,0x12,0x04,0x93,
0x7D,0xC0,0x7C,0x00,0x7F,0x00,0x7E,0x66,
0x02,0x04,0x93,0x78,0x7F,0xE4,0xF6,0xD8,
0xFD,0x75,0x81,0x3C,0x02,0x03,0xF0,0x02,
0x01,0x27,0xE4,0x93,0xA3,0xF8,0xE4,0x93,
0xA3,0x40,0x03,0xF6,0x80,0x01,0xF2,0x08,
0xDF,0xF4,0x80,0x29,0xE4,0x93,0xA3,0xF8,
0x54,0x07,0x24,0x0C,0xC8,0xC3,0x33,0xC4,
0x54,0x0F,0x44,0x20,0xC8,0x83,0x40,0x04,
0xF4,0x56,0x80,0x01,0x46,0xF6,0xDF,0xE4,
0x80,0x0B,0x01,0x02,0x04,0x08,0x10,0x20,
0x40,0x80,0x90,0x04,0xAF,0xE4,0x7E,0x01,
0x93,0x60,0xBC,0xA3,0xFF,0x54,0x3F,0x30,
0xE5,0x09,0x54,0x1F,0xFE,0xE4,0x93,0xA3,
0x60,0x01,0x0E,0xCF,0x54,0xC0,0x25,0xE0,
0x60,0xA8,0x40,0xB8,0xE4,0x93,0xA3,0xFA,
0xE4,0x93,0xA3,0xF8,0xE4,0x93,0xA3,0xC8,
0xC5,0x82,0xC8,0xCA,0xC5,0x83,0xCA,0xF0,
0xA3,0xC8,0xC5,0x82,0xC8,0xCA,0xC5,0x83,
0xCA,0xDF,0xE9,0xDE,0xE7,0x80,0xBE,0xC0,
0xE0,0xC0,0xF0,0xC0,0x83,0xC0,0x82,0xC0,
0xD0,0x75,0xD0,0x00,0xC0,0x00,0x78,0x17,
0xE6,0xF5,0x8C,0x78,0x18,0xE6,0xF5,0x8A,
0x90,0x06,0x29,0xE4,0x75,0xF0,0x01,0x12,
0x00,0x0E,0x90,0x06,0x2B,0xE4,0x75,0xF0,
0x01,0x12,0x00,0x0E,0xD0,0x00,0xD0,0xD0,
0xD0,0x82,0xD0,0x83,0xD0,0xF0,0xD0,0xE0,
0x32,0xC2,0xAF,0xAD,0x07,0xAC,0x06,0x8C,
0xA2,0x8D,0xA3,0x75,0xA0,0x01,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0xAE,0xA1,0xBE,0x00,0xF0,0xAE,0xA6,
0xAF,0xA7,0xD2,0xAF,0x22,0xC2,0xAF,0xAB,
0x07,0xAA,0x06,0x8A,0xA2,0x8B,0xA3,0x8C,
0xA4,0x8D,0xA5,0x75,0xA0,0x03,0x00,0x00,
0x00,0xAA,0xA1,0xBA,0x00,0xF8,0xD2,0xAF,
0x22,0x42,0x06,0x2B,0x00,0x00,0x42,0x06,
0x29,0x00,0x00,0x00,0x12,0x04,0xC3,0x12,
0x02,0x3E,0x02,0x00,0x03,0xE4,0xF5,0x8E,
0x22};

#define FIBER1_2_INIT_SIZE 1332
rtk_uint8 Fiber1_2_Init[FIBER1_2_INIT_SIZE] = {
0x02,0x05,0x28,0x90,0x00,0x0A,0xEE,0xF0,
0xA3,0xEF,0xF0,0xE4,0x7F,0x11,0x7E,0x62,
0x12,0x04,0xF7,0x7F,0x11,0x7E,0x62,0x12,
0x04,0xF7,0xEF,0x30,0xE2,0x03,0x02,0x01,
0xA8,0x90,0x00,0x0B,0xE0,0x04,0xF0,0x70,
0x06,0x90,0x00,0x0A,0xE0,0x04,0xF0,0x90,
0x00,0x0A,0xE0,0xFC,0xA3,0xE0,0xFD,0x7F,
0xA4,0x7E,0x0B,0x12,0x04,0xDB,0x7D,0x66,
0x7C,0x00,0x7F,0x11,0x7E,0x13,0x12,0x04,
0xDB,0x7D,0x66,0x7C,0x10,0x7F,0x11,0x7E,
0x13,0x12,0x04,0xDB,0x7F,0x9D,0x7E,0x1D,
0x12,0x04,0xF7,0xEE,0x30,0xE0,0xF5,0xE4,
0x90,0x00,0x0C,0xF0,0xA3,0xF0,0x90,0x00,
0x0D,0xE0,0x04,0xF0,0x70,0x06,0x90,0x00,
0x0C,0xE0,0x04,0xF0,0x90,0x00,0x0C,0xE0,
0xB4,0x0B,0xEB,0xA3,0xE0,0xB4,0xB8,0xE6,
0x7D,0x02,0x7C,0x00,0x7F,0x3D,0x7E,0x13,
0x12,0x04,0xDB,0xE4,0x90,0x00,0x0C,0xF0,
0xA3,0xF0,0x90,0x00,0x0D,0xE0,0x04,0xF0,
0x70,0x06,0x90,0x00,0x0C,0xE0,0x04,0xF0,
0x90,0x00,0x0C,0xE0,0xB4,0x0B,0xEB,0xA3,
0xE0,0xB4,0xB8,0xE6,0x90,0x00,0x14,0x74,
0x14,0xF0,0xA3,0xE4,0xF0,0xFB,0xFA,0xFD,
0xFC,0x7F,0x01,0xFE,0x12,0x04,0x2D,0xE4,
0x90,0x00,0x0C,0xF0,0xA3,0xF0,0x90,0x00,
0x0C,0xE0,0xFE,0xA3,0xE0,0xFF,0xE4,0xFC,
0xFD,0x7B,0x60,0x7A,0xEA,0xF9,0xF8,0xD3,
0x12,0x05,0x12,0x40,0x10,0x90,0x00,0x0D,
0xE0,0x04,0xF0,0x70,0x06,0x90,0x00,0x0C,
0xE0,0x04,0xF0,0x80,0xD9,0xE4,0x90,0x00,
0x0C,0xF0,0xA3,0xF0,0x90,0x00,0x0C,0xE0,
0xFE,0xA3,0xE0,0xFF,0xE4,0xFC,0xFD,0x7B,
0x60,0x7A,0xEA,0xF9,0xF8,0xD3,0x12,0x05,
0x12,0x40,0x10,0x90,0x00,0x0D,0xE0,0x04,
0xF0,0x70,0x06,0x90,0x00,0x0C,0xE0,0x04,
0xF0,0x80,0xD9,0x90,0x00,0x14,0x74,0x14,
0xF0,0xA3,0x74,0x03,0xF0,0xE4,0xFB,0xFA,
0xFD,0xFC,0x7F,0x01,0xFE,0x12,0x04,0x2D,
0xE4,0x90,0x00,0x0C,0xF0,0xA3,0xF0,0x90,
0x00,0x0D,0xE0,0x04,0xF0,0x70,0x06,0x90,
0x00,0x0C,0xE0,0x04,0xF0,0x90,0x00,0x0C,
0xE0,0xB4,0x75,0xEB,0xA3,0xE0,0xB4,0x30,
0xE6,0xE4,0x90,0x00,0x0C,0xF0,0xA3,0xF0,
0x90,0x00,0x0D,0xE0,0x04,0xF0,0x70,0x06,
0x90,0x00,0x0C,0xE0,0x04,0xF0,0x90,0x00,
0x0C,0xE0,0xB4,0x75,0xEB,0xA3,0xE0,0xB4,
0x30,0xE6,0xE4,0xFD,0xFC,0x7F,0x3D,0x7E,
0x13,0x12,0x04,0xDB,0xE4,0x90,0x00,0x0C,
0xF0,0xA3,0xF0,0x90,0x00,0x0D,0xE0,0x04,
0xF0,0x70,0x06,0x90,0x00,0x0C,0xE0,0x04,
0xF0,0x90,0x00,0x0C,0xE0,0xB4,0x0B,0xEB,
0xA3,0xE0,0xB4,0xB8,0xE6,0x7D,0x66,0x7C,
0x00,0x7F,0x11,0x7E,0x13,0x12,0x04,0xDB,
0x22,0x90,0x00,0x0A,0xEE,0xF0,0xA3,0xEF,
0xF0,0xE4,0xFF,0x0F,0x7E,0x62,0x12,0x04,
0xF7,0x7F,0x01,0x7E,0x62,0x12,0x04,0xF7,
0xEF,0x30,0xE2,0x03,0x02,0x03,0x4C,0x90,
0x00,0x0B,0xE0,0x04,0xF0,0x70,0x06,0x90,
0x00,0x0A,0xE0,0x04,0xF0,0x90,0x00,0x0A,
0xE0,0xFC,0xA3,0xE0,0xFD,0x7F,0xA3,0x7E,
0x0B,0x12,0x04,0xDB,0x7D,0x66,0x7C,0x00,
0x7F,0xC4,0x7E,0x13,0x12,0x04,0xDB,0x7D,
0x66,0x7C,0x10,0x7F,0xC4,0x7E,0x13,0x12,
0x04,0xDB,0x7F,0x9D,0x7E,0x1D,0x12,0x04,
0xF7,0xEE,0x30,0xE1,0xF5,0xE4,0x90,0x00,
0x0C,0xF0,0xA3,0xF0,0x90,0x00,0x0D,0xE0,
0x04,0xF0,0x70,0x06,0x90,0x00,0x0C,0xE0,
0x04,0xF0,0x90,0x00,0x0C,0xE0,0xB4,0x0B,
0xEB,0xA3,0xE0,0xB4,0xB8,0xE6,0x7D,0x02,
0x7C,0x00,0x7F,0x3D,0x7E,0x13,0x12,0x04,
0xDB,0xE4,0x90,0x00,0x0C,0xF0,0xA3,0xF0,
0x90,0x00,0x0D,0xE0,0x04,0xF0,0x70,0x06,
0x90,0x00,0x0C,0xE0,0x04,0xF0,0x90,0x00,
0x0C,0xE0,0xB4,0x0B,0xEB,0xA3,0xE0,0xB4,
0xB8,0xE6,0x90,0x00,0x14,0x74,0x14,0xF0,
0xA3,0xE4,0xF0,0xFB,0xFA,0xFD,0xFC,0xFF,
0xFE,0x12,0x04,0x2D,0xE4,0x90,0x00,0x0C,
0xF0,0xA3,0xF0,0x90,0x00,0x0C,0xE0,0xFE,
0xA3,0xE0,0xFF,0xE4,0xFC,0xFD,0x7B,0x60,
0x7A,0xEA,0xF9,0xF8,0xD3,0x12,0x05,0x12,
0x40,0x10,0x90,0x00,0x0D,0xE0,0x04,0xF0,
0x70,0x06,0x90,0x00,0x0C,0xE0,0x04,0xF0,
0x80,0xD9,0xE4,0x90,0x00,0x0C,0xF0,0xA3,
0xF0,0x90,0x00,0x0C,0xE0,0xFE,0xA3,0xE0,
0xFF,0xE4,0xFC,0xFD,0x7B,0x60,0x7A,0xEA,
0xF9,0xF8,0xD3,0x12,0x05,0x12,0x40,0x10,
0x90,0x00,0x0D,0xE0,0x04,0xF0,0x70,0x06,
0x90,0x00,0x0C,0xE0,0x04,0xF0,0x80,0xD9,
0x90,0x00,0x14,0x74,0x14,0xF0,0xA3,0x74,
0x03,0xF0,0xE4,0xFB,0xFA,0xFD,0xFC,0xFF,
0xFE,0x12,0x04,0x2D,0xE4,0x90,0x00,0x0C,
0xF0,0xA3,0xF0,0x90,0x00,0x0D,0xE0,0x04,
0xF0,0x70,0x06,0x90,0x00,0x0C,0xE0,0x04,
0xF0,0x90,0x00,0x0C,0xE0,0xB4,0x75,0xEB,
0xA3,0xE0,0xB4,0x30,0xE6,0xE4,0x90,0x00,
0x0C,0xF0,0xA3,0xF0,0x90,0x00,0x0D,0xE0,
0x04,0xF0,0x70,0x06,0x90,0x00,0x0C,0xE0,
0x04,0xF0,0x90,0x00,0x0C,0xE0,0xB4,0x75,
0xEB,0xA3,0xE0,0xB4,0x30,0xE6,0xE4,0xFD,
0xFC,0x7F,0x3D,0x7E,0x13,0x12,0x04,0xDB,
0xE4,0x90,0x00,0x0C,0xF0,0xA3,0xF0,0x90,
0x00,0x0D,0xE0,0x04,0xF0,0x70,0x06,0x90,
0x00,0x0C,0xE0,0x04,0xF0,0x90,0x00,0x0C,
0xE0,0xB4,0x0B,0xEB,0xA3,0xE0,0xB4,0xB8,
0xE6,0x7D,0x66,0x7C,0x00,0x7F,0xC4,0x7E,
0x13,0x12,0x04,0xDB,0x22,0xE4,0x90,0x00,
0x00,0xF0,0xA3,0xF0,0xA3,0xF0,0xA3,0xF0,
0xA3,0xF0,0xA3,0xF0,0xA3,0xF0,0xA3,0xF0,
0x7D,0x51,0xFC,0x7F,0x36,0x7E,0x13,0x12,
0x04,0xDB,0xE4,0x90,0x00,0x08,0xF0,0xA3,
0xF0,0x90,0x00,0x09,0xE0,0x04,0xF0,0x70,
0x06,0x90,0x00,0x08,0xE0,0x04,0xF0,0x90,
0x00,0x08,0xE0,0x70,0x04,0xA3,0xE0,0x64,
0x64,0x70,0xE6,0xE4,0x90,0x00,0x08,0xF0,
0xA3,0xF0,0xE4,0xFF,0xFE,0x0F,0xBF,0x00,
0x01,0x0E,0xEF,0x64,0x32,0x4E,0x70,0xF5,
0x90,0x00,0x09,0xE0,0x04,0xF0,0x70,0x06,
0x90,0x00,0x08,0xE0,0x04,0xF0,0x90,0x00,
0x08,0xE0,0xB4,0x75,0xDD,0xA3,0xE0,0xB4,
0x30,0xD8,0x7F,0x59,0x7E,0x1B,0x12,0x04,
0xF7,0xEF,0x4E,0x70,0xC6,0x7F,0x92,0x7E,
0x1D,0x12,0x04,0xF7,0x90,0x00,0x06,0xEE,
0xF0,0xA3,0xEF,0xF0,0x64,0x07,0x60,0x0A,
0xEF,0x64,0x05,0x60,0x05,0xEF,0x64,0x04,
0x70,0x19,0x90,0x00,0x01,0xE0,0x04,0xF0,
0x70,0x06,0x90,0x00,0x00,0xE0,0x04,0xF0,
0x90,0x00,0x00,0xE0,0xFE,0xA3,0xE0,0xFF,
0x12,0x01,0xA9,0x90,0x00,0x06,0xE0,0xFF,
0x64,0x07,0x60,0x0D,0xEF,0x64,0x05,0x60,
0x08,0xEF,0x64,0x04,0x60,0x03,0x02,0x03,
0x8B,0x90,0x00,0x03,0xE0,0x04,0xF0,0x70,
0x06,0x90,0x00,0x02,0xE0,0x04,0xF0,0x90,
0x00,0x02,0xE0,0xFE,0xA3,0xE0,0xFF,0x12,
0x00,0x03,0x02,0x03,0x8B,0x90,0x00,0x0E,
0xEE,0xF0,0xA3,0xEF,0xF0,0xE4,0x90,0x00,
0x16,0xF0,0xA3,0xF0,0xA3,0xF0,0xA3,0xF0,
0xAE,0x02,0xEB,0x78,0x05,0xC3,0x33,0xCE,
0x33,0xCE,0xD8,0xF9,0xFF,0xEE,0x4C,0xFE,
0xEF,0x4D,0xFF,0x90,0x00,0x16,0xEE,0xF0,
0xA3,0xEF,0xF0,0x90,0x00,0x0E,0xE0,0xFF,
0xA3,0xE0,0x44,0xC0,0x90,0x00,0x18,0xCF,
0xF0,0xA3,0xEF,0xF0,0x90,0x00,0x14,0xE0,
0xFC,0xA3,0xE0,0xFD,0x7F,0x02,0x7E,0x66,
0x12,0x04,0xDB,0x90,0x00,0x16,0xE0,0xFC,
0xA3,0xE0,0xFD,0x7F,0x01,0x7E,0x66,0x12,
0x04,0xDB,0x90,0x00,0x18,0xE0,0xFC,0xA3,
0xE0,0xFD,0x7F,0x00,0x7E,0x66,0x12,0x04,
0xDB,0x90,0x00,0x1A,0xE4,0xF0,0xA3,0x74,
0x64,0xF0,0x90,0x00,0x1A,0xE0,0x70,0x02,
0xA3,0xE0,0x60,0x2C,0x7F,0x00,0x7E,0x66,
0x12,0x04,0xF7,0xEE,0x30,0xE0,0x18,0x90,
0x00,0x1B,0xE0,0x24,0xFF,0xF0,0x90,0x00,
0x1A,0xE0,0x34,0xFF,0xF0,0xE0,0x70,0x02,
0xA3,0xE0,0x70,0xD6,0x7F,0xFF,0x22,0xE4,
0x90,0x00,0x1A,0xF0,0xA3,0xF0,0x80,0xCA,
0x7F,0x00,0x22,0xAB,0x07,0xAA,0x06,0x8A,
0xA2,0x00,0x8B,0xA3,0x00,0x8C,0xA4,0x00,
0x8D,0xA5,0x00,0x75,0xA0,0x03,0x00,0x00,
0xAA,0xA1,0x00,0xBA,0x00,0xF9,0x22,0xAD,
0x07,0xAC,0x06,0x8C,0xA2,0x00,0x8D,0xA3,
0x00,0x75,0xA0,0x01,0x00,0xAE,0xA1,0x00,
0xBE,0x00,0xF9,0x00,0xAE,0xA6,0x00,0xAF,
0xA7,0x22,0xEB,0x9F,0xF5,0xF0,0xEA,0x9E,
0x42,0xF0,0xE9,0x9D,0x42,0xF0,0xEC,0x64,
0x80,0xC8,0x64,0x80,0x98,0x45,0xF0,0x22,
0x78,0x7F,0xE4,0xF6,0xD8,0xFD,0x75,0x81,
0x09,0x02,0x03,0x4D,};
#endif /* #if CONFIG_TP_MODEL_EC220_G5sV1 */


#if 0
typedef enum init_state_e
{
    INIT_NOT_COMPLETED = 0,
    INIT_COMPLETED,
    INIT_STATE_END
} init_state_t;

typedef enum switch_chip_e
{
    CHIP_RTL8367C = 0,
    CHIP_RTL8370B,
    CHIP_RTL8364B,
    CHIP_END
}switch_chip_t;

typedef enum port_type_e
{
    UTP_PORT = 0,
    EXT_PORT,
    UNKNOWN_PORT = 0xFF,
    PORT_TYPE_END
}port_type_t;

typedef struct rtk_switch_halCtrl_s
{
    switch_chip_t   switch_type;
    rtk_uint32      l2p_port[RTK_SWITCH_PORT_NUM];
    rtk_uint32      p2l_port[RTK_SWITCH_PORT_NUM];
    port_type_t     log_port_type[RTK_SWITCH_PORT_NUM];
    rtk_uint32      ptp_port[RTK_SWITCH_PORT_NUM];
    rtk_uint32      valid_portmask;
    rtk_uint32      valid_utp_portmask;
    rtk_uint32      valid_ext_portmask;
#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    rtk_uint32      valid_cpu_portmask;
#endif
    rtk_uint32      min_phy_port;
    rtk_uint32      max_phy_port;
    rtk_uint32      phy_portmask;
    rtk_uint32      combo_logical_port;
    rtk_uint32      hsg_logical_port;
#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    rtk_uint32      sg_logical_portmask;
#endif
    rtk_uint32      max_meter_id;
    rtk_uint32      max_lut_addr_num;
    rtk_uint32      max_trunk_id;

}rtk_switch_halCtrl_t;

typedef struct  rtl8367c_rma_s{

    rtk_uint16 operation;
    rtk_uint16 discard_storm_filter;
    rtk_uint16 trap_priority;
    rtk_uint16 keep_format;
    rtk_uint16 vlan_leaky;
    rtk_uint16 portiso_leaky;

}rtl8367c_rma_t;

typedef enum rtk_port_phy_reg_e
{
    PHY_REG_CONTROL             = 0,
    PHY_REG_STATUS,
    PHY_REG_IDENTIFIER_1,
    PHY_REG_IDENTIFIER_2,
    PHY_REG_AN_ADVERTISEMENT,
    PHY_REG_AN_LINKPARTNER,
    PHY_REG_1000_BASET_CONTROL  = 9,
    PHY_REG_1000_BASET_STATUS,
    PHY_REG_END                 = 32
} rtk_port_phy_reg_t;


/*
 * ER-Telecom customized defind start
 */
#define RTL8367C_MIB_LEARNENTRYDISCARD_OFFSET   (0x420)
#define RTL8367C_MIB_PORT_OFFSET                (0x7C)
#define    RTL8367C_REG_MIB_ADDRESS             0x1004
#define    RTL8367C_REG_MIB_CTRL0               0x1005
#define    RTL8367C_MIB_CTRL_REG                RTL8367C_REG_MIB_CTRL0
#define    RTL8367C_MIB_CTRL0_BUSY_FLAG_MASK    0x1
#define    RTL8367C_RESET_FLAG_MASK             0x2
#define    RTL8367C_REG_MIB_COUNTER0            0x1000
#define    RTL8367C_MIB_COUNTER_BASE_REG        RTL8367C_REG_MIB_COUNTER0

#define    RTL8367C_GLOBAL_RESET_MASK    0x800
#define    RTL8367C_QM_RESET_MASK    0x400
#define    RTL8367C_PORT0_RESET_OFFSET    2
#define    RTL8367C_MIB_PORT07_MASK                                (0xFF<<RTL8367C_PORT0_RESET_OFFSET)
#define    RTL8367C_GLOBAL_RESET_OFFSET    11
#define    RTL8367C_QM_RESET_OFFSET    10



typedef rtk_u_long_t rtk_stat_counter_t; //unsigned long long, byte

/* port statistic counter index */
typedef enum rtk_stat_port_type_e
{
    STAT_IfInOctets = 0,
    STAT_Dot3StatsFCSErrors,
    STAT_Dot3StatsSymbolErrors,
    STAT_Dot3InPauseFrames,
    STAT_Dot3ControlInUnknownOpcodes,
    STAT_EtherStatsFragments,
    STAT_EtherStatsJabbers,
    STAT_IfInUcastPkts,
    STAT_EtherStatsDropEvents,
    STAT_EtherStatsOctets,
    STAT_EtherStatsUnderSizePkts,
    STAT_EtherOversizeStats,
    STAT_EtherStatsPkts64Octets,
    STAT_EtherStatsPkts65to127Octets,
    STAT_EtherStatsPkts128to255Octets,
    STAT_EtherStatsPkts256to511Octets,
    STAT_EtherStatsPkts512to1023Octets,
    STAT_EtherStatsPkts1024to1518Octets,
    STAT_EtherStatsMulticastPkts,
    STAT_EtherStatsBroadcastPkts,
    STAT_IfOutOctets,
    STAT_Dot3StatsSingleCollisionFrames,
    STAT_Dot3StatsMultipleCollisionFrames,
    STAT_Dot3StatsDeferredTransmissions,
    STAT_Dot3StatsLateCollisions,
    STAT_EtherStatsCollisions,
    STAT_Dot3StatsExcessiveCollisions,
    STAT_Dot3OutPauseFrames,
    STAT_Dot1dBasePortDelayExceededDiscards,
    STAT_Dot1dTpPortInDiscards,
    STAT_IfOutUcastPkts,
    STAT_IfOutMulticastPkts,
    STAT_IfOutBroadcastPkts,
    STAT_OutOampduPkts,
    STAT_InOampduPkts,
    STAT_PktgenPkts,
    STAT_InMldChecksumError,
    STAT_InIgmpChecksumError,
    STAT_InMldSpecificQuery,
    STAT_InMldGeneralQuery,
    STAT_InIgmpSpecificQuery,
    STAT_InIgmpGeneralQuery,
    STAT_InMldLeaves,
    STAT_InIgmpInterfaceLeaves,
    STAT_InIgmpJoinsSuccess,
    STAT_InIgmpJoinsFail,
    STAT_InMldJoinsSuccess,
    STAT_InMldJoinsFail,
    STAT_InReportSuppressionDrop,
    STAT_InLeaveSuppressionDrop,
    STAT_OutIgmpReports,
    STAT_OutIgmpLeaves,
    STAT_OutIgmpGeneralQuery,
    STAT_OutIgmpSpecificQuery,
    STAT_OutMldReports,
    STAT_OutMldLeaves,
    STAT_OutMldGeneralQuery,
    STAT_OutMldSpecificQuery,
    STAT_InKnownMulticastPkts,
    STAT_IfInMulticastPkts,
    STAT_IfInBroadcastPkts,
    STAT_IfOutDiscards,
    STAT_PORT_CNTR_END
}rtk_stat_port_type_t;
/*
 * ER-Telecom customized defind end
 */

/* enum Priority Selection Index */
typedef enum rtk_qos_priDecTbl_e
{
	PRIDECTBL_IDX0 = 0,
	PRIDECTBL_IDX1,
	PRIDECTBL_END,
}rtk_qos_priDecTbl_t;

typedef enum rtk_filter_invert_e
{
    FILTER_INVERT_DISABLE = 0,
    FILTER_INVERT_ENABLE,
    FILTER_INVERT_END,
} rtk_filter_invert_t;

typedef enum rtk_filter_act_enable_e
{
    /* CVLAN */
    FILTER_ENACT_CVLAN_INGRESS = 0,
    FILTER_ENACT_CVLAN_EGRESS,
    FILTER_ENACT_CVLAN_SVID,
    FILTER_ENACT_POLICING_1,

    /* SVLAN */
    FILTER_ENACT_SVLAN_INGRESS,
    FILTER_ENACT_SVLAN_EGRESS,
    FILTER_ENACT_SVLAN_CVID,
    FILTER_ENACT_POLICING_2,

    /* Policing and Logging */
    FILTER_ENACT_POLICING_0,

    /* Forward */
    FILTER_ENACT_COPY_CPU,
    FILTER_ENACT_DROP,
    FILTER_ENACT_ADD_DSTPORT,
    FILTER_ENACT_REDIRECT,
    FILTER_ENACT_MIRROR,
    FILTER_ENACT_TRAP_CPU,
    FILTER_ENACT_ISOLATION,

    /* QoS */
    FILTER_ENACT_PRIORITY,
    FILTER_ENACT_DSCP_REMARK,
    FILTER_ENACT_1P_REMARK,
    FILTER_ENACT_POLICING_3,

    /* Interrutp and GPO */
    FILTER_ENACT_INTERRUPT,
    FILTER_ENACT_GPO,

    /*VLAN tag*/
    FILTER_ENACT_EGRESSCTAG_UNTAG,
    FILTER_ENACT_EGRESSCTAG_TAG,
    FILTER_ENACT_EGRESSCTAG_KEEP,
    FILTER_ENACT_EGRESSCTAG_KEEPAND1PRMK,

    FILTER_ENACT_END,
} rtk_filter_act_enable_t;

typedef enum rtk_filter_care_tag_index_e
{
    CARE_TAG_CTAG = 0,
    CARE_TAG_STAG,
    CARE_TAG_PPPOE,
    CARE_TAG_IPV4,
    CARE_TAG_IPV6,
    CARE_TAG_TCP,
    CARE_TAG_UDP,
    CARE_TAG_ARP,
    CARE_TAG_RSV1,
    CARE_TAG_RSV2,
    CARE_TAG_ICMP,
    CARE_TAG_IGMP,
    CARE_TAG_LLC,
    CARE_TAG_RSV3,
    CARE_TAG_HTTP,
    CARE_TAG_RSV4,
    CARE_TAG_RSV5,
    CARE_TAG_DHCP,
    CARE_TAG_DHCPV6,
    CARE_TAG_SNMP,
    CARE_TAG_OAM,
    CARE_TAG_END,
} rtk_filter_care_tag_index_t;

enum ACLTCAMTYPES
{
	CAREBITS= 0,
	DATABITS
};

enum FIELDSEL_FORMAT_FORMAT
{
    FIELDSEL_FORMAT_DEFAULT = 0,
    FIELDSEL_FORMAT_RAW,
	FIELDSEL_FORMAT_LLC,
	FIELDSEL_FORMAT_IPV4,
	FIELDSEL_FORMAT_ARP,
	FIELDSEL_FORMAT_IPV6,
	FIELDSEL_FORMAT_IPPAYLOAD,
	FIELDSEL_FORMAT_L4PAYLOAD,
    FIELDSEL_FORMAT_END
};

#define RTL8367C_DECISIONPRIMAX    0xFF

/* enum Priority Selection Types */
enum PRIDECISION
{
	PRIDEC_PORT = 0,
	PRIDEC_ACL,
	PRIDEC_DSCP,
	PRIDEC_1Q,
	PRIDEC_1AD,
	PRIDEC_CVLAN,
	PRIDEC_DA,
	PRIDEC_SA,
	PRIDEC_END,
};

/* enum Priority Selection Index */
enum RTL8367C_PRIDEC_TABLE
{
	PRIDEC_IDX0 = 0,
	PRIDEC_IDX1,
	PRIDEC_IDX_END,
};

enum FLOW_CONTROL_TYPE
{
    FC_EGRESS = 0,
    FC_INGRESS,
};

/* enum for queue type */
enum QUEUETYPE
{
	QTYPE_STRICT = 0,
	QTYPE_WFQ,
};


typedef enum rtk_filter_field_type_e
{
    FILTER_FIELD_DMAC = 0,
    FILTER_FIELD_SMAC,
    FILTER_FIELD_ETHERTYPE,
    FILTER_FIELD_CTAG,
    FILTER_FIELD_STAG,

    FILTER_FIELD_IPV4_SIP,
    FILTER_FIELD_IPV4_DIP,
    FILTER_FIELD_IPV4_TOS,
    FILTER_FIELD_IPV4_PROTOCOL,
    FILTER_FIELD_IPV4_FLAG,
    FILTER_FIELD_IPV4_OFFSET,
    FILTER_FIELD_IPV6_SIPV6,
    FILTER_FIELD_IPV6_DIPV6,
    FILTER_FIELD_IPV6_TRAFFIC_CLASS,
    FILTER_FIELD_IPV6_NEXT_HEADER,

    FILTER_FIELD_TCP_SPORT,
    FILTER_FIELD_TCP_DPORT,
    FILTER_FIELD_TCP_FLAG,
    FILTER_FIELD_UDP_SPORT,
    FILTER_FIELD_UDP_DPORT,
    FILTER_FIELD_ICMP_CODE,
    FILTER_FIELD_ICMP_TYPE,
    FILTER_FIELD_IGMP_TYPE,

    FILTER_FIELD_VID_RANGE,
    FILTER_FIELD_IP_RANGE,
    FILTER_FIELD_PORT_RANGE,

    FILTER_FIELD_USER_DEFINED00,
    FILTER_FIELD_USER_DEFINED01,
    FILTER_FIELD_USER_DEFINED02,
    FILTER_FIELD_USER_DEFINED03,
    FILTER_FIELD_USER_DEFINED04,
    FILTER_FIELD_USER_DEFINED05,
    FILTER_FIELD_USER_DEFINED06,
    FILTER_FIELD_USER_DEFINED07,
    FILTER_FIELD_USER_DEFINED08,
    FILTER_FIELD_USER_DEFINED09,
    FILTER_FIELD_USER_DEFINED10,
    FILTER_FIELD_USER_DEFINED11,
    FILTER_FIELD_USER_DEFINED12,
    FILTER_FIELD_USER_DEFINED13,
    FILTER_FIELD_USER_DEFINED14,
    FILTER_FIELD_USER_DEFINED15,

    FILTER_FIELD_PATTERN_MATCH,

    FILTER_FIELD_END,
} rtk_filter_field_type_t;


enum ACLFIELDTYPES
{
	ACL_UNUSED,
	ACL_DMAC0,
	ACL_DMAC1,
	ACL_DMAC2,
	ACL_SMAC0,
	ACL_SMAC1,
	ACL_SMAC2,
	ACL_ETHERTYPE,
	ACL_STAG,
	ACL_CTAG,
	ACL_IP4SIP0 = 0x10,
	ACL_IP4SIP1,
	ACL_IP4DIP0,
	ACL_IP4DIP1,
	ACL_IP6SIP0WITHIPV4 = 0x20,
	ACL_IP6SIP1WITHIPV4,
	ACL_IP6DIP0WITHIPV4 = 0x28,
	ACL_IP6DIP1WITHIPV4,
	ACL_VIDRANGE = 0x30,
	ACL_IPRANGE,
	ACL_PORTRANGE,
	ACL_FIELD_VALID,
	ACL_FIELD_SELECT00 = 0x40,
	ACL_FIELD_SELECT01,
	ACL_FIELD_SELECT02,
	ACL_FIELD_SELECT03,
	ACL_FIELD_SELECT04,
	ACL_FIELD_SELECT05,
	ACL_FIELD_SELECT06,
	ACL_FIELD_SELECT07,
	ACL_FIELD_SELECT08,
	ACL_FIELD_SELECT09,
	ACL_FIELD_SELECT10,
	ACL_FIELD_SELECT11,
	ACL_FIELD_SELECT12,
	ACL_FIELD_SELECT13,
	ACL_FIELD_SELECT14,
	ACL_FIELD_SELECT15,
	ACL_TCPSPORT = 0x80,
	ACL_TCPDPORT,
	ACL_TCPFLAG,
	ACL_UDPSPORT,
	ACL_UDPDPORT,
	ACL_ICMPCODETYPE,
	ACL_IGMPTYPE,
	ACL_SPORT,
	ACL_DPORT,
	ACL_IP4TOSPROTO,
	ACL_IP4FLAGOFF,
	ACL_TCNH,
	ACL_CPUTAG,
	ACL_L2PAYLOAD,
	ACL_IP6SIP0,
	ACL_IP6SIP1,
	ACL_IP6SIP2,
	ACL_IP6SIP3,
	ACL_IP6SIP4,
	ACL_IP6SIP5,
	ACL_IP6SIP6,
	ACL_IP6SIP7,
	ACL_IP6DIP0,
	ACL_IP6DIP1,
	ACL_IP6DIP2,
	ACL_IP6DIP3,
	ACL_IP6DIP4,
	ACL_IP6DIP5,
	ACL_IP6DIP6,
	ACL_IP6DIP7,
	ACL_TYPE_END
};

typedef enum rtk_filter_field_data_type_e
{
    FILTER_FIELD_DATA_MASK = 0,
    FILTER_FIELD_DATA_RANGE,
    FILTER_FIELD_DATA_END ,
} rtk_filter_field_data_type_t;

#define FILTER_ENACT_CVLAN_MASK         0x01
#define FILTER_ENACT_SVLAN_MASK         0x02
#define FILTER_ENACT_PRIORITY_MASK    	0x04
#define FILTER_ENACT_POLICING_MASK    	0x08
#define FILTER_ENACT_FWD_MASK    		0x10
#define FILTER_ENACT_INTGPIO_MASK    	0x20
#define FILTER_ENACT_INIT_MASK			0x3F


#define FILTER_ENACT_CVLAN_TYPE(type)	(type - FILTER_ENACT_CVLAN_INGRESS)
#define FILTER_ENACT_SVLAN_TYPE(type)	(type - FILTER_ENACT_SVLAN_INGRESS)
#define FILTER_ENACT_FWD_TYPE(type)		(type - FILTER_ENACT_ADD_DSTPORT)
#define FILTER_ENACT_PRI_TYPE(type)		(type - FILTER_ENACT_PRIORITY)


typedef rtk_uint32  rtk_port_phy_data_t;     /* phy page  */

typedef struct  rtk_vlan_cfg_s
{
	rtk_portmask_t 	mbr;
    rtk_portmask_t 	untag;
    rtk_uint16      ivl_en;
    rtk_uint16      fid_msti;
    rtk_uint16      envlanpol;
    rtk_uint16      meteridx;
    rtk_uint16      vbpen;
    rtk_uint16      vbpri;
}rtk_vlan_cfg_t;

typedef struct  VLANCONFIGUSER
{
    rtk_uint16 	evid;
	rtk_uint16 	mbr;
    rtk_uint16  fid_msti;
    rtk_uint16  envlanpol;
    rtk_uint16  meteridx;
    rtk_uint16  vbpen;
    rtk_uint16  vbpri;
}rtl8367c_vlanconfiguser;

typedef struct  USER_VLANTABLE{

	rtk_uint16 	vid;
	rtk_uint16 	mbr;
 	rtk_uint16 	untag;
    rtk_uint16  fid_msti;
    rtk_uint16  envlanpol;
    rtk_uint16  meteridx;
    rtk_uint16  vbpen;
    rtk_uint16  vbpri;
	rtk_uint16 	ivl_svl;

}rtl8367c_user_vlan4kentry;

typedef struct LUTTABLE{

	ipaddr_t sip;
	ipaddr_t dip;
	ether_addr_t mac;
	rtk_uint16 ivl_svl:1;
	rtk_uint16 cvid_fid:12;
	rtk_uint16 fid:4;
	rtk_uint16 efid:3;

	rtk_uint16 nosalearn:1;
	rtk_uint16 da_block:1;
	rtk_uint16 sa_block:1;
	rtk_uint16 auth:1;
	rtk_uint16 lut_pri:3;
	rtk_uint16 sa_en:1;
	rtk_uint16 fwd_en:1;
	rtk_uint16 mbr:11;
	rtk_uint16 spa:4;
	rtk_uint16 age:3;
	rtk_uint16 l3lookup:1;
	rtk_uint16 igmp_asic:1;
	rtk_uint16 igmpidx:8;

	rtk_uint16 lookup_hit:1;
	rtk_uint16 lookup_busy:1;
	rtk_uint16 address:13;

    rtk_uint16 l3vidlookup:1;
	rtk_uint16 l3_vid:12;

    rtk_uint16 wait_time;

}rtl8367c_luttb;

typedef struct rtk_l2_ucastAddr_s
{
    rtk_mac_t       mac;
    rtk_uint32      ivl;
    rtk_uint32      cvid;
    rtk_uint32      fid;
    rtk_uint32      efid;
    rtk_uint32      port;
    rtk_uint32      sa_block;
    rtk_uint32      da_block;
    rtk_uint32      auth;
    rtk_uint32      is_static;
    rtk_uint32      priority;
    rtk_uint32      sa_pri_en;
    rtk_uint32      fwd_pri_en;
    rtk_uint32      address;
}rtk_l2_ucastAddr_t;

/* l2 address table - ip multicast data structure */
typedef struct rtk_l2_ipMcastAddr_s
{
    ipaddr_t        dip;
    ipaddr_t        sip;
    rtk_portmask_t  portmask;
    rtk_uint32      priority;
    rtk_uint32      fwd_pri_en;
    rtk_uint32      igmp_asic;
    rtk_uint32      igmp_index;
    rtk_uint32      address;
}rtk_l2_ipMcastAddr_t;

/* l2 address table - ip VID multicast data structure */
typedef struct rtk_l2_ipVidMcastAddr_s
{
    ipaddr_t        dip;
    ipaddr_t        sip;
    rtk_uint32      vid;
    rtk_portmask_t  portmask;
    rtk_uint32      address;
}rtk_l2_ipVidMcastAddr_t;

struct acl_rule_smi_st{
    rtk_uint16 rule_info;
	rtk_uint16 field[RTL8367C_ACLRULEFIELDNO];
};

struct acl_rule_smi_ext_st{
    rtk_uint16 rule_info;
};

typedef struct ACLRULESMI{
	struct acl_rule_smi_st	care_bits;
	rtk_uint16		valid:1;
	struct acl_rule_smi_st	data_bits;

	struct acl_rule_smi_ext_st care_bits_ext;
	struct acl_rule_smi_ext_st data_bits_ext;
}rtl8367c_aclrulesmi;

struct acl_rule_st{
	rtk_uint16 active_portmsk:11;
	rtk_uint16 type:3;
	rtk_uint16 tag_exist:5;
	rtk_uint16 field[RTL8367C_ACLRULEFIELDNO];
};

typedef struct ACLRULE{
	struct acl_rule_st	data_bits;
	rtk_uint16		valid:1;
	struct acl_rule_st	care_bits;
}rtl8367c_aclrule;

typedef struct rtl8367c_acltemplate_s{
	rtk_uint8 field[8];
}rtl8367c_acltemplate_t;

typedef struct acl_act_s{
	rtk_uint16 cvidx_cact:7;
	rtk_uint16 cact:2;
	rtk_uint16 svidx_sact:7;
	rtk_uint16 sact:2;


	rtk_uint16 aclmeteridx:7;
	rtk_uint16 fwdpmask:11;
	rtk_uint16 fwdact:2;

	rtk_uint16 pridx:7;
	rtk_uint16 priact:2;
	rtk_uint16 gpio_pin:4;
	rtk_uint16 gpio_en:1;
	rtk_uint16 aclint:1;

	rtk_uint16 cact_ext:2;
	rtk_uint16 fwdact_ext:1;
	rtk_uint16 tag_fmt:2;
}rtl8367c_acl_act_t;

typedef struct rtk_priority_select_s
{
    rtk_uint32 port_pri;
    rtk_uint32 dot1q_pri;
    rtk_uint32 acl_pri;
    rtk_uint32 dscp_pri;
    rtk_uint32 cvlan_pri;
    rtk_uint32 svlan_pri;
    rtk_uint32 dmac_pri;
    rtk_uint32 smac_pri;
} rtk_priority_select_t;

typedef struct rtk_qos_pri2queue_s
{
    rtk_uint32 pri2queue[RTK_MAX_NUM_OF_PRIORITY];
} rtk_qos_pri2queue_t;

typedef rtk_uint32  rtk_queue_num_t;    /* queue number*/

typedef struct rtk_qos_queue_weights_s
{
    rtk_uint32 weights[RTK_MAX_NUM_OF_QUEUE];
} rtk_qos_queue_weights_t;

typedef struct rtk_filter_mac_s
{
    rtk_uint32 dataType;
    rtk_mac_t value;
    rtk_mac_t mask;
    rtk_mac_t rangeStart;
    rtk_mac_t rangeEnd;
} rtk_filter_mac_t;

typedef struct rtk_filter_value_s
{
    rtk_uint32 dataType;
    rtk_uint32 value;
    rtk_uint32 mask;
    rtk_uint32 rangeStart;
    rtk_uint32 rangeEnd;

} rtk_filter_value_t;

typedef struct rtk_filter_flag_s
{
    rtk_uint32 value;
    rtk_uint32 mask;
} rtk_filter_flag_t;

typedef struct rtk_filter_tag_s
{
    rtk_filter_value_t pri;
    rtk_filter_flag_t cfi;
    rtk_filter_value_t vid;
} rtk_filter_tag_t;

typedef struct
{
    rtk_uint32 value[RTK_DOT_1AS_TIMESTAMP_UNIT_IN_WORD_LENGTH];
} rtk_filter_dot1as_timestamp_t;

typedef struct rtk_filter_ip_s
{
    rtk_uint32 dataType;
    rtk_uint32 rangeStart;
    rtk_uint32 rangeEnd;
    rtk_uint32 value;
    rtk_uint32 mask;
} rtk_filter_ip_t;

typedef struct rtk_filter_ipFlag_s
{
    rtk_filter_flag_t xf;
    rtk_filter_flag_t mf;
    rtk_filter_flag_t df;
} rtk_filter_ipFlag_t;

typedef struct
{
    rtk_uint32 addr[RTK_IPV6_ADDR_WORD_LENGTH];
} rtk_filter_ip6_addr_t;

typedef struct
{
    rtk_uint32 dataType;
    rtk_filter_ip6_addr_t value;
    rtk_filter_ip6_addr_t mask;
    rtk_filter_ip6_addr_t rangeStart;
    rtk_filter_ip6_addr_t rangeEnd;
} rtk_filter_ip6_t;

typedef struct rtk_filter_tcpFlag_s
{
    rtk_filter_flag_t urg;
    rtk_filter_flag_t ack;
    rtk_filter_flag_t psh;
    rtk_filter_flag_t rst;
    rtk_filter_flag_t syn;
    rtk_filter_flag_t fin;
    rtk_filter_flag_t ns;
    rtk_filter_flag_t cwr;
    rtk_filter_flag_t ece;
} rtk_filter_tcpFlag_t;

#define ACL_RULE_CARETAG_MASK						0x1F
#define FILTER_PATTERN_MAX                          4

typedef struct rtk_filter_pattern_s
{
    rtk_uint32 value[FILTER_PATTERN_MAX];
    rtk_uint32 mask[FILTER_PATTERN_MAX];
} rtk_filter_pattern_t;

struct rtk_filter_field
{
    rtk_uint32 fieldType;

    union
    {
        /* L2 struct */
        rtk_filter_mac_t       dmac;
        rtk_filter_mac_t       smac;
        rtk_filter_value_t     etherType;
        rtk_filter_tag_t       ctag;
        rtk_filter_tag_t       relayCtag;
        rtk_filter_tag_t       stag;
        rtk_filter_tag_t       l2tag;
        rtk_filter_dot1as_timestamp_t dot1asTimeStamp;
        rtk_filter_mac_t       mac;

        /* L3 struct */
	    rtk_filter_ip_t      sip;
        rtk_filter_ip_t      dip;
        rtk_filter_ip_t      ip;
        rtk_filter_value_t   protocol;
        rtk_filter_value_t   ipTos;
        rtk_filter_ipFlag_t  ipFlag;
        rtk_filter_value_t   ipOffset;
	    rtk_filter_ip6_t     sipv6;
        rtk_filter_ip6_t     dipv6;
        rtk_filter_ip6_t     ipv6;
        rtk_filter_value_t   ipv6TrafficClass;
        rtk_filter_value_t   ipv6NextHeader;
        rtk_filter_value_t   flowLabel;

        /* L4 struct */
        rtk_filter_value_t   tcpSrcPort;
        rtk_filter_value_t   tcpDstPort;
        rtk_filter_tcpFlag_t tcpFlag;
        rtk_filter_value_t   tcpSeqNumber;
        rtk_filter_value_t   tcpAckNumber;
        rtk_filter_value_t   udpSrcPort;
        rtk_filter_value_t   udpDstPort;
        rtk_filter_value_t   icmpCode;
        rtk_filter_value_t   icmpType;
        rtk_filter_value_t   igmpType;

        /* pattern match */
        rtk_filter_pattern_t pattern;

        rtk_filter_value_t   inData;

	} filter_pattern_union;

    rtk_uint32 fieldTemplateNo;
    rtk_uint32 fieldTemplateIdx[RTK_FILTER_FIELD_USED_MAX];

    struct rtk_filter_field *next;
};

typedef struct rtk_filter_field rtk_filter_field_t;

typedef rtk_uint32  rtk_filter_id_t;    /* filter id type */

typedef rtk_uint32 rtk_filter_number_t;

typedef struct rtk_filter_care_tag_s
{
    rtk_filter_flag_t tagType[CARE_TAG_END];
} rtk_filter_care_tag_t;

typedef struct rtk_filter_activeport_s
{
    rtk_portmask_t value;
    rtk_portmask_t mask;

} rtk_filter_activeport_t;

typedef struct
{
    rtk_filter_field_t      *fieldHead;
    rtk_filter_care_tag_t   careTag;
    rtk_filter_activeport_t activeport;

    rtk_filter_invert_t     invert;
} rtk_filter_cfg_t;

#define FILTER_POLICING_MAX                         4

typedef struct
{
    rtk_filter_act_enable_t actEnable[FILTER_ENACT_END];

	/* CVLAN acton */
	rtk_uint32     	filterCvlanVid;
	rtk_uint32     	filterCvlanIdx;
	/* SVLAN action */
    rtk_uint32      filterSvlanVid;
    rtk_uint32      filterSvlanIdx;

	/* Policing action */
	rtk_uint32     	filterPolicingIdx[FILTER_POLICING_MAX];

	/* Forwarding action */
	rtk_portmask_t 	filterPortmask;

	/* QOS action */
    rtk_uint32      filterPriority;

	/*GPO*/
    rtk_uint32      filterPin;

} rtk_filter_action_t;
#endif


#if 0
#define RTK_MAX_METER_ID            (rtk_switch_maxMeterId_get())
#define RTK_METER_NUM               (RTK_MAX_METER_ID + 1)

typedef enum rtk_meter_type_e{
    METER_TYPE_KBPS = 0,    /* Kbps */
    METER_TYPE_PPS,         /* Packet per second */
    METER_TYPE_END
}rtk_meter_type_t;

enum RTL8367C_TABLE_ACCESS_OP
{
    TB_OP_READ = 0,
    TB_OP_WRITE
};

enum RTL8367C_TABLE_ACCESS_TARGET
{
    TB_TARGET_ACLRULE = 1,
    TB_TARGET_ACLACT,
    TB_TARGET_CVLAN,
    TB_TARGET_L2,
    TB_TARGET_IGMP_GROUP
};

typedef enum vlan_mbrCfgType_e
{
    MBRCFG_UNUSED = 0,
    MBRCFG_USED_BY_VLAN,
    MBRCFG_END
}vlan_mbrCfgType_t;

typedef enum
{
    EG_TAG_MODE_ORI = 0,
    EG_TAG_MODE_KEEP,
    EG_TAG_MODE_PRI_TAG,
    EG_TAG_MODE_REAL_KEEP,
    EG_TAG_MODE_END
} rtl8367c_egtagmode;

enum RTL8367C_LUTREADMETHOD{

	LUTREADMETHOD_MAC =0,
	LUTREADMETHOD_ADDRESS,
	LUTREADMETHOD_NEXT_ADDRESS,
	LUTREADMETHOD_NEXT_L2UC,
	LUTREADMETHOD_NEXT_L2MC,
	LUTREADMETHOD_NEXT_L3MC,
	LUTREADMETHOD_NEXT_L2L3MC,
	LUTREADMETHOD_NEXT_L2UCSPA,
};

typedef enum rtk_l2_ipmc_lookup_type_e
{
    LOOKUP_MAC = 0,
    LOOKUP_IP,
    LOOKUP_IP_VID,
    LOOKUP_END
} rtk_l2_ipmc_lookup_type_t;

enum RTL8367C_IGMP_MLD_PROTOCOL_OP
{
    PROTOCOL_OP_ASIC = 0,
    PROTOCOL_OP_FLOOD,
    PROTOCOL_OP_TRAP,
    PROTOCOL_OP_DROP,
    PROTOCOL_OP_END
};

typedef enum rtk_l2_read_method_e{

	READMETHOD_MAC = 0,
	READMETHOD_ADDRESS,
	READMETHOD_NEXT_ADDRESS,
	READMETHOD_NEXT_L2UC,
	READMETHOD_NEXT_L2MC,
	READMETHOD_NEXT_L3MC,
	READMETHOD_NEXT_L2L3MC,
	READMETHOD_NEXT_L2UCSPA,
    READMETHOD_END
}rtk_l2_read_method_t;
#endif

#ifdef CONFIG_X_TP_VLAN
/* vlan operation interface, add by wanghao  */
typedef enum MT7620PortType
{
	USER_PORT = 0,
	STACK_PORT,
	TRANSLATION_PORT,
	TRANSPARENT_PORT,
}MT7620PortType;

typedef enum vlanPurpose
{
	INTERNET_LAN = 0,
	IPTV_LAN,
	IPTV_MULTICAST_LAN,
	IPPHONE_LAN,
	VOIP_LAN,
	OTHER_LAN,
	LAN_END = 10,
	INTERNET_WAN,
	IPTV_WAN,
	IPTV_MULTICAST_WAN,
	IPPHONE_WAN,
	VOIP_WAN,
	OTHER_WAN,
}vlanPurpose;

typedef struct vlanInfo
{
	rtk_vlan_t vid;
	rtk_pri_t pri;
	rtk_uint8 untag;
	vlanPurpose vlanPurpose;
	rtk_uint32 portMap;
}vlanInfo_t;

typedef struct vlanHdr
{
	rtk_uint16 tpid;
	rtk_uint16 tci;
}vlanHdr_t;
/* add end  */
#endif

/**************************************************************************************************/
/*                                           VARIABLES                                            */
/**************************************************************************************************/
#if 0
static init_state_t    init_state = INIT_NOT_COMPLETED;

static rtk_switch_halCtrl_t rtl8367c_hal_Ctrl =
{
    /* Switch Chip */
    CHIP_RTL8367C,

    /* Logical to Physical */
#if defined(CONFIG_TP_MODEL_EC220_G5sV1) || defined(CONFIG_TP_MODEL_EC220_G5V2)
    {0, 1, 2, 3, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
#else
    {0, 1, 2, 3, 4, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
#endif
     6, 7, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF },

    /* Physical to Logical */
    {UTP_PORT0, UTP_PORT1, UTP_PORT2, UTP_PORT3, UTP_PORT4, UNDEFINE_PORT, EXT_PORT0, EXT_PORT1,
     UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT,
     UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT,
     UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT, UNDEFINE_PORT},

    /* Port Type */
    {UTP_PORT, UTP_PORT, UTP_PORT, UTP_PORT, UTP_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT,
     UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT,
     EXT_PORT, EXT_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT,
     UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT, UNKNOWN_PORT},

    /* PTP port */
#if defined(CONFIG_TP_MODEL_EC220_G5sV1) || defined(CONFIG_TP_MODEL_EC220_G5V2)
    {1, 1, 1, 1, 0, 0, 0, 0,
#else
    {1, 1, 1, 1, 1, 0, 0, 0,
#endif
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0 },

    /* Valid port mask */
#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    ( (0x1 << UTP_PORT0) | (0x1 << UTP_PORT1) | (0x1 << UTP_PORT2) | (0x1 << UTP_PORT3) | (0x1 << EXT_PORT0) | (0x1 << EXT_PORT1) ),
#else
    ( (0x1 << UTP_PORT0) | (0x1 << UTP_PORT1) | (0x1 << UTP_PORT2) | (0x1 << UTP_PORT3) | (0x1 << UTP_PORT4) | (0x1 << EXT_PORT0) | (0x1 << EXT_PORT1) ),
#endif

    /* Valid UTP port mask */
    ( (0x1 << UTP_PORT0) | (0x1 << UTP_PORT1) | (0x1 << UTP_PORT2) | (0x1 << UTP_PORT3) ),

    /* Valid EXT port mask */
    ( (0x1 << EXT_PORT0) | (0x1 << EXT_PORT1) ),

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    /* Valid CPU port mask */
    0x00,
#endif

    /* Minimum physical port number */
    0,

    /* Maxmum physical port number */
    7,

    /* Physical port mask */
    0xDF,

    /* Combo Logical port ID */
    4,

    /* HSG Logical port ID */
    EXT_PORT0,

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    /* SGMII Logical portmask */
    (0x1 << EXT_PORT0),
#endif

    /* Max Meter ID */
    31,

    /* MAX LUT Address Number */
    2112,

    /* MAX TRUNK ID */
    1
};

static rtk_switch_halCtrl_t *halCtrl = NULL;

static rtk_vlan_t           vlan_mbrCfgVid[RTL8367C_CVIDXNO];
static vlan_mbrCfgType_t    vlan_mbrCfgUsage[RTL8367C_CVIDXNO];


CONST_T rtk_uint8 filter_templateField[RTL8367C_ACLTEMPLATENO][RTL8367C_ACLRULEFIELDNO] = {
    {ACL_DMAC0,   			ACL_DMAC1, 		 	ACL_DMAC2, 	 		ACL_SMAC0,   		ACL_SMAC1, 			ACL_SMAC2, 			ACL_ETHERTYPE, 		ACL_FIELD_SELECT15},
    {ACL_IP4SIP0, 			ACL_IP4SIP1, 		ACL_IP4DIP0, 		ACL_IP4DIP1, 		ACL_FIELD_SELECT13, ACL_FIELD_SELECT14, ACL_FIELD_SELECT02, ACL_FIELD_SELECT15},
    {ACL_IP6SIP0WITHIPV4,	ACL_IP6SIP1WITHIPV4,ACL_FIELD_SELECT03, ACL_FIELD_SELECT04, ACL_FIELD_SELECT05,	ACL_FIELD_SELECT06, ACL_FIELD_SELECT07,	ACL_FIELD_SELECT08},
    {ACL_IP6DIP0WITHIPV4,	ACL_IP6DIP1WITHIPV4,ACL_FIELD_SELECT09, ACL_FIELD_SELECT10, ACL_FIELD_SELECT11,	ACL_FIELD_SELECT12, ACL_FIELD_SELECT13,	ACL_FIELD_SELECT14},
    {ACL_VIDRANGE,			ACL_IPRANGE, 		ACL_PORTRANGE,  	ACL_CTAG,  			ACL_STAG, 			ACL_FIELD_SELECT13, ACL_FIELD_SELECT14,	ACL_FIELD_SELECT15}
};

CONST_T rtk_uint8 filter_advanceCaretagField[RTL8367C_ACLTEMPLATENO][2] = {
    {TRUE,		7},
    {TRUE,		7},
    {FALSE,		0},
    {FALSE,		0},
    {TRUE,		7},
};


CONST_T rtk_uint8 filter_fieldTemplateIndex[FILTER_FIELD_END][RTK_FILTER_FIELD_USED_MAX] = {
	{0x00, 0x01,0x02},
	{0x03, 0x04,0x05},
	{0x06},
	{0x43},
	{0x44},
	{0x10, 0x11},
	{0x12, 0x13},
	{0x24},
	{0x25},
	{0x35},
	{0x35},
	{0x20, 0x21,0x22,0x23},
	{0x30, 0x31,0x32,0x33},
	{0x26},
	{0x27},
	{0x14},
	{0x15},
	{0x16},
	{0x14},
	{0x15},
	{0x14},
	{0x14},
	{0x14},

	{0x40},
	{0x41},
	{0x42},

	{0x14},
	{0x15},
	{0x16},
	{0x22},
	{0x23},
	{0x24},
	{0x25},
	{0x26},
	{0x27},
	{0x32},
	{0x33},
	{0x34},
	{0x35},
	{0x36},
	{0x37},
	{0x47},

    {0xFF} /* Pattern Match */
};

CONST_T rtk_uint8 filter_fieldSize[FILTER_FIELD_END] = {
    3, 3, 1, 1, 1,
    2, 2, 1, 1, 1, 1, 4, 4, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    8
};

CONST_T rtk_uint16 field_selector[RTL8367C_FIELDSEL_FORMAT_NUMBER][2] =
{
    {FIELDSEL_FORMAT_DEFAULT, 0},    /* Field Selector 0 */
    {FIELDSEL_FORMAT_DEFAULT, 0},    /* Field Selector 1 */
    {FIELDSEL_FORMAT_IPPAYLOAD, 12}, /* Field Selector 2 */
    {FIELDSEL_FORMAT_IPV6, 10},      /* Field Selector 3 */
    {FIELDSEL_FORMAT_IPV6, 8},       /* Field Selector 4 */
    {FIELDSEL_FORMAT_IPV4, 0},       /* Field Selector 5 */
    {FIELDSEL_FORMAT_IPV4, 8},       /* Field Selector 6 */
    {FIELDSEL_FORMAT_IPV6, 0},       /* Field Selector 7 */
    {FIELDSEL_FORMAT_IPV6, 6},       /* Field Selector 8 */
    {FIELDSEL_FORMAT_IPV6, 26},      /* Field Selector 9 */
    {FIELDSEL_FORMAT_IPV6, 24},      /* Field Selector 10 */
    {FIELDSEL_FORMAT_DEFAULT, 0},    /* Field Selector 11 */
    {FIELDSEL_FORMAT_IPV4, 6},       /* Field Selector 12 */
    {FIELDSEL_FORMAT_IPPAYLOAD, 0},  /* Field Selector 13 */
    {FIELDSEL_FORMAT_IPPAYLOAD, 2},  /* Field Selector 14 */
    {FIELDSEL_FORMAT_DEFAULT, 0}     /* Field Selector 15 */
};
#endif
#ifdef CONFIG_X_TP_VLAN
int vlanSetCtl(struct sock *sk, int cmd, void __user *user, unsigned int len);

static struct nf_sockopt_ops vlanOptSockopts = {
	.pf			= PF_INET,
	.set_optmin	= VLAN_SET,
	.set_optmax	= VLAN_SET_MAX + 1,
	.set		= vlanSetCtl,
};

rtk_uint32 vlanTableIndex = 0x0;

rtk_vlan_t iptvVlanID = 0;
rtk_pri_t iptvPriority = 0;
rtk_vlan_t multiCastVlanID = 0;
rtk_pri_t multiCastPriority = 0;
uint16_t *hwNatWanVid = NULL;
uint16_t wanVid = CONFIG_RA_HW_NAT_WAN_VLANID;
EXPORT_SYMBOL(hwNatWanVid);
EXPORT_SYMBOL(wanVid);
/* add end  */
#endif

#ifdef TP_AP_MODE
#define PHYRESET_SET 384
#define PHY_UP_PORT 				385
#define PHY_DOWN_PORT 				386
#define PHY_DELAY					387
#define PHYRESET_SET_MAX 388

int phySetCtl(struct sock *sk, int cmd, void __user *user, unsigned int len);

static struct nf_sockopt_ops phyOptSockopts = {
	.pf = PF_INET,
	.set_optmin = PHYRESET_SET, 
	.set_optmax = PHYRESET_SET_MAX,
	.set = phySetCtl,
};
#endif

#if 0
extern ret_t rtl8367c_setAsicReg(rtk_uint32 reg, rtk_uint32 value);
extern ret_t rtl8367c_getAsicReg(rtk_uint32 reg, rtk_uint32 *pValue);
#endif

/**************************************************************************************************/
/*                                           LOCAL_FUNCTIONS                                      */
/**************************************************************************************************/

#if 0
u32 rtl_smi_write(u32 mAddrs, u32 rData)
{
    if(mAddrs > 0xFFFF)
        return RT_ERR_INPUT;

    if(rData > 0xFFFF)
        return RT_ERR_INPUT;
	
    /* Write address control code to register 31 */
    if(!mii_mgr_write(MDC_MDIO_PHY_ID, MDC_MDIO_CTRL0_REG, MDC_MDIO_ADDR_OP))
    {
    	return RT_ERR_SMI;
    }

    /* Write address to register 23 */
    if(!mii_mgr_write(MDC_MDIO_PHY_ID, MDC_MDIO_ADDRESS_REG, mAddrs))
    {
    	return RT_ERR_SMI;
    }

    /* Write data to register 24 */
    if(!mii_mgr_write(MDC_MDIO_PHY_ID, MDC_MDIO_DATA_WRITE_REG, rData))
    {
    	return RT_ERR_SMI;
    }

    /* Write data control code to register 21 */
    if(!mii_mgr_write(MDC_MDIO_PHY_ID, MDC_MDIO_CTRL1_REG, MDC_MDIO_WRITE_OP))
    {
    	return RT_ERR_SMI;
    }
	
	return RT_ERR_OK;
}
#endif
u32 rtl_smi_read(u32 mAddrs, u32* rData)
{
    if(mAddrs > 0xFFFF)
        return RT_ERR_INPUT;

    if(rData == NULL)
        return RT_ERR_NULL_POINTER;
	
    /* Write address control code to register 31 */
    if(!mii_mgr_write(MDC_MDIO_PHY_ID, MDC_MDIO_CTRL0_REG, MDC_MDIO_ADDR_OP))
    {
    	return RT_ERR_SMI;
    }

    /* Write address to register 23 */
    if(!mii_mgr_write(MDC_MDIO_PHY_ID, MDC_MDIO_ADDRESS_REG, mAddrs))
    {
    	return RT_ERR_SMI;
    }

    /* Write read control code to register 21 */
    if(!mii_mgr_write(MDC_MDIO_PHY_ID, MDC_MDIO_CTRL1_REG, MDC_MDIO_READ_OP))
    {
    	return RT_ERR_SMI;
    }

    /* Read data from register 25 */
    if(!mii_mgr_read(MDC_MDIO_PHY_ID, MDC_MDIO_DATA_READ_REG, rData))
    {
    	return RT_ERR_SMI;
    }
	
	return RT_ERR_OK;
}
#if 0



/* Function Name:
 *      rtl8367c_setAsicRegBit
 * Description:
 *      Set a bit value of a specified register
 * Input:
 *      reg 	- register's address
 *      bit 	- bit location
 *      value 	- value to set. It can be value 0 or 1.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_INPUT  	- Invalid input parameter
 * Note:
 *      Set a bit of a specified register to 1 or 0.
 */
ret_t rtl8367c_setAsicRegBit(rtk_uint32 reg, rtk_uint32 bit, rtk_uint32 value)
{
	rtk_uint32 regData;
	ret_t retVal;

	if(bit >= RTL8367C_REGBITLENGTH)
		return RT_ERR_INPUT;

	retVal = rtl_smi_read(reg, &regData);
	if(retVal != RT_ERR_OK)
		return RT_ERR_SMI;

	if(value)
		regData = regData | (1 << bit);
	else
		regData = regData & (~(1 << bit));

	retVal = rtl_smi_write(reg, regData);
	if(retVal != RT_ERR_OK)
		return RT_ERR_SMI;

	return RT_ERR_OK;
}
/* Function Name:
 *      rtl8367c_getAsicRegBit
 * Description:
 *      Get a bit value of a specified register
 * Input:
 *      reg 	- register's address
 *      bit 	- bit location
 *      value 	- value to get.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_INPUT  	- Invalid input parameter
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicRegBit(rtk_uint32 reg, rtk_uint32 bit, rtk_uint32 *pValue)
{
	rtk_uint32 regData;
	ret_t retVal;

	retVal = rtl_smi_read(reg, &regData);
	if(retVal != RT_ERR_OK)
		return RT_ERR_SMI;

	*pValue = (regData & (0x1 << bit)) >> bit;

	return RT_ERR_OK;
}
/* Function Name:
 *      rtl8367c_setAsicRegBits
 * Description:
 *      Set bits value of a specified register
 * Input:
 *      reg 	- register's address
 *      bits 	- bits mask for setting
 *      value 	- bits value for setting
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_INPUT  	- Invalid input parameter
 * Note:
 *      Set bits of a specified register to value. Both bits and value are be treated as bit-mask
 */
ret_t rtl8367c_setAsicRegBits(rtk_uint32 reg, rtk_uint32 bits, rtk_uint32 value)
{
	rtk_uint32 regData;
	ret_t retVal;
	rtk_uint32 bitsShift;
	rtk_uint32 valueShifted;

	if(bits >= (1 << RTL8367C_REGBITLENGTH) )
		return RT_ERR_INPUT;

	bitsShift = 0;
	while(!(bits & (1 << bitsShift)))
	{
		bitsShift++;
		if(bitsShift >= RTL8367C_REGBITLENGTH)
			return RT_ERR_INPUT;
	}
	valueShifted = value << bitsShift;

	if(valueShifted > RTL8367C_REGDATAMAX)
		return RT_ERR_INPUT;

	retVal = rtl_smi_read(reg, &regData);
	if(retVal != RT_ERR_OK)
		return RT_ERR_SMI;

	regData = regData & (~bits);
	regData = regData | (valueShifted & bits);

	retVal = rtl_smi_write(reg, regData);
	if(retVal != RT_ERR_OK)
		return RT_ERR_SMI;


	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_getAsicRegBits
 * Description:
 *      Get bits value of a specified register
 * Input:
 *      reg 	- register's address
 *      bits 	- bits mask for setting
 *      value 	- bits value for setting
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_INPUT  	- Invalid input parameter
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicRegBits(rtk_uint32 reg, rtk_uint32 bits, rtk_uint32 *pValue)
{
	rtk_uint32 regData;
	ret_t retVal;
	rtk_uint32 bitsShift;

	if(bits>= (1<<RTL8367C_REGBITLENGTH) )
		return RT_ERR_INPUT;

	bitsShift = 0;
	while(!(bits & (1 << bitsShift)))
	{
		bitsShift++;
		if(bitsShift >= RTL8367C_REGBITLENGTH)
			return RT_ERR_INPUT;
	}

	retVal = rtl_smi_read(reg, &regData);
	if(retVal != RT_ERR_OK) return RT_ERR_SMI;

	*pValue = (regData & bits) >> bitsShift;

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicReg
 * Description:
 *      Set content of asic register
 * Input:
 *      reg 	- register's address
 *      value 	- Value setting to register
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 * Note:
 *      The value will be set to ASIC mapping address only and it is always return RT_ERR_OK while setting un-mapping address registers
 */
ret_t rtl8367c_setAsicReg(rtk_uint32 reg, rtk_uint32 value)
{
	ret_t retVal;

	retVal = rtl_smi_write(reg, value);
	if(retVal != RT_ERR_OK)
		return RT_ERR_SMI;

	return RT_ERR_OK;
}
/* Function Name:
 *      rtl8367c_getAsicReg
 * Description:
 *      Get content of asic register
 * Input:
 *      reg 	- register's address
 *      value 	- Value setting to register
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 * Note:
 *      Value 0x0000 will be returned for ASIC un-mapping address
 */
ret_t rtl8367c_getAsicReg(rtk_uint32 reg, rtk_uint32 *pValue)
{
	rtk_uint32 regData;
	ret_t retVal;

	retVal = rtl_smi_read(reg, &regData);
	if(retVal != RT_ERR_OK)
		return RT_ERR_SMI;

	*pValue = regData;

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicPHYOCPReg
 * Description:
 *      Set PHY OCP registers
 * Input:
 *      phyNo 	- Physical port number (0~7)
 *      ocpAddr - OCP address
 *      ocpData - Writing data
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_PHY_REG_ID  		- invalid PHY address
 *      RT_ERR_PHY_ID  			- invalid PHY no
 *      RT_ERR_BUSYWAIT_TIMEOUT - PHY access busy
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPHYOCPReg(rtk_uint32 phyNo, rtk_uint32 ocpAddr, rtk_uint32 ocpData )
{
    ret_t retVal;
	rtk_uint32 regAddr;
    rtk_uint32 ocpAddrPrefix, ocpAddr9_6, ocpAddr5_1;

    /* OCP prefix */
    ocpAddrPrefix = ((ocpAddr & 0xFC00) >> 10);
    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_GPHY_OCP_MSB_0, RTL8367C_CFG_CPU_OCPADR_MSB_MASK, ocpAddrPrefix)) != RT_ERR_OK)
        return retVal;

    /*prepare access address*/
    ocpAddr9_6 = ((ocpAddr >> 6) & 0x000F);
    ocpAddr5_1 = ((ocpAddr >> 1) & 0x001F);
    regAddr = RTL8367C_PHY_BASE | (ocpAddr9_6 << 8) | (phyNo << RTL8367C_PHY_OFFSET) | ocpAddr5_1;
    if((retVal = rtl8367c_setAsicReg(regAddr, ocpData)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_getAsicPHYOCPReg
 * Description:
 *      Get PHY OCP registers
 * Input:
 *      phyNo 	- Physical port number (0~7)
 *      ocpAddr - PHY address
 *      pRegData - read data
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_PHY_REG_ID  		- invalid PHY address
 *      RT_ERR_PHY_ID  			- invalid PHY no
 *      RT_ERR_BUSYWAIT_TIMEOUT - PHY access busy
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicPHYOCPReg(rtk_uint32 phyNo, rtk_uint32 ocpAddr, rtk_uint32 *pRegData )
{
    ret_t retVal;
	rtk_uint32 regAddr;
    rtk_uint32 ocpAddrPrefix, ocpAddr9_6, ocpAddr5_1;

    /* OCP prefix */
    ocpAddrPrefix = ((ocpAddr & 0xFC00) >> 10);
    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_GPHY_OCP_MSB_0, RTL8367C_CFG_CPU_OCPADR_MSB_MASK, ocpAddrPrefix)) != RT_ERR_OK)
        return retVal;

    /*prepare access address*/
    ocpAddr9_6 = ((ocpAddr >> 6) & 0x000F);
    ocpAddr5_1 = ((ocpAddr >> 1) & 0x001F);
    regAddr = RTL8367C_PHY_BASE | (ocpAddr9_6 << 8) | (phyNo << RTL8367C_PHY_OFFSET) | ocpAddr5_1;
    if((retVal = rtl8367c_getAsicReg(regAddr, pRegData)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtl8367c_setAsicPHYReg
 * Description:
 *      Set PHY registers
 * Input:
 *      phyNo 	- Physical port number (0~7)
 *      phyAddr - PHY address (0~31)
 *      phyData - Writing data
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_PHY_REG_ID  		- invalid PHY address
 *      RT_ERR_PHY_ID  			- invalid PHY no
 *      RT_ERR_BUSYWAIT_TIMEOUT - PHY access busy
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPHYReg(rtk_uint32 phyNo, rtk_uint32 phyAddr, rtk_uint32 phyData )
{
    rtk_uint32 ocp_addr;

    if(phyAddr > RTL8367C_PHY_REGNOMAX)
        return RT_ERR_PHY_REG_ID;

    ocp_addr = 0xa400 + phyAddr*2;

    return rtl8367c_setAsicPHYOCPReg(phyNo, ocp_addr, phyData);
}
/* Function Name:
 *      rtl8367c_getAsicPHYReg
 * Description:
 *      Get PHY registers
 * Input:
 *      phyNo 	- Physical port number (0~7)
 *      phyAddr - PHY address (0~31)
 *      pRegData - Writing data
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_PHY_REG_ID  		- invalid PHY address
 *      RT_ERR_PHY_ID  			- invalid PHY no
 *      RT_ERR_BUSYWAIT_TIMEOUT - PHY access busy
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicPHYReg(rtk_uint32 phyNo, rtk_uint32 phyAddr, rtk_uint32 *pRegData )
{
	rtk_uint32 ocp_addr;

    if(phyAddr > RTL8367C_PHY_REGNOMAX)
        return RT_ERR_PHY_REG_ID;

    ocp_addr = 0xa400 + phyAddr*2;

    return rtl8367c_getAsicPHYOCPReg(phyNo, ocp_addr, pRegData);
}

/* Function Name:
 *      rtl8370_setAsicPortEnableAll
 * Description:
 *      Set ALL ports enable.
 * Input:
 *      enable - enable all ports.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 			- Success
 *      RT_ERR_SMI  		- SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortEnableAll(rtk_uint32 enable)
{
    if(enable >= 2)
        return RT_ERR_INPUT;

    return rtl8367c_setAsicRegBit(RTL8367C_REG_PHY_AD, RTL8367C_PDNPHY_OFFSET, !enable);
}

/* Function Name:
 *      rtl8367c_setAsicPortEgressRate
 * Description:
 *      Set per-port egress rate
 * Input:
 *      port 		- Physical port number (0~10)
 *      rate 		- Egress rate
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 			- Success
 *      RT_ERR_SMI  		- SMI access error
 *      RT_ERR_PORT_ID  	- Invalid port number
 *      RT_ERR_QOS_EBW_RATE - Invalid bandwidth/rate
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortEgressRate(rtk_uint32 port, rtk_uint32 rate)
{
    ret_t retVal;
    rtk_uint32 regAddr, regData;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    if(rate > RTL8367C_QOS_GRANULARTY_MAX)
        return RT_ERR_QOS_EBW_RATE;

    regAddr = RTL8367C_PORT_EGRESSBW_LSB_REG(port);
    regData = RTL8367C_QOS_GRANULARTY_LSB_MASK & rate;

    retVal = rtl8367c_setAsicReg(regAddr, regData);

    if(retVal != RT_ERR_OK)
        return retVal;

    regAddr = RTL8367C_PORT_EGRESSBW_MSB_REG(port);
    regData = (RTL8367C_QOS_GRANULARTY_MSB_MASK & rate) >> RTL8367C_QOS_GRANULARTY_MSB_OFFSET;

    retVal = rtl8367c_setAsicRegBits(regAddr, RTL8367C_PORT6_EGRESSBW_CTRL1_MASK, regData);

	return retVal;
}

/* Function Name:
 *      rtl8367c_setAsicPortEgressRateIfg
 * Description:
 *      Set per-port egress rate calculate include/exclude IFG
 * Input:
 *      ifg 	- 1:include IFG 0:exclude IFG
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortEgressRateIfg(rtk_uint32 ifg)
{
    ret_t retVal;

    retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SCHEDULE_WFQ_CTRL, RTL8367C_SCHEDULE_WFQ_CTRL_OFFSET, ifg);

	return retVal;
}

/* Function Name:
 *      rtl8367c_setAsicPortIngressBandwidth
 * Description:
 *      Set per-port total ingress bandwidth
 * Input:
 *      port 		- Physical port number (0~7)
 *      bandwidth 	- The total ingress bandwidth (unit: 8Kbps), 0x1FFFF:disable
 *      preifg 		- Include preamble and IFG, 0:Exclude, 1:Include
 *      enableFC 	- Action when input rate exceeds. 0: Drop	1: Flow Control
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 			- Success
 *      RT_ERR_SMI  		- SMI access error
 *      RT_ERR_PORT_ID  	- Invalid port number
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortIngressBandwidth(rtk_uint32 port, rtk_uint32 bandwidth, rtk_uint32 preifg, rtk_uint32 enableFC)
{
	ret_t retVal;
	rtk_uint32 regData;
	rtk_uint32 regAddr;

	/* Invalid input parameter */
	if(port >= RTL8367C_PORTNO)
		return RT_ERR_PORT_ID;

	if(bandwidth > RTL8367C_QOS_GRANULARTY_MAX)
		return RT_ERR_OUT_OF_RANGE;

	regAddr = RTL8367C_INGRESSBW_PORT_RATE_LSB_REG(port);
	regData = bandwidth & RTL8367C_QOS_GRANULARTY_LSB_MASK;
	retVal = rtl8367c_setAsicReg(regAddr, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	regAddr += 1;
	regData = (bandwidth & RTL8367C_QOS_GRANULARTY_MSB_MASK) >> RTL8367C_QOS_GRANULARTY_MSB_OFFSET;
	retVal = rtl8367c_setAsicRegBits(regAddr, RTL8367C_INGRESSBW_PORT0_RATE_CTRL1_INGRESSBW_RATE16_MASK, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	regAddr = RTL8367C_PORT_MISC_CFG_REG(port);
	retVal = rtl8367c_setAsicRegBit(regAddr, RTL8367C_PORT0_MISC_CFG_INGRESSBW_IFG_OFFSET, preifg);
	if(retVal != RT_ERR_OK)
		return retVal;

	regAddr = RTL8367C_PORT_MISC_CFG_REG(port);
	retVal = rtl8367c_setAsicRegBit(regAddr, RTL8367C_PORT0_MISC_CFG_INGRESSBW_FLOWCTRL_OFFSET, enableFC);
	if(retVal != RT_ERR_OK)
		return retVal;

	return RT_ERR_OK;
}


/* Function Name:
 *      rtl8367c_setAsicLutIpLookupMethod
 * Description:
 *      Set Lut IP lookup hash with DIP or {DIP,SIP} pair
 * Input:
 *      type - 1: When DIP can be found in IPMC_GROUP_TABLE, use DIP+SIP Hash, otherwise, use DIP+(SIP=0.0.0.0) Hash.
 *             0: When DIP can be found in IPMC_GROUP_TABLE, use DIP+(SIP=0.0.0.0) Hash, otherwise use DIP+SIP Hash.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicLutIpLookupMethod(rtk_uint32 type)
{
	return rtl8367c_setAsicRegBit(RTL8367C_REG_LUT_CFG, RTL8367C_LUT_IPMC_LOOKUP_OP_OFFSET, type);
}

/* Function Name:
 *      rtl8367c_setAsicPortMirrorIsolationTxLeaky
 * Description:
 *      Set the mirror function of Isolation TX leaky
 * Input:
 *      enabled 	- 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortMirrorIsolationTxLeaky(rtk_uint32 enabled)
{
	return rtl8367c_setAsicRegBit(RTL8367C_REG_MIRROR_CTRL2, RTL8367C_MIRROR_TX_ISOLATION_LEAKY_OFFSET, enabled);
}

/* Function Name:
 *      rtl8367c_setAsicRma
 * Description:
 *      Set reserved multicast address for CPU trapping
 * Input:
 *      index     - reserved multicast LSB byte, 0x00~0x2F is available value
 *      pRmacfg     - type of RMA for trapping frame type setting
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK         - Success
 *      RT_ERR_SMI      - SMI access error
 *      RT_ERR_RMA_ADDR - Invalid RMA address index
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicRma(rtk_uint32 index, rtl8367c_rma_t* pRmacfg)
{
    rtk_uint32 regData = 0;
    ret_t retVal;

    if(index > RTL8367C_RMAMAX)
        return RT_ERR_RMA_ADDR;

    regData |= (pRmacfg->portiso_leaky & 0x0001);
    regData |= ((pRmacfg->vlan_leaky & 0x0001) << 1);
    regData |= ((pRmacfg->keep_format & 0x0001) << 2);
    regData |= ((pRmacfg->trap_priority & 0x0007) << 3);
    regData |= ((pRmacfg->discard_storm_filter & 0x0001) << 6);
    regData |= ((pRmacfg->operation & 0x0003) << 7);

    if( (index >= 0x4 && index <= 0x7) || (index >= 0x9 && index <= 0x0C) || (0x0F == index))
        index = 0x04;
    else if((index >= 0x13 && index <= 0x17) || (0x19 == index) || (index >= 0x1B && index <= 0x1f))
        index = 0x13;
    else if(index >= 0x22 && index <= 0x2F)
        index = 0x22;

    retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_RMA_CTRL00, RTL8367C_TRAP_PRIORITY_MASK, pRmacfg->trap_priority);
    if(retVal != RT_ERR_OK)
        return retVal;

    return rtl8367c_setAsicReg(RTL8367C_REG_RMA_CTRL00+index, regData);
}

/* Function Name:
 *      rtl8367c_setAsicVlanEgressTagMode
 * Description:
 *      Set CVLAN egress tag mode
 * Input:
 *      port 		- Physical port number (0~10)
 *      tagMode 	- The egress tag mode. Including Original mode, Keep tag mode and Priority tag mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_INPUT  	- Invalid input parameter
 *      RT_ERR_PORT_ID  - Invalid port number
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicVlanEgressTagMode(rtk_uint32 port, rtl8367c_egtagmode tagMode)
{
    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    if(tagMode >= EG_TAG_MODE_END)
        return RT_ERR_INPUT;

    return rtl8367c_setAsicRegBits(RTL8367C_PORT_MISC_CFG_REG(port), RTL8367C_VLAN_EGRESS_MDOE_MASK, tagMode);
}

/* Function Name:
 *      rtl8367c_setAsicVlanIngressFilter
 * Description:
 *      Set VLAN Ingress Filter
 * Input:
 *      port 		- Physical port number (0~10)
 *      enabled 	- Enable or disable Ingress filter
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_PORT_ID  - Invalid port number
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicVlanIngressFilter(rtk_uint32 port, rtk_uint32 enabled)
{
    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    return rtl8367c_setAsicRegBit(RTL8367C_VLAN_INGRESS_REG, port, enabled);
}

/* Function Name:
 *      rtl8367c_setAsicVlanFilter
 * Description:
 *      Set enable CVLAN filtering function
 * Input:
 *      enabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicVlanFilter(rtk_uint32 enabled)
{
    return rtl8367c_setAsicRegBit(RTL8367C_REG_VLAN_CTRL, RTL8367C_VLAN_CTRL_OFFSET, enabled);
}

static void _rtl8367c_VlanMCStUser2Smi(rtl8367c_vlanconfiguser *pVlanCg, rtk_uint16 *pSmiVlanCfg)
{
    pSmiVlanCfg[0] |= pVlanCg->mbr & 0x07FF;

    pSmiVlanCfg[1] |= pVlanCg->fid_msti & 0x000F;

    pSmiVlanCfg[2] |= pVlanCg->vbpen & 0x0001;
    pSmiVlanCfg[2] |= (pVlanCg->vbpri & 0x0007) << 1;
    pSmiVlanCfg[2] |= (pVlanCg->envlanpol & 0x0001) << 4;
    pSmiVlanCfg[2] |= (pVlanCg->meteridx & 0x003F) << 5;

    pSmiVlanCfg[3] |= pVlanCg->evid & 0x1FFF;
}

static void _rtl8367c_VlanMCStSmi2User(rtk_uint16 *pSmiVlanCfg, rtl8367c_vlanconfiguser *pVlanCg)
{
	pVlanCg->mbr			= pSmiVlanCfg[0] & 0x07FF;
	pVlanCg->fid_msti		= pSmiVlanCfg[1] & 0x000F;
    pVlanCg->meteridx		= (pSmiVlanCfg[2] >> 5) & 0x003F;
	pVlanCg->envlanpol		= (pSmiVlanCfg[2] >> 4) & 0x0001;
	pVlanCg->vbpri			= (pSmiVlanCfg[2] >> 1) & 0x0007;
	pVlanCg->vbpen			= pSmiVlanCfg[2] & 0x0001;
    pVlanCg->evid			= pSmiVlanCfg[3] & 0x1FFF;
}

static void _rtl8367c_Vlan4kStUser2Smi(rtl8367c_user_vlan4kentry *pUserVlan4kEntry, rtk_uint16 *pSmiVlan4kEntry)
{
    pSmiVlan4kEntry[0] |= (pUserVlan4kEntry->mbr & 0x00FF);
    pSmiVlan4kEntry[0] |= (pUserVlan4kEntry->untag & 0x00FF) << 8;

    pSmiVlan4kEntry[1] |= (pUserVlan4kEntry->fid_msti & 0x000F);
    pSmiVlan4kEntry[1] |= (pUserVlan4kEntry->vbpen & 0x0001) << 4;
    pSmiVlan4kEntry[1] |= (pUserVlan4kEntry->vbpri & 0x0007) << 5;
    pSmiVlan4kEntry[1] |= (pUserVlan4kEntry->envlanpol & 0x0001) << 8;
    pSmiVlan4kEntry[1] |= (pUserVlan4kEntry->meteridx & 0x001F) << 9;
    pSmiVlan4kEntry[1] |= (pUserVlan4kEntry->ivl_svl & 0x0001) << 14;

    pSmiVlan4kEntry[2] |= ((pUserVlan4kEntry->mbr & 0x0700) >> 8);
    pSmiVlan4kEntry[2] |= ((pUserVlan4kEntry->untag & 0x0700) >> 8) << 3;
    pSmiVlan4kEntry[2] |= ((pUserVlan4kEntry->meteridx & 0x0020) >> 5) << 6;
}


static void _rtl8367c_Vlan4kStSmi2User(rtk_uint16 *pSmiVlan4kEntry, rtl8367c_user_vlan4kentry *pUserVlan4kEntry)
{
    pUserVlan4kEntry->mbr = (pSmiVlan4kEntry[0] & 0x00FF) | ((pSmiVlan4kEntry[2] & 0x0007) << 8);
    pUserVlan4kEntry->untag = ((pSmiVlan4kEntry[0] & 0xFF00) >> 8) | (((pSmiVlan4kEntry[2] & 0x0038) >> 3) << 8);
    pUserVlan4kEntry->fid_msti = pSmiVlan4kEntry[1] & 0x000F;
    pUserVlan4kEntry->vbpen = (pSmiVlan4kEntry[1] & 0x0010) >> 4;
    pUserVlan4kEntry->vbpri = (pSmiVlan4kEntry[1] & 0x00E0) >> 5;
    pUserVlan4kEntry->envlanpol = (pSmiVlan4kEntry[1] & 0x0100) >> 8;
    pUserVlan4kEntry->meteridx = ((pSmiVlan4kEntry[1] & 0x3E00) >> 9) | (((pSmiVlan4kEntry[2] & 0x0040) >> 6) << 5);
    pUserVlan4kEntry->ivl_svl = (pSmiVlan4kEntry[1] & 0x4000) >> 14;
}

static void _rtl8367c_fdbStUser2Smi( rtl8367c_luttb *pLutSt, rtk_uint16 *pFdbSmi)
{
    /* L3 lookup */
    if(pLutSt->l3lookup)
    {
        if(pLutSt->l3vidlookup)
        {
            pFdbSmi[0] = (pLutSt->sip & 0x0000FFFF);
            pFdbSmi[1] = (pLutSt->sip & 0xFFFF0000) >> 16;

            pFdbSmi[2] = (pLutSt->dip & 0x0000FFFF);
            pFdbSmi[3] = (pLutSt->dip & 0x0FFF0000) >> 16;

            pFdbSmi[3] |= (pLutSt->l3lookup & 0x0001) << 12;
            pFdbSmi[3] |= (pLutSt->l3vidlookup & 0x0001) << 13;
            pFdbSmi[3] |= ((pLutSt->mbr & 0x0300) >> 8) << 14;

            pFdbSmi[4] |= (pLutSt->mbr & 0x00FF);
            pFdbSmi[4] |= (pLutSt->l3_vid & 0x00FF) << 8;

            pFdbSmi[5] |= ((pLutSt->l3_vid & 0x0F00) >> 8);
            pFdbSmi[5] |= (pLutSt->nosalearn & 0x0001) << 5;
            pFdbSmi[5] |= ((pLutSt->mbr & 0x0400) >> 10) << 7;
        }
        else
        {
            pFdbSmi[0] = (pLutSt->sip & 0x0000FFFF);
            pFdbSmi[1] = (pLutSt->sip & 0xFFFF0000) >> 16;

            pFdbSmi[2] = (pLutSt->dip & 0x0000FFFF);
            pFdbSmi[3] = (pLutSt->dip & 0x0FFF0000) >> 16;

            pFdbSmi[3] |= (pLutSt->l3lookup & 0x0001) << 12;
            pFdbSmi[3] |= (pLutSt->l3vidlookup & 0x0001) << 13;
            pFdbSmi[3] |= ((pLutSt->mbr & 0x0300) >> 8) << 14;

            pFdbSmi[4] |= (pLutSt->mbr & 0x00FF);
            pFdbSmi[4] |= (pLutSt->igmpidx & 0x00FF) << 8;

            pFdbSmi[5] |= (pLutSt->igmp_asic & 0x0001);
            pFdbSmi[5] |= (pLutSt->lut_pri & 0x0007) << 1;
            pFdbSmi[5] |= (pLutSt->fwd_en & 0x0001) << 4;
            pFdbSmi[5] |= (pLutSt->nosalearn & 0x0001) << 5;
            pFdbSmi[5] |= ((pLutSt->mbr & 0x0400) >> 10) << 7;
        }
    }
    else if(pLutSt->mac.octet[0] & 0x01) /*Multicast L2 Lookup*/
    {
        pFdbSmi[0] |= pLutSt->mac.octet[5];
        pFdbSmi[0] |= pLutSt->mac.octet[4] << 8;

        pFdbSmi[1] |= pLutSt->mac.octet[3];
        pFdbSmi[1] |= pLutSt->mac.octet[2] << 8;

        pFdbSmi[2] |= pLutSt->mac.octet[1];
        pFdbSmi[2] |= pLutSt->mac.octet[0] << 8;

        pFdbSmi[3] |= pLutSt->cvid_fid;
        pFdbSmi[3] |= (pLutSt->l3lookup & 0x0001) << 12;
        pFdbSmi[3] |= (pLutSt->ivl_svl & 0x0001) << 13;
        pFdbSmi[3] |= ((pLutSt->mbr & 0x0300) >> 8) << 14;

        pFdbSmi[4] |= (pLutSt->mbr & 0x00FF);
        pFdbSmi[4] |= (pLutSt->igmpidx & 0x00FF) << 8;

        pFdbSmi[5] |= pLutSt->igmp_asic;
        pFdbSmi[5] |= (pLutSt->lut_pri & 0x0007) << 1;
        pFdbSmi[5] |= (pLutSt->fwd_en & 0x0001) << 4;
        pFdbSmi[5] |= (pLutSt->nosalearn & 0x0001) << 5;
        pFdbSmi[5] |= ((pLutSt->mbr & 0x0400) >> 10) << 7;
    }
    else /*Asic auto-learning*/
    {
        pFdbSmi[0] |= pLutSt->mac.octet[5];
        pFdbSmi[0] |= pLutSt->mac.octet[4] << 8;

        pFdbSmi[1] |= pLutSt->mac.octet[3];
        pFdbSmi[1] |= pLutSt->mac.octet[2] << 8;

        pFdbSmi[2] |= pLutSt->mac.octet[1];
        pFdbSmi[2] |= pLutSt->mac.octet[0] << 8;

        pFdbSmi[3] |= pLutSt->cvid_fid;
        pFdbSmi[3] |= (pLutSt->l3lookup & 0x0001) << 12;
        pFdbSmi[3] |= (pLutSt->ivl_svl & 0x0001) << 13;
        pFdbSmi[3] |= ((pLutSt->spa & 0x0008) >> 3) << 15;

        pFdbSmi[4] |= pLutSt->efid;
        pFdbSmi[4] |= (pLutSt->fid & 0x000F) << 3;
        pFdbSmi[4] |= (pLutSt->sa_en & 0x0001) << 7;
        pFdbSmi[4] |= (pLutSt->spa & 0x0007) << 8;
        pFdbSmi[4] |= (pLutSt->age & 0x0007) << 11;
        pFdbSmi[4] |= (pLutSt->auth & 0x0001) << 14;
        pFdbSmi[4] |= (pLutSt->sa_block & 0x0001) << 15;

        pFdbSmi[5] |= pLutSt->da_block;
        pFdbSmi[5] |= (pLutSt->lut_pri & 0x0007) << 1;
        pFdbSmi[5] |= (pLutSt->fwd_en & 0x0001) << 4;
        pFdbSmi[5] |= (pLutSt->nosalearn & 0x0001) << 5;
    }
}


static void _rtl8367c_fdbStSmi2User( rtl8367c_luttb *pLutSt, rtk_uint16 *pFdbSmi)
{
    /*L3 lookup*/
    if(pFdbSmi[3] & 0x1000)
    {
        if(pFdbSmi[3] & 0x2000)
        {
            pLutSt->sip            	= pFdbSmi[0] | (pFdbSmi[1] << 16);
            pLutSt->dip            	= pFdbSmi[2] | ((pFdbSmi[3] & 0x0FFF) << 16);

            pLutSt->mbr             = (pFdbSmi[4] & 0x00FF) | (((pFdbSmi[3] & 0xC000) >> 14) << 8) | (((pFdbSmi[5] & 0x0080) >> 7) << 10);
            pLutSt->l3_vid          = ((pFdbSmi[4] & 0xFF00) >> 8) | (pFdbSmi[5] & 0x000F);

            pLutSt->l3lookup        = (pFdbSmi[3] & 0x1000) >> 12;
            pLutSt->l3vidlookup     = (pFdbSmi[3] & 0x2000) >> 13;
            pLutSt->nosalearn       = (pFdbSmi[5] & 0x0020) >> 5;
        }
        else
        {
            pLutSt->sip            	= pFdbSmi[0] | (pFdbSmi[1] << 16);
            pLutSt->dip            	= pFdbSmi[2] | ((pFdbSmi[3] & 0x0FFF) << 16);

            pLutSt->lut_pri         = (pFdbSmi[5] & 0x000E) >> 1;
            pLutSt->fwd_en          = (pFdbSmi[5] & 0x0010) >> 4;

            pLutSt->mbr             = (pFdbSmi[4] & 0x00FF) | (((pFdbSmi[3] & 0xC000) >> 14) << 8) | (((pFdbSmi[5] & 0x0080) >> 7) << 10);
            pLutSt->igmpidx         = (pFdbSmi[4] & 0xFF00) >> 8;

            pLutSt->igmp_asic       = (pFdbSmi[5] & 0x0001);
            pLutSt->l3lookup        = (pFdbSmi[3] & 0x1000) >> 12;
            pLutSt->nosalearn       = (pFdbSmi[5] & 0x0020) >> 5;
        }
    }
    else if(pFdbSmi[2] & 0x0100) /*Multicast L2 Lookup*/
    {
        pLutSt->mac.octet[0]   	= (pFdbSmi[2] & 0xFF00) >> 8;
	 	pLutSt->mac.octet[1]   	= (pFdbSmi[2] & 0x00FF);
	 	pLutSt->mac.octet[2]   	= (pFdbSmi[1] & 0xFF00) >> 8;
	 	pLutSt->mac.octet[3]   	= (pFdbSmi[1] & 0x00FF);
	 	pLutSt->mac.octet[4]   	= (pFdbSmi[0] & 0xFF00) >> 8;
	 	pLutSt->mac.octet[5]   	= (pFdbSmi[0] & 0x00FF);

        pLutSt->cvid_fid       	= pFdbSmi[3] & 0x0FFF;
        pLutSt->lut_pri         = (pFdbSmi[5] & 0x000E) >> 1;
        pLutSt->fwd_en          = (pFdbSmi[5] & 0x0010) >> 4;

        pLutSt->mbr             = (pFdbSmi[4] & 0x00FF) | (((pFdbSmi[3] & 0xC000) >> 14) << 8) | (((pFdbSmi[5] & 0x0080) >> 7) << 10);
        pLutSt->igmpidx         = (pFdbSmi[4] & 0xFF00) >> 8;

        pLutSt->igmp_asic      	= (pFdbSmi[5] & 0x0001);
        pLutSt->l3lookup       	= (pFdbSmi[3] & 0x1000) >> 12;
        pLutSt->ivl_svl			= (pFdbSmi[3] & 0x2000) >> 13;
        pLutSt->nosalearn      	= (pFdbSmi[5] & 0x0020) >> 5;
    }
    else /*Asic auto-learning*/
    {
        pLutSt->mac.octet[0]   	= (pFdbSmi[2] & 0xFF00) >> 8;
	 	pLutSt->mac.octet[1]   	= (pFdbSmi[2] & 0x00FF);
	 	pLutSt->mac.octet[2]   	= (pFdbSmi[1] & 0xFF00) >> 8;
	 	pLutSt->mac.octet[3]   	= (pFdbSmi[1] & 0x00FF);
	 	pLutSt->mac.octet[4]   	= (pFdbSmi[0] & 0xFF00) >> 8;
	 	pLutSt->mac.octet[5]   	= (pFdbSmi[0] & 0x00FF);

		pLutSt->cvid_fid       	= pFdbSmi[3] & 0x0FFF;
        pLutSt->lut_pri         = (pFdbSmi[5] & 0x000E) >> 1;
        pLutSt->fwd_en          = (pFdbSmi[5] & 0x0010) >> 4;

		pLutSt->sa_en     		= (pFdbSmi[4] & 0x0080) >> 7;
		pLutSt->auth     		= (pFdbSmi[4] & 0x4000) >> 14;
		pLutSt->spa     		= ((pFdbSmi[4] & 0x0700) >> 8) | (((pFdbSmi[3] & 0x8000) >> 15) << 3);
		pLutSt->age     		= (pFdbSmi[4] & 0x3800) >> 11;
		pLutSt->fid     		= (pFdbSmi[4] & 0x0078) >> 3;
		pLutSt->efid     		= (pFdbSmi[4] & 0x0007);
        pLutSt->sa_block     	= (pFdbSmi[4] & 0x8000) >> 15;

		pLutSt->da_block     	= (pFdbSmi[5] & 0x0001);
		pLutSt->l3lookup     	= (pFdbSmi[3] & 0x1000) >> 12;
		pLutSt->ivl_svl			= (pFdbSmi[3] & 0x2000) >> 13;
		pLutSt->nosalearn     	= (pFdbSmi[3] & 0x0020) >> 5;
    }
}

/* Function Name:
 *      rtl8367c_setAsicVlanMemberConfig
 * Description:
 *      Set 32 VLAN member configurations
 * Input:
 *      index 		- VLAN member configuration index (0~31)
 *      pVlanCg - VLAN member configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 					- Success
 *      RT_ERR_SMI  				- SMI access error
 *      RT_ERR_INPUT  				- Invalid input parameter
 *      RT_ERR_L2_FID  				- Invalid FID
 *      RT_ERR_PORT_MASK  			- Invalid portmask
 *      RT_ERR_FILTER_METER_ID  	- Invalid meter
 *      RT_ERR_QOS_INT_PRIORITY  	- Invalid priority
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - Invalid VLAN member configuration index
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicVlanMemberConfig(rtk_uint32 index, rtl8367c_vlanconfiguser *pVlanCg)
{
	ret_t  retVal;
	rtk_uint32 regAddr;
	rtk_uint32 regData;
	rtk_uint16 *tableAddr;
    rtk_uint32 page_idx;
    rtk_uint16 smi_vlancfg[RTL8367C_VLAN_MBRCFG_LEN];

    /* Error Checking  */
	if(index > RTL8367C_CVIDXMAX)
        return RT_ERR_VLAN_ENTRY_NOT_FOUND;

    if(pVlanCg->evid > RTL8367C_EVIDMAX)
        return RT_ERR_INPUT;


    if(pVlanCg->mbr > RTL8367C_PORTMASK)
        return RT_ERR_PORT_MASK;

    if(pVlanCg->fid_msti > RTL8367C_FIDMAX)
        return RT_ERR_L2_FID;

    if(pVlanCg->meteridx > RTL8367C_METERMAX)
        return RT_ERR_FILTER_METER_ID;

    if(pVlanCg->vbpri > RTL8367C_PRIMAX)
        return RT_ERR_QOS_INT_PRIORITY;

    memset(smi_vlancfg, 0x00, sizeof(rtk_uint16) * RTL8367C_VLAN_MBRCFG_LEN);
    _rtl8367c_VlanMCStUser2Smi(pVlanCg, smi_vlancfg);
    tableAddr = smi_vlancfg;

    for(page_idx = 0; page_idx < 4; page_idx++)  /* 4 pages per VLAN Member Config */
    {
        regAddr = RTL8367C_VLAN_MEMBER_CONFIGURATION_BASE + (index * 4) + page_idx;
    	regData = *tableAddr;

    	retVal = rtl8367c_setAsicReg(regAddr, regData);
    	if(retVal != RT_ERR_OK)
            return retVal;

        tableAddr++;
    }

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_getAsicVlanMemberConfig
 * Description:
 *      Get 32 VLAN member configurations
 * Input:
 *      index 		- VLAN member configuration index (0~31)
 *      pVlanCg - VLAN member configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 					- Success
 *      RT_ERR_SMI  				- SMI access error
 *      RT_ERR_INPUT  				- Invalid input parameter
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - Invalid VLAN member configuration index
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicVlanMemberConfig(rtk_uint32 index, rtl8367c_vlanconfiguser *pVlanCg)
{
    ret_t  retVal;
    rtk_uint32 page_idx;
    rtk_uint32 regAddr;
    rtk_uint32 regData;
    rtk_uint16 *tableAddr;
    rtk_uint16 smi_vlancfg[RTL8367C_VLAN_MBRCFG_LEN];

    if(index > RTL8367C_CVIDXMAX)
		return RT_ERR_VLAN_ENTRY_NOT_FOUND;

    memset(smi_vlancfg, 0x00, sizeof(rtk_uint16) * RTL8367C_VLAN_MBRCFG_LEN);
    tableAddr  = smi_vlancfg;

    for(page_idx = 0; page_idx < 4; page_idx++)  /* 4 pages per VLAN Member Config */
    {
        regAddr = RTL8367C_VLAN_MEMBER_CONFIGURATION_BASE + (index * 4) + page_idx;

        retVal = rtl8367c_getAsicReg(regAddr, &regData);
        if(retVal != RT_ERR_OK)
            return retVal;

        *tableAddr = (rtk_uint16)regData;
        tableAddr++;
    }

    _rtl8367c_VlanMCStSmi2User(smi_vlancfg, pVlanCg);
    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicVlan4kEntry
 * Description:
 *      Set VID mapped entry to 4K VLAN table
 * Input:
 *      pVlan4kEntry - 4K VLAN configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 					- Success
 *      RT_ERR_SMI  				- SMI access error
 *      RT_ERR_INPUT  				- Invalid input parameter
 *      RT_ERR_L2_FID  				- Invalid FID
 *      RT_ERR_VLAN_VID 			- Invalid VID parameter (0~4095)
 *      RT_ERR_PORT_MASK  			- Invalid portmask
 *      RT_ERR_FILTER_METER_ID  	- Invalid meter
 *      RT_ERR_QOS_INT_PRIORITY  	- Invalid priority
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicVlan4kEntry(rtl8367c_user_vlan4kentry *pVlan4kEntry )
{
    rtk_uint16              vlan_4k_entry[RTL8367C_VLAN_4KTABLE_LEN];
	rtk_uint32					page_idx;
	rtk_uint16					*tableAddr;
	ret_t 					retVal;
	rtk_uint32 					regData;

    if(pVlan4kEntry->vid > RTL8367C_VIDMAX)
        return RT_ERR_VLAN_VID;

    if(pVlan4kEntry->mbr > RTL8367C_PORTMASK)
        return RT_ERR_PORT_MASK;

    if(pVlan4kEntry->untag > RTL8367C_PORTMASK)
        return RT_ERR_PORT_MASK;

    if(pVlan4kEntry->fid_msti > RTL8367C_FIDMAX)
        return RT_ERR_L2_FID;

    if(pVlan4kEntry->meteridx > RTL8367C_METERMAX)
        return RT_ERR_FILTER_METER_ID;

    if(pVlan4kEntry->vbpri > RTL8367C_PRIMAX)
        return RT_ERR_QOS_INT_PRIORITY;

    memset(vlan_4k_entry, 0x00, sizeof(rtk_uint16) * RTL8367C_VLAN_4KTABLE_LEN);
    _rtl8367c_Vlan4kStUser2Smi(pVlan4kEntry, vlan_4k_entry);

	/* Prepare Data */
	tableAddr = vlan_4k_entry;
	for(page_idx = 0; page_idx < RTL8367C_VLAN_4KTABLE_LEN; page_idx++)
	{
		regData = *tableAddr;
		retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_WRDATA_BASE + page_idx, regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		tableAddr++;
	}

	/* Write Address (VLAN_ID) */
	regData = pVlan4kEntry->vid;
	retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_ADDR_REG, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Write Command */
	retVal = rtl8367c_setAsicRegBits(RTL8367C_TABLE_ACCESS_CTRL_REG, RTL8367C_TABLE_TYPE_MASK | RTL8367C_COMMAND_TYPE_MASK,RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_WRITE,TB_TARGET_CVLAN));
	if(retVal != RT_ERR_OK)
		return retVal;

#if defined(CONFIG_RTL8367C_ASICDRV_TEST)
    memcpy(&Rtl8370sVirtualVlanTable[pVlan4kEntry->vid], pVlan4kEntry, sizeof(rtl8367c_user_vlan4kentry));
#endif

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_getAsicVlan4kEntry
 * Description:
 *      Get VID mapped entry to 4K VLAN table
 * Input:
 *      pVlan4kEntry - 4K VLAN configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_VLAN_VID 		- Invalid VID parameter (0~4095)
 *      RT_ERR_BUSYWAIT_TIMEOUT - LUT is busy at retrieving
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicVlan4kEntry(rtl8367c_user_vlan4kentry *pVlan4kEntry )
{
	rtk_uint16                  vlan_4k_entry[RTL8367C_VLAN_4KTABLE_LEN];
	rtk_uint32					page_idx;
	rtk_uint16					*tableAddr;
	ret_t 					    retVal;
	rtk_uint32 					regData;
    rtk_uint32                  busyCounter;

    if(pVlan4kEntry->vid > RTL8367C_VIDMAX)
        return RT_ERR_VLAN_VID;

    /* Polling status */
    busyCounter = RTL8367C_VLAN_BUSY_CHECK_NO;
	while(busyCounter)
	{
		retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_BUSY_FLAG_OFFSET,&regData);
		if(retVal != RT_ERR_OK)
	        return retVal;

		if(regData == 0)
			break;

		busyCounter --;
		if(busyCounter == 0)
			return RT_ERR_BUSYWAIT_TIMEOUT;
	}

	/* Write Address (VLAN_ID) */
	regData = pVlan4kEntry->vid;
	retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_ADDR_REG, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Read Command */
	retVal = rtl8367c_setAsicRegBits(RTL8367C_TABLE_ACCESS_CTRL_REG, RTL8367C_TABLE_TYPE_MASK | RTL8367C_COMMAND_TYPE_MASK, RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_READ,TB_TARGET_CVLAN));
	if(retVal != RT_ERR_OK)
		return retVal;

    /* Polling status */
    busyCounter = RTL8367C_VLAN_BUSY_CHECK_NO;
	while(busyCounter)
	{
		retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_BUSY_FLAG_OFFSET,&regData);
		if(retVal != RT_ERR_OK)
	        return retVal;

		if(regData == 0)
			break;

		busyCounter --;
		if(busyCounter == 0)
			return RT_ERR_BUSYWAIT_TIMEOUT;
	}

	/* Read VLAN data from register */
	tableAddr = vlan_4k_entry;
	for(page_idx = 0; page_idx < RTL8367C_VLAN_4KTABLE_LEN; page_idx++)
	{
		retVal = rtl8367c_getAsicReg(RTL8367C_TABLE_ACCESS_RDDATA_BASE + page_idx, &regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		*tableAddr = regData;
		tableAddr++;
	}

	_rtl8367c_Vlan4kStSmi2User(vlan_4k_entry, pVlan4kEntry);

#if defined(CONFIG_RTL8367C_ASICDRV_TEST)
    memcpy(pVlan4kEntry, &Rtl8370sVirtualVlanTable[pVlan4kEntry->vid], sizeof(rtl8367c_user_vlan4kentry));
#endif

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicVlanPortBasedVID
 * Description:
 *      Set port based VID which is indexed to 32 VLAN member configurations
 * Input:
 *      port 	- Physical port number (0~10)
 *      index 	- Index to VLAN member configuration
 *      pri 	- 1Q Port based VLAN priority
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 					- Success
 *      RT_ERR_SMI  				- SMI access error
 *      RT_ERR_PORT_ID  			- Invalid port number
 *      RT_ERR_QOS_INT_PRIORITY  	- Invalid priority
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - Invalid VLAN member configuration index
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicVlanPortBasedVID(rtk_uint32 port, rtk_uint32 index, rtk_uint32 pri)
{
    rtk_uint32 regAddr, bit_mask;
    ret_t  retVal;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    if(index > RTL8367C_CVIDXMAX)
        return RT_ERR_VLAN_ENTRY_NOT_FOUND;

    if(pri > RTL8367C_PRIMAX)
        return RT_ERR_QOS_INT_PRIORITY;

    regAddr = RTL8367C_VLAN_PVID_CTRL_REG(port);
    bit_mask = RTL8367C_PORT_VIDX_MASK(port);
    retVal = rtl8367c_setAsicRegBits(regAddr, bit_mask, index);
    if(retVal != RT_ERR_OK)
        return retVal;

    regAddr = RTL8367C_VLAN_PORTBASED_PRIORITY_REG(port);
    bit_mask = RTL8367C_VLAN_PORTBASED_PRIORITY_MASK(port);
    retVal = rtl8367c_setAsicRegBits(regAddr, bit_mask, pri);
    if(retVal != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtl8367c_setAsicL2LookupTb
 * Description:
 *      Set filtering database entry
 * Input:
 *      pL2Table 	- L2 table entry writing to 8K+64 filtering database
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicL2LookupTb(rtl8367c_luttb *pL2Table)
{
	ret_t retVal;
	rtk_uint32 regData;
	rtk_uint16 *accessPtr;
	rtk_uint32 i;
	rtk_uint16 smil2Table[RTL8367C_LUT_TABLE_SIZE];
	rtk_uint32 tblCmd;
    rtk_uint32 busyCounter;

	memset(smil2Table, 0x00, sizeof(rtk_uint16) * RTL8367C_LUT_TABLE_SIZE);
	_rtl8367c_fdbStUser2Smi(pL2Table, smil2Table);

    if(pL2Table->wait_time == 0)
    	busyCounter = RTL8367C_LUT_BUSY_CHECK_NO;
    else
        busyCounter = pL2Table->wait_time;

    while(busyCounter)
	{
		retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_BUSY_FLAG_OFFSET,&regData);
		if(retVal != RT_ERR_OK)
	        return retVal;

		pL2Table->lookup_busy = regData;
		if(!regData)
			break;

		busyCounter --;
		if(busyCounter == 0)
			return RT_ERR_BUSYWAIT_TIMEOUT;
	}

	accessPtr = smil2Table;
	regData = *accessPtr;
	for(i = 0; i < RTL8367C_LUT_ENTRY_SIZE; i++)
	{
		retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_WRDATA_BASE + i, regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		accessPtr ++;
		regData = *accessPtr;

	}

	tblCmd = (RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_WRITE,TB_TARGET_L2)) & (RTL8367C_TABLE_TYPE_MASK  | RTL8367C_COMMAND_TYPE_MASK);
	/* Write Command */
	retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_CTRL_REG, tblCmd);
	if(retVal != RT_ERR_OK)
		return retVal;

    if(pL2Table->wait_time == 0)
    	busyCounter = RTL8367C_LUT_BUSY_CHECK_NO;
    else
        busyCounter = pL2Table->wait_time;

    while(busyCounter)
	{
		retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_BUSY_FLAG_OFFSET,&regData);
		if(retVal != RT_ERR_OK)
	        return retVal;

		pL2Table->lookup_busy = regData;
		if(!regData)
			break;

		busyCounter --;
		if(busyCounter == 0)
			return RT_ERR_BUSYWAIT_TIMEOUT;
	}

    /*Read access status*/
	retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_HIT_STATUS_OFFSET, &regData);
	if(retVal != RT_ERR_OK)
        return retVal;

    pL2Table->lookup_hit = regData;
    if(!pL2Table->lookup_hit)
        return RT_ERR_FAILED;

    /*Read access address*/
    /*
	retVal = rtl8367c_getAsicRegBits(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_TYPE_MASK | RTL8367C_TABLE_LUT_ADDR_ADDRESS_MASK,&regData);
	if(retVal != RT_ERR_OK)
        return retVal;

    pL2Table->address = regData;*/

    retVal = rtl8367c_getAsicReg(RTL8367C_TABLE_ACCESS_STATUS_REG, &regData);
	if(retVal != RT_ERR_OK)
        return retVal;

    pL2Table->address = (regData & 0x7ff) | ((regData & 0x4000) >> 3) | ((regData & 0x800) << 1);
	pL2Table->lookup_busy = 0;

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_getAsicL2LookupTb
 * Description:
 *      Get filtering database entry
 * Input:
 *      pL2Table 	- L2 table entry writing to 2K+64 filtering database
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_INPUT  			- Invalid input parameter
 *      RT_ERR_BUSYWAIT_TIMEOUT - LUT is busy at retrieving
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicL2LookupTb(rtk_uint32 method, rtl8367c_luttb *pL2Table)
{
	ret_t retVal;
	rtk_uint32 regData;
	rtk_uint16* accessPtr;
	rtk_uint32 i;
    rtk_uint16 smil2Table[RTL8367C_LUT_TABLE_SIZE];
	rtk_uint32 busyCounter;
	rtk_uint32 tblCmd;

    if(pL2Table->wait_time == 0)
    	busyCounter = RTL8367C_LUT_BUSY_CHECK_NO;
    else
        busyCounter = pL2Table->wait_time;

 	while(busyCounter)
	{
		retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_BUSY_FLAG_OFFSET,&regData);
		if(retVal != RT_ERR_OK)
	        return retVal;

		pL2Table->lookup_busy = regData;
		if(!pL2Table->lookup_busy)
			break;

		busyCounter --;
		if(busyCounter == 0)
			return RT_ERR_BUSYWAIT_TIMEOUT;
	}


	tblCmd = (method << RTL8367C_ACCESS_METHOD_OFFSET) & RTL8367C_ACCESS_METHOD_MASK;

	switch(method)
	{
		case LUTREADMETHOD_ADDRESS:
		case LUTREADMETHOD_NEXT_ADDRESS:
		case LUTREADMETHOD_NEXT_L2UC:
		case LUTREADMETHOD_NEXT_L2MC:
		case LUTREADMETHOD_NEXT_L3MC:
		case LUTREADMETHOD_NEXT_L2L3MC:
	        retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_ADDR_REG, pL2Table->address);
	    	if(retVal != RT_ERR_OK)
	    		return retVal;
			break;
		case LUTREADMETHOD_MAC:
	    	memset(smil2Table, 0x00, sizeof(rtk_uint16) * RTL8367C_LUT_TABLE_SIZE);
            _rtl8367c_fdbStUser2Smi(pL2Table, smil2Table);

	    	accessPtr = smil2Table;
	    	regData = *accessPtr;
	    	for(i=0; i<RTL8367C_LUT_ENTRY_SIZE; i++)
	    	{
	    		retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_WRDATA_BASE + i, regData);
	    		if(retVal != RT_ERR_OK)
	    			return retVal;

	    		accessPtr ++;
	    		regData = *accessPtr;

	    	}
			break;
		case LUTREADMETHOD_NEXT_L2UCSPA:
	        retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_ADDR_REG, pL2Table->address);
	    	if(retVal != RT_ERR_OK)
	    		return retVal;

			tblCmd = tblCmd | ((pL2Table->spa << RTL8367C_TABLE_ACCESS_CTRL_SPA_OFFSET) & RTL8367C_TABLE_ACCESS_CTRL_SPA_MASK);

			break;
		default:
			return RT_ERR_INPUT;
	}

	tblCmd = tblCmd | ((RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_READ,TB_TARGET_L2)) & (RTL8367C_TABLE_TYPE_MASK  | RTL8367C_COMMAND_TYPE_MASK));
	/* Read Command */
	retVal = rtl8367c_setAsicReg(RTL8367C_TABLE_ACCESS_CTRL_REG, tblCmd);
	if(retVal != RT_ERR_OK)
		return retVal;

    if(pL2Table->wait_time == 0)
    	busyCounter = RTL8367C_LUT_BUSY_CHECK_NO;
    else
        busyCounter = pL2Table->wait_time;

	while(busyCounter)
	{
		retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_BUSY_FLAG_OFFSET,&regData);
		if(retVal != RT_ERR_OK)
	        return retVal;

		pL2Table->lookup_busy = regData;
		if(!pL2Table->lookup_busy)
			break;

		busyCounter --;
		if(busyCounter == 0)
			return RT_ERR_BUSYWAIT_TIMEOUT;
	}

	retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_HIT_STATUS_OFFSET,&regData);
	if(retVal != RT_ERR_OK)
        	return retVal;
	pL2Table->lookup_hit = regData;
	if(!pL2Table->lookup_hit)
        return RT_ERR_L2_ENTRY_NOTFOUND;

    /*Read access address*/
	//retVal = rtl8367c_getAsicRegBits(RTL8367C_TABLE_ACCESS_STATUS_REG, RTL8367C_TABLE_LUT_ADDR_TYPE_MASK | RTL8367C_TABLE_LUT_ADDR_ADDRESS_MASK,&regData);
	retVal = rtl8367c_getAsicReg(RTL8367C_TABLE_ACCESS_STATUS_REG, &regData);
	if(retVal != RT_ERR_OK)
        return retVal;

    pL2Table->address = (regData & 0x7ff) | ((regData & 0x4000) >> 3) | ((regData & 0x800) << 1);

	/*read L2 entry */
    memset(smil2Table, 0x00, sizeof(rtk_uint16) * RTL8367C_LUT_TABLE_SIZE);

	accessPtr = smil2Table;

	for(i = 0; i < RTL8367C_LUT_ENTRY_SIZE; i++)
	{
		retVal = rtl8367c_getAsicReg(RTL8367C_TABLE_ACCESS_RDDATA_BASE + i, &regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		*accessPtr = regData;

		accessPtr ++;
	}

	_rtl8367c_fdbStSmi2User(pL2Table, smil2Table);

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicLutIpMulticastLookup
 * Description:
 *      Set Lut IP multicast lookup function
 * Input:
 *      enabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicLutIpMulticastLookup(rtk_uint32 enabled)
{
	return rtl8367c_setAsicRegBit(RTL8367C_REG_LUT_CFG, RTL8367C_LUT_IPMC_HASH_OFFSET, enabled);
}

/* Function Name:
 *      rtl8367c_getAsicLutIpMulticastLookup
 * Description:
 *      Get Lut IP multicast lookup function
 * Input:
 *      pEnabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicLutIpMulticastLookup(rtk_uint32* pEnabled)
{
	return rtl8367c_getAsicRegBit(RTL8367C_REG_LUT_CFG, RTL8367C_LUT_IPMC_HASH_OFFSET, pEnabled);
}


/* Function Name:
 *      rtl8367c_setAsicLutIpMulticastLookup
 * Description:
 *      Set Lut IP multicast + VID lookup function
 * Input:
 *      enabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicLutIpMulticastVidLookup(rtk_uint32 enabled)
{
	return rtl8367c_setAsicRegBit(RTL8367C_REG_LUT_CFG2, RTL8367C_LUT_IPMC_VID_HASH_OFFSET, enabled);
}

/* Function Name:
 *      rtl8367c_getAsicLutIpMulticastVidLookup
 * Description:
 *      Get Lut IP multicast lookup function
 * Input:
 *      pEnabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicLutIpMulticastVidLookup(rtk_uint32* pEnabled)
{
	return rtl8367c_getAsicRegBit(RTL8367C_REG_LUT_CFG2, RTL8367C_LUT_IPMC_VID_HASH_OFFSET, pEnabled);
}

/* Function Name:
 *      rtl8367c_setAsicIGMPStaticRouterPort
 * Description:
 *      Set IGMP static router port mask
 * Input:
 *      pmsk 	- Static portmask
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 			- Success
 *      RT_ERR_SMI  		- SMI access error
 *      RT_ERR_PORT_MASK  	- Invalid port mask
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIGMPStaticRouterPort(rtk_uint32 pmsk)
{
    if(pmsk > RTL8367C_PORTMASK)
        return RT_ERR_PORT_MASK;

    return rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_STATIC_ROUTER_PORT, RTL8367C_IGMP_STATIC_ROUTER_PORT_MASK, pmsk);
}

/* Function Name:
 *      rtl8367c_getAsicIGMPStaticRouterPort
 * Description:
 *      Get IGMP static router port mask
 * Input:
 *      pmsk 	- Static portmask
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicIGMPStaticRouterPort(rtk_uint32 *pmsk)
{
    return rtl8367c_getAsicRegBits(RTL8367C_REG_IGMP_STATIC_ROUTER_PORT, RTL8367C_IGMP_STATIC_ROUTER_PORT_MASK, pmsk);
}

/* Function Name:
 *      rtl8367c_setAsicIGMPv1Opeartion
 * Description:
 *      Set port-based IGMPv1 Control packet action
 * Input:
 *      port            - port number
 *      igmpv1_op       - IGMPv1 control packet action
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	    - Success
 *      RT_ERR_PORT_ID  - Error PORT ID
 *      RT_ERR_SMI      - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIGMPv1Opeartion(rtk_uint32 port, rtk_uint32 igmpv1_op)
{
    ret_t   retVal;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    /* IGMPv1 operation */
    if(port < 8)
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT0_CONTROL + port, RTL8367C_IGMP_PORT0_CONTROL_IGMPV1_OP_MASK, igmpv1_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    else
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT8_CONTROL + port - 8, RTL8367C_IGMP_PORT0_CONTROL_IGMPV1_OP_MASK, igmpv1_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}


/* Function Name:
 *      rtl8367c_setAsicIGMPv2Opeartion
 * Description:
 *      Set port-based IGMPv2 Control packet action
 * Input:
 *      port            - port number
 *      igmpv2_op       - IGMPv2 control packet action
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	    - Success
 *      RT_ERR_PORT_ID  - Error PORT ID
 *      RT_ERR_SMI      - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIGMPv2Opeartion(rtk_uint32 port, rtk_uint32 igmpv2_op)
{
    ret_t   retVal;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    /* IGMPv2 operation */
    if(port < 8)
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT0_CONTROL + port, RTL8367C_IGMP_PORT0_CONTROL_IGMPV2_OP_MASK, igmpv2_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    else
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT8_CONTROL + port - 8, RTL8367C_IGMP_PORT0_CONTROL_IGMPV2_OP_MASK, igmpv2_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}


/* Function Name:
 *      rtl8367c_setAsicIGMPv3Opeartion
 * Description:
 *      Set port-based IGMPv3 Control packet action
 * Input:
 *      port            - port number
 *      igmpv3_op       - IGMPv3 control packet action
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	    - Success
 *      RT_ERR_PORT_ID  - Error PORT ID
 *      RT_ERR_SMI      - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIGMPv3Opeartion(rtk_uint32 port, rtk_uint32 igmpv3_op)
{
    ret_t   retVal;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    /* IGMPv3 operation */
    if(port < 8)
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT0_CONTROL + port, RTL8367C_IGMP_PORT0_CONTROL_IGMPV3_OP_MASK, igmpv3_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    else
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT8_CONTROL + port - 8, RTL8367C_IGMP_PORT0_CONTROL_IGMPV3_OP_MASK, igmpv3_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicMLDv1Opeartion
 * Description:
 *      Set port-based MLDv1 Control packet action
 * Input:
 *      port            - port number
 *      mldv1_op        - MLDv1 control packet action
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	    - Success
 *      RT_ERR_PORT_ID  - Error PORT ID
 *      RT_ERR_SMI      - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicMLDv1Opeartion(rtk_uint32 port, rtk_uint32 mldv1_op)
{
    ret_t   retVal;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    /* MLDv1 operation */
    if(port < 8)
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT0_CONTROL + port, RTL8367C_IGMP_PORT0_CONTROL_MLDv1_OP_MASK, mldv1_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    else
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT8_CONTROL + port - 8, RTL8367C_IGMP_PORT0_CONTROL_MLDv1_OP_MASK, mldv1_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicMLDv2Opeartion
 * Description:
 *      Set port-based MLDv2 Control packet action
 * Input:
 *      port            - port number
 *      mldv2_op        - MLDv2 control packet action
 * Output:
 *      none
 * Return:
 *      RT_ERR_OK 	    - Success
 *      RT_ERR_PORT_ID  - Error PORT ID
 *      RT_ERR_SMI      - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicMLDv2Opeartion(rtk_uint32 port, rtk_uint32 mldv2_op)
{
    ret_t   retVal;

    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    /* MLDv2 operation */
    if(port < 8)
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT0_CONTROL + port, RTL8367C_IGMP_PORT0_CONTROL_MLDv2_OP_MASK, mldv2_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    else
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_PORT8_CONTROL + port - 8, RTL8367C_IGMP_PORT0_CONTROL_MLDv2_OP_MASK, mldv2_op);
        if(retVal != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicIGMPAllowDynamicRouterPort
 * Description:
 *      Set IGMP dynamic router port allow mask
 * Input:
 *      pmsk 	- Allow dynamic router port mask
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 			- Success
 *      RT_ERR_SMI  		- SMI access error
 *      RT_ERR_PORT_MASK  	- Invalid port mask
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIGMPAllowDynamicRouterPort(rtk_uint32 pmsk)
{
    return rtl8367c_setAsicReg(RTL8367C_REG_IGMP_MLD_CFG4, pmsk);
}

/* Function Name:
 *      rtl8367c_setAsicIGMPFastLeaveEn
 * Description:
 *      Enable/Disable Fast Leave
 * Input:
 *      enabled - 1:enable Fast Leave; 0:disable Fast Leave
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIGMPFastLeaveEn(rtk_uint32 enabled)
{
    ret_t  retVal;

    /* Fast Leave */
    retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_MLD_CFG0, RTL8367C_FAST_LEAVE_EN_MASK, (enabled >= 1) ? 1 : 0);
    if(retVal != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicIGMPReportLeaveFlood
 * Description:
 *      Set IGMP/MLD Report/Leave flood
 * Input:
 *      flood 	- 0: Reserved, 1: flooding to router ports, 2: flooding to all ports, 3: flooding to router port or to all ports if there is no router port
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIGMPReportLeaveFlood(rtk_uint32 flood)
{
    ret_t   retVal;

    retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_IGMP_MLD_CFG3, RTL8367C_REPORT_LEAVE_FORWARD_MASK, flood);
    if(retVal != RT_ERR_OK)
		return retVal;

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicIgmp
 * Description:
 *      Set IGMP/MLD state
 * Input:
 *      enabled 	- 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicIgmp(rtk_uint32 enabled)
{
    ret_t retVal;

    /* Enable/Disable H/W IGMP/MLD */
    retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_IGMP_MLD_CFG0, RTL8367C_IGMP_MLD_EN_OFFSET, enabled);

    return retVal;
}

/* Function Name:
 *      rtl8367c_getAsicIgmp
 * Description:
 *      Get IGMP/MLD state
 * Input:
 *      enabled 	- 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicIgmp(rtk_uint32 *ptr_enabled)
{
    ret_t retVal;

    retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_IGMP_MLD_CFG0, RTL8367C_IGMP_MLD_EN_OFFSET, ptr_enabled);
    return retVal;
}

/* Function Name:
 *      rtl8367c_setAsicOutputQueueMappingIndex
 * Description:
 *      Set output queue number for each port
 * Input:
 *      port     - Physical port number (0~7)
 *      index     - Mapping table index
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK             - Success
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_PORT_ID      - Invalid port number
 *      RT_ERR_QUEUE_NUM      - Invalid queue number
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicOutputQueueMappingIndex(rtk_uint32 port, rtk_uint32 index )
{
    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    if(index >= RTL8367C_QUEUENO)
        return RT_ERR_QUEUE_NUM;

    return rtl8367c_setAsicRegBits(RTL8367C_QOS_PORT_QUEUE_NUMBER_REG(port), RTL8367C_QOS_PORT_QUEUE_NUMBER_MASK(port), index);
}

/* Function Name:
 *      rtl8367c_setAsicPriorityToQIDMappingTable
 * Description:
 *      Set priority to QID mapping table parameters
 * Input:
 *      index         - Mapping table index
 *      priority     - The priority value
 *      qid         - Queue id
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                 - Success
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_QUEUE_ID          - Invalid queue id
 *      RT_ERR_QUEUE_NUM          - Invalid queue number
 *      RT_ERR_QOS_INT_PRIORITY - Invalid priority
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPriorityToQIDMappingTable(rtk_uint32 index, rtk_uint32 priority, rtk_uint32 qid )
{
    if(index >= RTL8367C_QUEUENO)
        return RT_ERR_QUEUE_NUM;

    if(priority > RTL8367C_PRIMAX)
        return RT_ERR_QOS_INT_PRIORITY;

    if(qid > RTL8367C_QIDMAX)
        return RT_ERR_QUEUE_ID;

    return rtl8367c_setAsicRegBits(RTL8367C_QOS_1Q_PRIORITY_TO_QID_REG(index, priority), RTL8367C_QOS_1Q_PRIORITY_TO_QID_MASK(priority), qid);
}

/* Function Name:
 *      rtl8367c_setAsicFlowControlSelect
 * Description:
 *      Set system flow control type
 * Input:
 *      select 		- System flow control type 1: Ingress flow control 0:Egress flow control
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 	- Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicFlowControlSelect(rtk_uint32 select)
{
    return rtl8367c_setAsicRegBit(RTL8367C_REG_FLOWCTRL_CTRL0, RTL8367C_FLOWCTRL_TYPE_OFFSET, select);
}

/* Function Name:
 *      rtl8367c_setAsicPriorityDecision
 * Description:
 *      Set priority decision table
 * Input:
 *      prisrc         - Priority decision source
 *      decisionPri - Decision priority assignment
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                     - Success
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_QOS_INT_PRIORITY        - Invalid priority
 *      RT_ERR_QOS_SEL_PRI_SOURCE    - Invalid priority decision source parameter
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPriorityDecision(rtk_uint32 index, rtk_uint32 prisrc, rtk_uint32 decisionPri)
{
    ret_t retVal;

    if(index >= PRIDEC_IDX_END )
        return RT_ERR_ENTRY_INDEX;

    if(prisrc >= PRIDEC_END )
        return RT_ERR_QOS_SEL_PRI_SOURCE;

    if(decisionPri > RTL8367C_DECISIONPRIMAX )
        return RT_ERR_QOS_INT_PRIORITY;

    switch(index)
    {
        case PRIDEC_IDX0:
            if((retVal = rtl8367c_setAsicRegBits(RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_REG(prisrc), RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_MASK(prisrc), decisionPri))!=  RT_ERR_OK)
                return retVal;
            break;
        case PRIDEC_IDX1:
            if((retVal = rtl8367c_setAsicRegBits(RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_REG(prisrc), RTL8367C_QOS_INTERNAL_PRIORITY_DECISION2_MASK(prisrc), decisionPri))!=  RT_ERR_OK)
                return retVal;
            break;
        default:
            break;
    };

    return RT_ERR_OK;


}

/* Function Name:
 *      rtl8367c_setAsicPriorityPortBased
 * Description:
 *      Set port based priority
 * Input:
 *      port         - Physical port number (0~7)
 *      priority     - Priority value
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                 - Success
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_PORT_ID          - Invalid port number
 *      RT_ERR_QOS_INT_PRIORITY    - Invalid priority
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPriorityPortBased(rtk_uint32 port, rtk_uint32 priority )
{
    ret_t retVal;
    
    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    if(priority > RTL8367C_PRIMAX )
        return RT_ERR_QOS_INT_PRIORITY;

    if(port < 8)
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_QOS_PORTBASED_PRIORITY_REG(port), RTL8367C_QOS_PORTBASED_PRIORITY_MASK(port), priority);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    else
    {
        retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_QOS_PORTBASED_PRIORITY_CTRL2, 0x7 << ((port - 8) << 2), priority);
        if(retVal != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicRemarkingDot1pAbility
 * Description:
 *      Set 802.1p remarking ability
 * Input:
 *      port     - Physical port number (0~7)
 *      enabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK             - Success
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_PORT_ID      - Invalid port number
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicRemarkingDot1pAbility(rtk_uint32 port, rtk_uint32 enabled)
{
    return rtl8367c_setAsicRegBit(RTL8367C_PORT_MISC_CFG_REG(port), RTL8367C_1QREMARK_ENABLE_OFFSET, enabled);
}

/* Function Name:
 *      rtl8367c_setAsicRemarkingDscpAbility
 * Description:
 *      Set DSCP remarking ability
 * Input:
 *      enabled     - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK     - Success
 *      RT_ERR_SMI  - SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicRemarkingDscpAbility(rtk_uint32 enabled)
{
    return rtl8367c_setAsicRegBit(RTL8367C_REMARKING_CTRL_REG, RTL8367C_REMARKING_DSCP_ENABLE_OFFSET, enabled);
}

/* Function Name:
 *      rtl8367c_setAsicPriorityDot1qRemapping
 * Description:
 *      Set 802.1Q absolutely priority
 * Input:
 *      srcpriority - Priority value
 *      priority     - Absolute priority value
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                 - Success
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_QOS_INT_PRIORITY    - Invalid priority
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPriorityDot1qRemapping(rtk_uint32 srcpriority, rtk_uint32 priority )
{
    if((srcpriority > RTL8367C_PRIMAX) || (priority > RTL8367C_PRIMAX))
        return RT_ERR_QOS_INT_PRIORITY;

    return rtl8367c_setAsicRegBits(RTL8367C_QOS_1Q_PRIORITY_REMAPPING_REG(srcpriority), RTL8367C_QOS_1Q_PRIORITY_REMAPPING_MASK(srcpriority),priority);
}

/* Function Name:
 *      rtl8367c_setAsicRemarkingDot1pParameter
 * Description:
 *      Set 802.1p remarking parameter
 * Input:
 *      priority     - Priority value
 *      newPriority - New priority value
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                 - Success
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_QOS_INT_PRIORITY - Invalid priority
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicRemarkingDot1pParameter(rtk_uint32 priority, rtk_uint32 newPriority )
{
    if(priority > RTL8367C_PRIMAX || newPriority > RTL8367C_PRIMAX)
        return RT_ERR_QOS_INT_PRIORITY;

    return rtl8367c_setAsicRegBits(RTL8367C_QOS_1Q_REMARK_REG(priority), RTL8367C_QOS_1Q_REMARK_MASK(priority), newPriority);
}

/* Function Name:
 *      rtl8367c_setAsicRemarkingDscpParameter
 * Description:
 *      Set DSCP remarking parameter
 * Input:
 *      priority     - Priority value
 *      newDscp     - New DSCP value
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                 - Success
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_QOS_DSCP_VALUE    - Invalid DSCP value
 *      RT_ERR_QOS_INT_PRIORITY    - Invalid priority
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicRemarkingDscpParameter(rtk_uint32 priority, rtk_uint32 newDscp )
{
    if(priority > RTL8367C_PRIMAX )
        return RT_ERR_QOS_INT_PRIORITY;

    if(newDscp > RTL8367C_DSCPMAX)
        return RT_ERR_QOS_DSCP_VALUE;

    return rtl8367c_setAsicRegBits(RTL8367C_QOS_DSCP_REMARK_REG(priority), RTL8367C_QOS_DSCP_REMARK_MASK(priority), newDscp);
}

/* Function Name:
 *      rtl8367c_setAsicPriorityDscpBased
 * Description:
 *      Set DSCP-based priority
 * Input:
 *      dscp         - DSCP value
 *      priority     - Priority value
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                 - Success
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_QOS_DSCP_VALUE    - Invalid DSCP value
 *      RT_ERR_QOS_INT_PRIORITY    - Invalid priority
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPriorityDscpBased(rtk_uint32 dscp, rtk_uint32 priority )
{
    if(priority > RTL8367C_PRIMAX )
        return RT_ERR_QOS_INT_PRIORITY;

    if(dscp > RTL8367C_DSCPMAX)
        return RT_ERR_QOS_DSCP_VALUE;

    return rtl8367c_setAsicRegBits(RTL8367C_QOS_DSCP_TO_PRIORITY_REG(dscp), RTL8367C_QOS_DSCP_TO_PRIORITY_MASK(dscp), priority);
}

/* Function Name:
 *      rtl8367c_setAsicQueueType
 * Description:
 *      Set type of a queue
 * Input:
 *      port 		- Physical port number (0~10)
 *      qid 		- The queue ID wanted to set
 *      queueType 	- The specified queue type. 0b0: Strict priority, 0b1: WFQ
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_PORT_ID  - Invalid port number
 *      RT_ERR_QUEUE_ID - Invalid queue id
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicQueueType(rtk_uint32 port, rtk_uint32 qid, rtk_uint32 queueType)
{
	ret_t retVal;

	/* Invalid input parameter */
	if(port > RTL8367C_PORTIDMAX)
		return RT_ERR_PORT_ID;

    if(qid > RTL8367C_QIDMAX)
        return RT_ERR_QUEUE_ID;

	/* Set Related Registers */
	retVal = rtl8367c_setAsicRegBit(RTL8367C_SCHEDULE_QUEUE_TYPE_REG(port), RTL8367C_SCHEDULE_QUEUE_TYPE_OFFSET(port, qid),queueType);

	return retVal;
}

/* Function Name:
 *      rtl8367c_setAsicWFQWeight
 * Description:
 *      Set weight  of a queue
 * Input:
 *      port 	- Physical port number (0~10)
 *      qid 	- The queue ID wanted to set
 *      qWeight - The weight value wanted to set (valid:0~127)
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_PORT_ID  		- Invalid port number
 *      RT_ERR_QUEUE_ID  		- Invalid queue id
 *      RT_ERR_QOS_QUEUE_WEIGHT - Invalid queue weight
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicWFQWeight(rtk_uint32 port, rtk_uint32 qid, rtk_uint32 qWeight)
{
	ret_t retVal;

	/* Invalid input parameter */
	if(port > RTL8367C_PORTIDMAX)
		return RT_ERR_PORT_ID;

    if(qid > RTL8367C_QIDMAX)
        return RT_ERR_QUEUE_ID;

	if(qWeight > RTL8367C_QWEIGHTMAX && qid > 0)
		return RT_ERR_QOS_QUEUE_WEIGHT;

	retVal = rtl8367c_setAsicReg(RTL8367C_SCHEDULE_PORT_QUEUE_WFQ_WEIGHT_REG(port, qid), qWeight);

	return retVal;
}

/* Function Name:
 *      rtl8367c_setAsicPortPriorityDecisionIndex
 * Description:
 *      Set priority decision index for each port
 * Input:
 *      port     - Physical port number (0~7)
 *      index     - Table index
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK             - Success
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_PORT_ID      - Invalid port number
 *      RT_ERR_QUEUE_NUM      - Invalid queue number
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortPriorityDecisionIndex(rtk_uint32 port, rtk_uint32 index )
{
    if(port > RTL8367C_PORTIDMAX)
        return RT_ERR_PORT_ID;

    if(index >= PRIDEC_IDX_END)
        return RT_ERR_ENTRY_INDEX;

    return rtl8367c_setAsicRegBit(RTL8367C_QOS_INTERNAL_PRIORITY_DECISION_IDX_CTRL, port, index);
}

/* Function Name:
 *      rtl8367c_setAsicAclTemplate
 * Description:
 *      Set fields of a ACL Template
 * Input:
 *      index 	- ACL template index(0~4)
 *      pAclType - ACL type stucture for setting
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_OUT_OF_RANGE  	- Invalid ACL template index(0~4)
 * Note:
 *	    The API can set type field of the 5 ACL rule templates.
 *		Each type has 8 fields. One field means what data in one field of a ACL rule means
 *		8 fields of ACL rule 0~95 is descripted by one type in ACL group
 */
ret_t rtl8367c_setAsicAclTemplate(rtk_uint32 index, rtl8367c_acltemplate_t* pAclType)
{
	ret_t retVal;
	rtk_uint32 i;
	rtk_uint32 regAddr, regData;

	if(index >= RTL8367C_ACLTEMPLATENO)
		return RT_ERR_OUT_OF_RANGE;

	regAddr = RTL8367C_ACL_RULE_TEMPLATE_CTRL_REG(index);

	for(i = 0; i < (RTL8367C_ACLRULEFIELDNO/2); i++)
    {
    	regData = pAclType->field[i*2+1];
		regData = regData << 8 | pAclType->field[i*2];

		retVal = rtl8367c_setAsicReg(regAddr + i, regData);

		if(retVal != RT_ERR_OK)
	        return retVal;
	}

	return retVal;
}

/* Function Name:
 *      rtl8367c_setAsicFieldSelector
 * Description:
 *      Set user defined field selectors in HSB
 * Input:
 *      index 		- index of field selector 0-15
 *      format 		- Format of field selector
 *      offset 		- Retrieving data offset
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 			- Success
 *      RT_ERR_SMI  		- SMI access error
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Note:
 *      System support 16 user defined field selctors.
 * 		Each selector can be enabled or disable. User can defined retrieving 16-bits in many predefiend
 * 		standard l2/l3/l4 payload.
 */
ret_t rtl8367c_setAsicFieldSelector(rtk_uint32 index, rtk_uint32 format, rtk_uint32 offset)
{
	rtk_uint32 regData;

	if(index > RTL8367C_FIELDSEL_FORMAT_NUMBER)
		return RT_ERR_OUT_OF_RANGE;

	if(format >= FIELDSEL_FORMAT_END)
		return RT_ERR_OUT_OF_RANGE;

	regData = (((format << RTL8367C_FIELD_SELECTOR_FORMAT_OFFSET) & RTL8367C_FIELD_SELECTOR_FORMAT_MASK ) |
			   ((offset << RTL8367C_FIELD_SELECTOR_OFFSET_OFFSET) & RTL8367C_FIELD_SELECTOR_OFFSET_MASK ));

    return rtl8367c_setAsicReg(RTL8367C_FIELD_SELECTOR_REG(index), regData);
}

/* Function Name:
 *      rtl8367c_setAsicAcl
 * Description:
 *      Set port acl function enable/disable
 * Input:
 *      port 	- Physical port number (0~10)
 *      enabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_PORT_ID  - Invalid port number
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicAcl(rtk_uint32 port, rtk_uint32 enabled)
{
	if(port > RTL8367C_PORTIDMAX)
		return RT_ERR_PORT_ID;

	return rtl8367c_setAsicRegBit(RTL8367C_ACL_ENABLE_REG, port, enabled);
}

/* Function Name:
 *      rtl8367c_setAsicAclUnmatchedPermit
 * Description:
 *      Set port acl function unmatched permit action
 * Input:
 *      port 	- Physical port number (0~10)
 *      enabled - 1: enabled, 0: disabled
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 		- Success
 *      RT_ERR_SMI  	- SMI access error
 *      RT_ERR_PORT_ID  - Invalid port number
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicAclUnmatchedPermit(rtk_uint32 port, rtk_uint32 enabled)
{
	if(port > RTL8367C_PORTIDMAX)
		return RT_ERR_PORT_ID;

	return rtl8367c_setAsicRegBit(RTL8367C_ACL_UNMATCH_PERMIT_REG, port, enabled);
}


/*
	Exchange structure type define with MMI and SMI
*/
static void _rtl8367c_aclRuleStUser2Smi(rtl8367c_aclrule *pAclUser, rtl8367c_aclrulesmi *pAclSmi)
{
    rtk_uint8 *care_ptr, *data_ptr;
    rtk_uint8 care_tmp, data_tmp;
    rtk_uint32 i;

	pAclSmi->data_bits_ext.rule_info = ((pAclUser->data_bits.active_portmsk >> 8) & 0x7) << 1;
    pAclSmi->data_bits.rule_info = ((pAclUser->data_bits.active_portmsk & 0xff) << 8) | ((pAclUser->data_bits.tag_exist & 0x1F) << 3) | (pAclUser->data_bits.type & 0x07);

	for(i = 0;i < RTL8367C_ACLRULEFIELDNO; i++)
		pAclSmi->data_bits.field[i] = pAclUser->data_bits.field[i];

	pAclSmi->valid = pAclUser->valid;

	pAclSmi->care_bits_ext.rule_info = ((pAclUser->care_bits.active_portmsk >> 8) & 0x7) << 1;
    pAclSmi->care_bits.rule_info = ((pAclUser->care_bits.active_portmsk & 0xff) << 8) | ((pAclUser->care_bits.tag_exist & 0x1F) << 3) | (pAclUser->care_bits.type & 0x07);

	for(i = 0; i < RTL8367C_ACLRULEFIELDNO; i++)
		pAclSmi->care_bits.field[i] = pAclUser->care_bits.field[i];

    care_ptr = (rtk_uint8*)&pAclSmi->care_bits;
    data_ptr = (rtk_uint8*)&pAclSmi->data_bits;

    for ( i = 0; i < sizeof(struct acl_rule_smi_st); i++)
    {
        care_tmp = *(care_ptr + i) & ~(*(data_ptr + i));
        data_tmp = *(care_ptr + i) & *(data_ptr + i);

        *(care_ptr + i) = care_tmp;
        *(data_ptr + i) = data_tmp;
    }

	care_ptr = (rtk_uint8*)&pAclSmi->care_bits_ext;
    data_ptr = (rtk_uint8*)&pAclSmi->data_bits_ext;
	care_tmp = *care_ptr & ~(*data_ptr);
	data_tmp = *care_ptr & *data_ptr;

	*care_ptr = care_tmp;
	*data_ptr = data_tmp;
}

/*
	Exchange structure type define with MMI and SMI
*/
static void _rtl8367c_aclRuleStSmi2User( rtl8367c_aclrule *pAclUser, rtl8367c_aclrulesmi *pAclSmi)
{
    rtk_uint8 *care_ptr, *data_ptr;
    rtk_uint8 care_tmp, data_tmp;
    rtk_uint32 i;

	pAclUser->data_bits.active_portmsk = (((pAclSmi->data_bits_ext.rule_info >> 1) & 0x0007) << 8) | ((pAclSmi->data_bits.rule_info >> 8) & 0x00FF);
	pAclUser->data_bits.type = (pAclSmi->data_bits.rule_info & 0x0007);
	pAclUser->data_bits.tag_exist = (pAclSmi->data_bits.rule_info & 0x00F8) >> 3;

    care_ptr = (rtk_uint8*)&pAclSmi->care_bits;
    data_ptr = (rtk_uint8*)&pAclSmi->data_bits;

    for ( i = 0; i < sizeof(struct acl_rule_smi_st); i++)
    {
        care_tmp = *(care_ptr + i) ^ (*(data_ptr + i));
        data_tmp = *(data_ptr + i);

        *(care_ptr + i) = care_tmp;
        *(data_ptr + i) = data_tmp;
    }

    care_ptr = (rtk_uint8*)&pAclSmi->care_bits_ext;
    data_ptr = (rtk_uint8*)&pAclSmi->data_bits_ext;
    care_tmp = (*care_ptr) ^ (*data_ptr);
    data_tmp = (*data_ptr);
    *care_ptr = care_tmp;
    *data_ptr = data_tmp;

	for(i = 0; i < RTL8367C_ACLRULEFIELDNO; i++)
		pAclUser->data_bits.field[i] = pAclSmi->data_bits.field[i];

	pAclUser->valid = pAclSmi->valid;

    pAclUser->care_bits.active_portmsk = (((pAclSmi->care_bits_ext.rule_info >> 1) & 0x0007) << 8) | ((pAclSmi->care_bits.rule_info >> 8) & 0x00FF);
	pAclUser->care_bits.type = (pAclSmi->care_bits.rule_info & 0x0007);
	pAclUser->care_bits.tag_exist = (pAclSmi->care_bits.rule_info & 0x00F8) >> 3;

	for(i = 0; i < RTL8367C_ACLRULEFIELDNO; i++)
		pAclUser->care_bits.field[i] = pAclSmi->care_bits.field[i];
}

/*
	Exchange structure type define with MMI and SMI
*/
static void _rtl8367c_aclActStUser2Smi(rtl8367c_acl_act_t *pAclUser, rtk_uint16 *pAclSmi)
{
    pAclSmi[0] |= (pAclUser->cvidx_cact & 0x003F);
    pAclSmi[0] |= (pAclUser->cact & 0x0003) << 6;
    pAclSmi[0] |= (pAclUser->svidx_sact & 0x003F) << 8;
    pAclSmi[0] |= (pAclUser->sact & 0x0003) << 14;

    pAclSmi[1] |= (pAclUser->aclmeteridx & 0x003F);
    pAclSmi[1] |= (pAclUser->fwdpmask & 0x00FF) << 6;
    pAclSmi[1] |= (pAclUser->fwdact & 0x0003) << 14;

    pAclSmi[2] |= (pAclUser->pridx & 0x003F);
    pAclSmi[2] |= (pAclUser->priact & 0x0003) << 6;
    pAclSmi[2] |= (pAclUser->gpio_pin & 0x000F) << 8;
    pAclSmi[2] |= (pAclUser->gpio_en & 0x0001) << 12;
    pAclSmi[2] |= (pAclUser->aclint & 0x0001) << 13;
    pAclSmi[2] |= (pAclUser->cact_ext & 0x0003) << 14;

    pAclSmi[3] |= (pAclUser->tag_fmt & 0x0003);
    pAclSmi[3] |= (pAclUser->fwdact_ext & 0x0001) << 2;
    pAclSmi[3] |= ((pAclUser->cvidx_cact & 0x0040) >> 6) << 3;
    pAclSmi[3] |= ((pAclUser->svidx_sact & 0x0040) >> 6) << 4;
    pAclSmi[3] |= ((pAclUser->aclmeteridx & 0x0040) >> 6) << 5;
    pAclSmi[3] |= ((pAclUser->fwdpmask & 0x0700) >> 8) << 6;
    pAclSmi[3] |= ((pAclUser->pridx & 0x0040) >> 6) << 9;
}

/* Function Name:
 *      rtl8367c_setAsicAclRule
 * Description:
 *      Set acl rule content
 * Input:
 *      index 	- ACL rule index (0-95) of 96 ACL rules
 *      pAclRule - ACL rule stucture for setting
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_OUT_OF_RANGE  	- Invalid ACL rule index (0-95)
 * Note:
 *		System supported 95 shared 289-bit ACL ingress rule. Index was available at range 0-95 only.
 *		If software want to modify ACL rule, the ACL function should be disable at first or unspecify
 *		acl action will be executed.
 *		One ACL rule structure has three parts setting:
 *		Bit 0-147		Data Bits of this Rule
 *		Bit	148		Valid Bit
 *		Bit 149-296	Care Bits of this Rule
 *		There are four kinds of field in Data Bits and Care Bits: Active Portmask, Type, Tag Exist, and 8 fields
 */
ret_t rtl8367c_setAsicAclRule(rtk_uint32 index, rtl8367c_aclrule* pAclRule)
{
	rtl8367c_aclrulesmi aclRuleSmi;
	rtk_uint16* tableAddr;
	rtk_uint32 regAddr;
	rtk_uint32	regData;
	rtk_uint32 i;
	ret_t retVal;

	if(index > RTL8367C_ACLRULEMAX)
		return RT_ERR_OUT_OF_RANGE;

    memset(&aclRuleSmi, 0x00, sizeof(rtl8367c_aclrulesmi));

 	_rtl8367c_aclRuleStUser2Smi(pAclRule, &aclRuleSmi);

    /* Write valid bit = 0 */
    regAddr = RTL8367C_TABLE_ACCESS_ADDR_REG;
    if(index >= 64)
        regData = RTL8367C_ACLRULETBADDR2(DATABITS, index);
    else
        regData = RTL8367C_ACLRULETBADDR(DATABITS, index);
    retVal = rtl8367c_setAsicReg(regAddr,regData);
    if(retVal !=RT_ERR_OK)
        return retVal;

    retVal = rtl8367c_setAsicRegBits(RTL8367C_TABLE_ACCESS_WRDATA_REG(RTL8367C_ACLRULETBLEN), 0x1, 0);
    if(retVal !=RT_ERR_OK)
        return retVal;

    regAddr = RTL8367C_TABLE_ACCESS_CTRL_REG;
    regData = RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_WRITE, TB_TARGET_ACLRULE);
    retVal = rtl8367c_setAsicReg(regAddr, regData);
    if(retVal !=RT_ERR_OK)
        return retVal;



  	/* Write ACS_ADR register */
	regAddr = RTL8367C_TABLE_ACCESS_ADDR_REG;
    if(index >= 64)
	    regData = RTL8367C_ACLRULETBADDR2(CAREBITS, index);
    else
	    regData = RTL8367C_ACLRULETBADDR(CAREBITS, index);
	retVal = rtl8367c_setAsicReg(regAddr, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Write Care Bits to ACS_DATA registers */
	 tableAddr = (rtk_uint16*)&aclRuleSmi.care_bits;
	 regAddr = RTL8367C_TABLE_ACCESS_WRDATA_BASE;

	for(i = 0; i < RTL8367C_ACLRULETBLEN; i++)
	{
		regData = *tableAddr;
		retVal = rtl8367c_setAsicReg(regAddr, regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		regAddr++;
		tableAddr++;
	}
	retVal = rtl8367c_setAsicRegBits(RTL8367C_TABLE_ACCESS_WRDATA_REG(RTL8367C_ACLRULETBLEN), (0x0007 << 1), (aclRuleSmi.care_bits_ext.rule_info >> 1) & 0x0007);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Write ACS_CMD register */
	regAddr = RTL8367C_TABLE_ACCESS_CTRL_REG;
	regData = RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_WRITE, TB_TARGET_ACLRULE);
	retVal = rtl8367c_setAsicRegBits(regAddr, RTL8367C_TABLE_TYPE_MASK | RTL8367C_COMMAND_TYPE_MASK,regData);
	if(retVal != RT_ERR_OK)
		return retVal;



	/* Write ACS_ADR register for data bits */
	regAddr = RTL8367C_TABLE_ACCESS_ADDR_REG;
    if(index >= 64)
	    regData = RTL8367C_ACLRULETBADDR2(DATABITS, index);
    else
	    regData = RTL8367C_ACLRULETBADDR(DATABITS, index);

	retVal = rtl8367c_setAsicReg(regAddr, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Write Data Bits to ACS_DATA registers */
	 tableAddr = (rtk_uint16*)&aclRuleSmi.data_bits;
	 regAddr = RTL8367C_TABLE_ACCESS_WRDATA_BASE;

	for(i = 0; i < RTL8367C_ACLRULETBLEN; i++)
	{
		regData = *tableAddr;
		retVal = rtl8367c_setAsicReg(regAddr, regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		regAddr++;
		tableAddr++;
	}

	retVal = rtl8367c_setAsicRegBit(RTL8367C_TABLE_ACCESS_WRDATA_REG(RTL8367C_ACLRULETBLEN), 0, aclRuleSmi.valid);
	if(retVal != RT_ERR_OK)
		return retVal;
	retVal = rtl8367c_setAsicRegBits(RTL8367C_TABLE_ACCESS_WRDATA_REG(RTL8367C_ACLRULETBLEN), (0x0007 << 1), (aclRuleSmi.care_bits_ext.rule_info >> 1) & 0x0007);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Write ACS_CMD register for care bits*/
	regAddr = RTL8367C_TABLE_ACCESS_CTRL_REG;
	regData = RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_WRITE, TB_TARGET_ACLRULE);
	retVal = rtl8367c_setAsicRegBits(regAddr, RTL8367C_TABLE_TYPE_MASK | RTL8367C_COMMAND_TYPE_MASK, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

#ifdef CONFIG_RTL8367C_ASICDRV_TEST
	memcpy(&Rtl8370sVirtualAclRuleTable[index], &aclRuleSmi, sizeof(rtl8367c_aclrulesmi));
#endif

	return RT_ERR_OK;
}
/* Function Name:
 *      rtl8367c_getAsicAclRule
 * Description:
 *      Get acl rule content
 * Input:
 *      index 	- ACL rule index (0-63) of 64 ACL rules
 *      pAclRule - ACL rule stucture for setting
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_OUT_OF_RANGE  	- Invalid ACL rule index (0-63)
  * Note:
 *		None
 */
ret_t rtl8367c_getAsicAclRule(rtk_uint32 index, rtl8367c_aclrule *pAclRule)
{
	rtl8367c_aclrulesmi aclRuleSmi;
	rtk_uint32 regAddr, regData;
	ret_t retVal;
	rtk_uint16* tableAddr;
	rtk_uint32 i;

	if(index > RTL8367C_ACLRULEMAX)
		return RT_ERR_OUT_OF_RANGE;

	memset(&aclRuleSmi, 0x00, sizeof(rtl8367c_aclrulesmi));

	/* Write ACS_ADR register for data bits */
	regAddr = RTL8367C_TABLE_ACCESS_ADDR_REG;
    if(index >= 64)
        regData = RTL8367C_ACLRULETBADDR2(DATABITS, index);
    else
	    regData = RTL8367C_ACLRULETBADDR(DATABITS, index);

	retVal = rtl8367c_setAsicReg(regAddr, regData);
	if(retVal != RT_ERR_OK)
		return retVal;


	/* Write ACS_CMD register */
	regAddr = RTL8367C_TABLE_ACCESS_CTRL_REG;
	regData = RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_READ, TB_TARGET_ACLRULE);
	retVal = rtl8367c_setAsicRegBits(regAddr, RTL8367C_TABLE_TYPE_MASK | RTL8367C_COMMAND_TYPE_MASK, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Read Data Bits */
	regAddr = RTL8367C_TABLE_ACCESS_RDDATA_BASE;
	tableAddr = (rtk_uint16*)&aclRuleSmi.data_bits;
	for(i = 0; i < RTL8367C_ACLRULETBLEN; i++)
	{
		retVal = rtl8367c_getAsicReg(regAddr, &regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		*tableAddr = regData;

		regAddr ++;
		tableAddr ++;
	}

	/* Read Valid Bit */
	retVal = rtl8367c_getAsicRegBit(RTL8367C_TABLE_ACCESS_RDDATA_REG(RTL8367C_ACLRULETBLEN), 0, &regData);
	if(retVal != RT_ERR_OK)
		return retVal;
	aclRuleSmi.valid = regData & 0x1;
	/* Read active_portmsk_ext Bits */
	retVal = rtl8367c_getAsicRegBits(RTL8367C_TABLE_ACCESS_RDDATA_REG(RTL8367C_ACLRULETBLEN), 0x7<<1, &regData);
	if(retVal != RT_ERR_OK)
		return retVal;
	aclRuleSmi.data_bits_ext.rule_info = (regData % 0x0007) << 1;


	/* Write ACS_ADR register for carebits*/
	regAddr = RTL8367C_TABLE_ACCESS_ADDR_REG;
    if(index >= 64)
	    regData = RTL8367C_ACLRULETBADDR2(CAREBITS, index);
    else
        regData = RTL8367C_ACLRULETBADDR(CAREBITS, index);

	retVal = rtl8367c_setAsicReg(regAddr, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Write ACS_CMD register */
	regAddr = RTL8367C_TABLE_ACCESS_CTRL_REG;
	regData = RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_READ, TB_TARGET_ACLRULE);
	retVal = rtl8367c_setAsicRegBits(regAddr, RTL8367C_TABLE_TYPE_MASK | RTL8367C_COMMAND_TYPE_MASK, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Read Care Bits */
	regAddr = RTL8367C_TABLE_ACCESS_RDDATA_BASE;
	tableAddr = (rtk_uint16*)&aclRuleSmi.care_bits;
	for(i = 0; i < RTL8367C_ACLRULETBLEN; i++)
	{
		retVal = rtl8367c_getAsicReg(regAddr, &regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		*tableAddr = regData;

		regAddr ++;
		tableAddr ++;
	}
	/* Read active_portmsk_ext care Bits */
	retVal = rtl8367c_getAsicRegBits(RTL8367C_TABLE_ACCESS_RDDATA_REG(RTL8367C_ACLRULETBLEN), 0x7<<1, &regData);
	if(retVal != RT_ERR_OK)
		return retVal;
	aclRuleSmi.care_bits_ext.rule_info = (regData & 0x0007) << 1;

#ifdef CONFIG_RTL8367C_ASICDRV_TEST
	memcpy(&aclRuleSmi,&Rtl8370sVirtualAclRuleTable[index], sizeof(rtl8367c_aclrulesmi));
#endif

	 _rtl8367c_aclRuleStSmi2User(pAclRule, &aclRuleSmi);

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicAclAct
 * Description:
 *      Set ACL rule matched Action
 * Input:
 *      index 	- ACL rule index (0-95) of 96 ACL rules
 *      pAclAct 	- ACL action stucture for setting
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_OUT_OF_RANGE  	- Invalid ACL rule index (0-95)
 * Note:
 *	    None
 */
ret_t rtl8367c_setAsicAclAct(rtk_uint32 index, rtl8367c_acl_act_t* pAclAct)
{
	rtk_uint16 aclActSmi[RTL8367C_ACL_ACT_TABLE_LEN];
	ret_t retVal;
	rtk_uint32 regAddr, regData;
	rtk_uint16* tableAddr;
	rtk_uint32 i;

	if(index > RTL8367C_ACLRULEMAX)
		return RT_ERR_OUT_OF_RANGE;

	memset(aclActSmi, 0x00, sizeof(rtk_uint16) * RTL8367C_ACL_ACT_TABLE_LEN);
	 _rtl8367c_aclActStUser2Smi(pAclAct, aclActSmi);

	/* Write ACS_ADR register for data bits */
	regAddr = RTL8367C_TABLE_ACCESS_ADDR_REG;
	regData = index;
	retVal = rtl8367c_setAsicReg(regAddr, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

	/* Write Data Bits to ACS_DATA registers */
	 tableAddr = aclActSmi;
	 regAddr = RTL8367C_TABLE_ACCESS_WRDATA_BASE;

	for(i = 0; i < RTL8367C_ACLACTTBLEN; i++)
	{
		regData = *tableAddr;
		retVal = rtl8367c_setAsicReg(regAddr, regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		regAddr++;
		tableAddr++;
	}

	/* Write ACS_CMD register for care bits*/
	regAddr = RTL8367C_TABLE_ACCESS_CTRL_REG;
	regData = RTL8367C_TABLE_ACCESS_REG_DATA(TB_OP_WRITE, TB_TARGET_ACLACT);
	retVal = rtl8367c_setAsicRegBits(regAddr, RTL8367C_TABLE_TYPE_MASK | RTL8367C_COMMAND_TYPE_MASK, regData);
	if(retVal != RT_ERR_OK)
		return retVal;

#ifdef CONFIG_RTL8367C_ASICDRV_TEST
    memcpy(&Rtl8370sVirtualAclActTable[index][0], aclActSmi, sizeof(rtk_uint16) * RTL8367C_ACL_ACT_TABLE_LEN);
#endif

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicAclActCtrl
 * Description:
 *      Set ACL rule matched Action Control Bits
 * Input:
 *      index 		- ACL rule index (0-95) of 96 ACL rules
 *      aclActCtrl 	- 6 ACL Control Bits
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_OUT_OF_RANGE  	- Invalid ACL rule index (0-95)
 * Note:
 *	    ACL Action Control Bits Indicate which actions will be take when a rule matches
 */
ret_t rtl8367c_setAsicAclActCtrl(rtk_uint32 index, rtk_uint32 aclActCtrl)
{
	ret_t retVal;

	if(index > RTL8367C_ACLRULEMAX)
		return RT_ERR_OUT_OF_RANGE;

    if(index >= 64)
        retVal = rtl8367c_setAsicRegBits(RTL8367C_ACL_ACTION_CTRL2_REG(index), RTL8367C_ACL_OP_ACTION_MASK(index), aclActCtrl);
    else
        retVal = rtl8367c_setAsicRegBits(RTL8367C_ACL_ACTION_CTRL_REG(index), RTL8367C_ACL_OP_ACTION_MASK(index), aclActCtrl);

    return retVal;
}


/* Function Name:
 *      rtl8367c_setAsicAclNot
 * Description:
 *      Set rule comparison result inversion / no inversion
 * Input:
 *      index 	- ACL rule index (0-95) of 96 ACL rules
 *      not 	- 1: inverse, 0: don't inverse
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_OUT_OF_RANGE  	- Invalid ACL rule index (0-95)
 * Note:
 *		None
 */
ret_t rtl8367c_setAsicAclNot(rtk_uint32 index, rtk_uint32 not)
{
	if(index > RTL8367C_ACLRULEMAX)
		return RT_ERR_OUT_OF_RANGE;

	if(index < 64)
		return rtl8367c_setAsicRegBit(RTL8367C_ACL_ACTION_CTRL_REG(index), RTL8367C_ACL_OP_NOT_OFFSET(index), not);
	else
		return rtl8367c_setAsicRegBit(RTL8367C_ACL_ACTION_CTRL2_REG(index), RTL8367C_ACL_OP_NOT_OFFSET(index), not);

}

/* Function Name:
 *      rtl8367c_setAsicShareMeter
 * Description:
 *      Set meter configuration
 * Input:
 *      index 	- hared meter index (0-31)
 *      rate 	- 17-bits rate of share meter, unit is 8Kpbs
 *      ifg 	- Including IFG in rate calculation, 1:include 0:exclude
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_FILTER_METER_ID  - Invalid meter
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicShareMeter(rtk_uint32 index, rtk_uint32 rate, rtk_uint32 ifg)
{
    ret_t retVal;

    if(index > RTL8367C_METERMAX)
        return RT_ERR_FILTER_METER_ID;

    if(index < 32)
    {
	/*19-bits Rate*/
        retVal = rtl8367c_setAsicReg(RTL8367C_METER_RATE_REG(index), rate&0xFFFF);
        if(retVal != RT_ERR_OK)
            return retVal;

        retVal = rtl8367c_setAsicReg(RTL8367C_METER_RATE_REG(index) + 1, (rate &0x70000) >> 16);
        if(retVal != RT_ERR_OK)
            return retVal;

        retVal = rtl8367c_setAsicRegBit(RTL8367C_METER_IFG_CTRL_REG(index), RTL8367C_METER_IFG_OFFSET(index), ifg);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    else
    {
	/*19-bits Rate*/
        retVal = rtl8367c_setAsicReg(RTL8367C_REG_METER32_RATE_CTRL0 + ((index-32) << 1), rate&0xFFFF);
        if(retVal != RT_ERR_OK)
            return retVal;

        retVal = rtl8367c_setAsicReg(RTL8367C_REG_METER32_RATE_CTRL0 + ((index-32) << 1) + 1, (rate &0x70000) >> 16);
        if(retVal != RT_ERR_OK)
            return retVal;

        retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_METER_IFG_CTRL2 + ((index-32) >> 4), RTL8367C_METER_IFG_OFFSET(index), ifg);
        if(retVal != RT_ERR_OK)
            return retVal;
    }
    
	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicShareMeterType
 * Description:
 *      Set meter Type
 * Input:
 *      index 		- shared meter index (0-31)
 *      Type        - 0: kbps, 1: pps
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_FILTER_METER_ID  - Invalid meter
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicShareMeterType(rtk_uint32 index, rtk_uint32 type)
{
    rtk_uint32 reg;

    if(index > RTL8367C_METERMAX)
		return RT_ERR_FILTER_METER_ID;

    if(index < 32)
        reg = RTL8367C_REG_METER_MODE_SETTING0 + (index / 16);
    else
        reg = RTL8367C_REG_METER_MODE_SETTING2 + ((index - 32) / 16);
    return rtl8367c_setAsicRegBit(reg, index % 16, type);
}

/* Function Name:
 *      rtl8367c_setAsicShareMeterBucketSize
 * Description:
 *      Set meter related leaky bucket threshold
 * Input:
 *      index 		- hared meter index (0-31)
 *      lbthreshold - Leaky bucket threshold of meter
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_FILTER_METER_ID  - Invalid meter
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicShareMeterBucketSize(rtk_uint32 index, rtk_uint32 lbthreshold)
{
    
    if(index > RTL8367C_METERMAX)
        return RT_ERR_FILTER_METER_ID;

    if(index < 32)
	return rtl8367c_setAsicReg(RTL8367C_METER_BUCKET_SIZE_REG(index), lbthreshold);
    else
       return rtl8367c_setAsicReg(RTL8367C_REG_METER32_BUCKET_SIZE + index - 32, lbthreshold);
}

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
/* APIs for SFP */

/* Function Name:
 *      rtl8367c_setAsicSdsReg
 * Description:
 *      Set Serdes registers
 * Input:
 *      sdsId   - sdsid (0~1)
 *      sdsReg - reg address (0~31)
 *      sdsPage - Writing data
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK               - Success

 * Note:
 *      None
 */

ret_t rtl8367c_setAsicSdsReg(rtk_uint32 sdsId, rtk_uint32 sdsReg, rtk_uint32 sdsPage,  rtk_uint32 value)
{
    rtk_uint32 retVal;

    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, value)) != RT_ERR_OK)
        return retVal;

    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (sdsPage<<5) | sdsReg)) != RT_ERR_OK)
        return retVal;

    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0|sdsId)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;

}

/* Function Name:
 *      rtl8367c_getAiscSdsReg
 * Description:
 *      Get Serdes registers
 * Input:
 *      sdsId   - sdsid (0~1)
 *      sdsReg - reg address (0~31)
 *      sdsPage - Writing data
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK               - Success

 * Note:
 *      None
 */
ret_t rtl8367c_getAsicSdsReg(rtk_uint32 sdsId, rtk_uint32 sdsReg, rtk_uint32 sdsPage, rtk_uint32 *value)
{
    rtk_uint32 retVal, busy;

    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (sdsPage<<5) | sdsReg)) != RT_ERR_OK)
        return retVal;

    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x0080|sdsId)) != RT_ERR_OK)
        return retVal;

    while(1)
    {
        if ((retVal = rtl8367c_getAsicReg(RTL8367C_REG_SDS_INDACS_CMD, &busy))!=RT_ERR_OK)
            return retVal;

        if ((busy & 0x100) == 0)
            break;
    }

    if ((retVal = rtl8367c_getAsicReg(RTL8367C_REG_SDS_INDACS_DATA, value))!=RT_ERR_OK)
            return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtl8367c_setAsicPortExtMode
 * Description:
 *      Set external interface mode configuration
 * Input:
 *      id      - external interface id (0~2)
 *      mode    - external interface mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - Success
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortExtMode(rtk_uint32 id, rtk_uint32 mode)
{
    ret_t   retVal;
    rtk_uint32 i, regValue, type, option,reg_data;
    rtk_uint32 idx;
    rtk_uint32 redData[][2] =   { {0x04D7, 0x0480}, {0xF994, 0x0481}, {0x21A2, 0x0482}, {0x6960, 0x0483}, {0x9728, 0x0484}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x83F2, 0x002E} };
    rtk_uint32 redDataSB[][2] = { {0x04D7, 0x0480}, {0xF994, 0x0481}, {0x31A2, 0x0482}, {0x6960, 0x0483}, {0x9728, 0x0484}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x83F2, 0x002E} };
    rtk_uint32 redData1[][2] =  { {0x82F1, 0x0500}, {0xF195, 0x0501}, {0x31A2, 0x0502}, {0x796C, 0x0503}, {0x9728, 0x0504}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x0F80, 0x0001}, {0x83F2, 0x002E} };
    rtk_uint32 redData5[][2] =  { {0x82F1, 0x0500}, {0xF195, 0x0501}, {0x31A2, 0x0502}, {0x796C, 0x0503}, {0x9728, 0x0504}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x0F80, 0x0001}, {0x83F2, 0x002E} };
    rtk_uint32 redData6[][2] =  { {0x82F1, 0x0500}, {0xF195, 0x0501}, {0x31A2, 0x0502}, {0x796C, 0x0503}, {0x9728, 0x0504}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x0F80, 0x0001}, {0x83F2, 0x002E} };
    rtk_uint32 redData8[][2] =  { {0x82F1, 0x0500}, {0xF995, 0x0501}, {0x31A2, 0x0502}, {0x796C, 0x0503}, {0x9728, 0x0504}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x0F80, 0x0001}, {0x83F2, 0x002E} };
    rtk_uint32 redData9[][2] =  { {0x82F1, 0x0500}, {0xF995, 0x0501}, {0x31A2, 0x0502}, {0x796C, 0x0503}, {0x9728, 0x0504}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x0F80, 0x0001}, {0x83F2, 0x002E} };
    rtk_uint32 redDataHB[][2] = { {0x82F0, 0x0500}, {0xF195, 0x0501}, {0x31A2, 0x0502}, {0x7960, 0x0503}, {0x9728, 0x0504}, {0x9D85, 0x0423}, {0xD810, 0x0424}, {0x0F80, 0x0001}, {0x83F2, 0x002E} };

    if(id >= RTL8367C_EXTNO)
        return RT_ERR_OUT_OF_RANGE;

    if(mode >= EXT_END)
        return RT_ERR_OUT_OF_RANGE;


    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0249)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_getAsicReg(0x1300, &regValue)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0000)) != RT_ERR_OK)
        return retVal;

    type = 0;

    switch (regValue)
    {
        case 0x0276:
        case 0x0597:
        case 0x6367:
            type = 1;
            break;
        case 0x0652:
        case 0x6368:
            type = 2;
            break;
        case 0x0801:
        case 0x6511:
            type = 3;
            break;
        default:
            return RT_ERR_FAILED;
    }


    if (1==type)
    {
        if((mode == EXT_1000X_100FX) || (mode == EXT_1000X) || (mode == EXT_100FX))
        {
            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_REG_TO_ECO4, 5, 1)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_REG_TO_ECO4, 7, 1)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_CHIP_RESET, RTL8367C_DW8051_RST_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_MISCELLANEOUS_CONFIGURE0, RTL8367C_DW8051_EN_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_ACS_IROM_ENABLE_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_IROM_MSB_OFFSET, 0)) != RT_ERR_OK)
                return retVal;

            if(mode == EXT_1000X_100FX)
            {
                for(idx = 0; idx < FIBER2_AUTO_INIT_SIZE; idx++)
                {
                    if ((retVal = rtl8367c_setAsicReg(0xE000 + idx, (rtk_uint32)Fiber2_Auto[idx])) != RT_ERR_OK)
                        return retVal;
                }
            }

            if(mode == EXT_1000X)
            {
                for(idx = 0; idx < FIBER2_1G_INIT_SIZE; idx++)
                {
                    if ((retVal = rtl8367c_setAsicReg(0xE000 + idx, (rtk_uint32)Fiber2_1G[idx])) != RT_ERR_OK)
                        return retVal;
                }
            }

            if(mode == EXT_100FX)
            {
                for(idx = 0; idx < FIBER2_100M_INIT_SIZE; idx++)
                {
                    if ((retVal = rtl8367c_setAsicReg(0xE000 + idx, (rtk_uint32)Fiber2_100M[idx])) != RT_ERR_OK)
                        return retVal;
                }
            }

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_IROM_MSB_OFFSET, 0)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_ACS_IROM_ENABLE_OFFSET, 0)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_CHIP_RESET, RTL8367C_DW8051_RST_OFFSET, 0)) != RT_ERR_OK)
                return retVal;
        }

        if(mode == EXT_GMII)
        {
            if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_EXT0_RGMXF, RTL8367C_EXT0_RGTX_INV_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_EXT1_RGMXF, RTL8367C_EXT1_RGTX_INV_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if( (retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_EXT_TXC_DLY, RTL8367C_EXT1_GMII_TX_DELAY_MASK, 5)) != RT_ERR_OK)
                return retVal;

            if( (retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_EXT_TXC_DLY, RTL8367C_EXT0_GMII_TX_DELAY_MASK, 6)) != RT_ERR_OK)
                return retVal;
        }

        /* Serdes reset */
        if( (mode == EXT_TMII_MAC) || (mode == EXT_TMII_PHY) )
        {
            if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_BYPASS_LINE_RATE, id, 1)) != RT_ERR_OK)
                return retVal;
        }
        else
        {
            if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_BYPASS_LINE_RATE, id, 0)) != RT_ERR_OK)
                return retVal;
        }

        if( (mode == EXT_SGMII) || (mode == EXT_HSGMII) )
        {
            if(id != 1)
                return RT_ERR_PORT_ID;

            if((retVal = rtl8367c_setAsicReg(0x13C0, 0x0249)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_getAsicReg(0x13C1, &option)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicReg(0x13C0, 0x0000)) != RT_ERR_OK)
                return retVal;
        }

        if(mode == EXT_SGMII)
        {
            if(option == 0)
            {
                for(i = 0; i <= 7; i++)
                {
                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redData[i][0])) != RT_ERR_OK)
                        return retVal;

                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redData[i][1])) != RT_ERR_OK)
                        return retVal;

                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                        return retVal;
                }
            }
            else
            {
                for(i = 0; i <= 7; i++)
                {
                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redDataSB[i][0])) != RT_ERR_OK)
                        return retVal;

                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redDataSB[i][1])) != RT_ERR_OK)
                        return retVal;

                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                        return retVal;
                }
            }
        }

        if(mode == EXT_HSGMII)
        {
            if(option == 0)
            {
                if( (retVal = rtl8367c_setAsicReg(0x13c2, 0x0249)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicReg(0x1301, &regValue)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(0x13c2, 0x0000)) != RT_ERR_OK)
                    return retVal;

                if ( ((regValue & 0x00F0) >> 4) == 0x0001)
                {
                    for(i = 0; i <= 8; i++)
                    {
                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redData1[i][0])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redData1[i][1])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                            return retVal;
                    }
                }
                else if ( ((regValue & 0x00F0) >> 4) == 0x0005)
                {
                    for(i = 0; i <= 8; i++)
                    {
                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redData5[i][0])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redData5[i][1])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                            return retVal;
                    }
                }
                else if ( ((regValue & 0x00F0) >> 4) == 0x0006)
                {
                    for(i = 0; i <= 8; i++)
                    {
                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redData6[i][0])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redData6[i][1])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                            return retVal;
                    }
                }
                else if ( ((regValue & 0x00F0) >> 4) == 0x0008)
                {
                    for(i = 0; i <= 8; i++)
                    {
                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redData8[i][0])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redData8[i][1])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                            return retVal;
                    }
                }
                else if ( ((regValue & 0x00F0) >> 4) == 0x0009)
                {
                    for(i = 0; i <= 8; i++)
                    {
                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redData9[i][0])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redData9[i][1])) != RT_ERR_OK)
                            return retVal;

                        if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                            return retVal;
                    }
                }
            }
            else
            {
                for(i = 0; i <= 8; i++)
                {
                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, redDataHB[i][0])) != RT_ERR_OK)
                        return retVal;

                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, redDataHB[i][1])) != RT_ERR_OK)
                        return retVal;

                    if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                        return retVal;
                }
            }
        }

        /* Only one ext port should care SGMII setting */
        if(id == 1)
        {

            if(mode == EXT_SGMII)
            {
                if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_SGMII_OFFSET, 1)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_HSGMII_OFFSET, 0)) != RT_ERR_OK)
                    return retVal;
            }
            else if(mode == EXT_HSGMII)
            {
                if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_SGMII_OFFSET, 0)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_HSGMII_OFFSET, 1)) != RT_ERR_OK)
                    return retVal;
            }
            else
            {

                if((mode != EXT_1000X_100FX) && (mode != EXT_1000X) && (mode != EXT_100FX))
                {
                    if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_SGMII_OFFSET, 0)) != RT_ERR_OK)
                        return retVal;

                    if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_HSGMII_OFFSET, 0)) != RT_ERR_OK)
                        return retVal;
                }
            }
        }

        if(0 == id || 1 == id)
        {
            if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_DIGITAL_INTERFACE_SELECT, RTL8367C_SELECT_GMII_0_MASK << (id * RTL8367C_SELECT_GMII_1_OFFSET), mode)) != RT_ERR_OK)
                return retVal;
        }
        else
        {
            if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_DIGITAL_INTERFACE_SELECT_1, RTL8367C_SELECT_GMII_2_MASK, mode)) != RT_ERR_OK)
                return retVal;
        }

        /* Serdes not reset */
        if( (mode == EXT_SGMII) || (mode == EXT_HSGMII) )
        {
            if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x7106)) != RT_ERR_OK)
                return retVal;

            if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, 0x0003)) != RT_ERR_OK)
                return retVal;

            if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                return retVal;
        }

        if( (mode == EXT_SGMII) || (mode == EXT_HSGMII) )
        {
            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_CHIP_RESET, RTL8367C_DW8051_RST_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_MISCELLANEOUS_CONFIGURE0, RTL8367C_DW8051_EN_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_ACS_IROM_ENABLE_OFFSET, 1)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_IROM_MSB_OFFSET, 0)) != RT_ERR_OK)
                return retVal;

            for(idx = 0; idx < SGMII_INIT_SIZE; idx++)
            {
                if ((retVal = rtl8367c_setAsicReg(0xE000 + idx, (rtk_uint32)Sgmii_Init[idx])) != RT_ERR_OK)
                    return retVal;
            }

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_IROM_MSB_OFFSET, 0)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_ACS_IROM_ENABLE_OFFSET, 0)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_CHIP_RESET, RTL8367C_DW8051_RST_OFFSET, 0)) != RT_ERR_OK)
                return retVal;
        }
    }
    else if (2 == type)
    {

        if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_CHIP_RESET, RTL8367C_DW8051_RST_OFFSET, 1)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_MISCELLANEOUS_CONFIGURE0, RTL8367C_DW8051_EN_OFFSET, 1)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_ACS_IROM_ENABLE_OFFSET, 1)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_IROM_MSB_OFFSET, 0)) != RT_ERR_OK)
            return retVal;
        
        for(idx = 0; idx < FIBER1_2_INIT_SIZE; idx++)
        {
            if ((retVal = rtl8367c_setAsicReg(0xE000 + idx, (rtk_uint32)Fiber1_2_Init[idx])) != RT_ERR_OK)
                return retVal;
        }


        if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_IROM_MSB_OFFSET, 0)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_DW8051_RDY, RTL8367C_ACS_IROM_ENABLE_OFFSET, 0)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_CHIP_RESET, RTL8367C_DW8051_RST_OFFSET, 0)) != RT_ERR_OK)
            return retVal;


        if( (mode == EXT_TMII_MAC) || (mode == EXT_TMII_PHY) )
        {
            if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_BYPASS_LINE_RATE, id+2, 1)) != RT_ERR_OK)
                return retVal;
        }
        else
        {
            if( (retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_BYPASS_LINE_RATE, id+2, 0)) != RT_ERR_OK)
                return retVal;
        }


        if (id == 1)
        {
            if(mode == EXT_HSGMII)
                return RT_ERR_PORT_ID;

            if (mode == EXT_SGMII)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 14, 1)) != RT_ERR_OK)
                    return retVal;
            }
            else if (mode == EXT_1000X || mode == EXT_100FX || mode == EXT_1000X_100FX)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 14, 0)) != RT_ERR_OK)
                    return retVal;


                if((retVal = rtl8367c_setAsicRegBit(0x6210, 11, 0)) != RT_ERR_OK)
                    return retVal;
            }
            else
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, mode)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 14, 0)) != RT_ERR_OK)
                    return retVal;
            }

            if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 0x1f)) != RT_ERR_OK)
                return retVal;
        }
        else if(id == 2)
        {
            if (mode == EXT_HSGMII)
            {
                if ((retVal = rtl8367c_setAsicReg(0x130, 7)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0x39f, 7)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0x3fa, 7)) != RT_ERR_OK)
                    return retVal;
            }
            else
            {
                if ((retVal = rtl8367c_setAsicReg(0x130, 1)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0x39f, 1)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0x3fa, 4)) != RT_ERR_OK)
                    return retVal;

            }


            if (mode == EXT_SGMII)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 6, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 7, 0)) != RT_ERR_OK)
                    return retVal;
            }
            else if (mode == EXT_HSGMII)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 6, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 7, 1)) != RT_ERR_OK)
                    return retVal;
            }
            else if (mode == EXT_1000X || mode == EXT_100FX || mode == EXT_1000X_100FX)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 6, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 7, 0)) != RT_ERR_OK)
                    return retVal;


                if((retVal = rtl8367c_setAsicRegBit(0x6200, 11, 0)) != RT_ERR_OK)
                    return retVal;
            }
            else
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, mode)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 6, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d92, 7, 0)) != RT_ERR_OK)
                    return retVal;
            }

            if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 0x1f)) != RT_ERR_OK)
                return retVal;
        }


        if (mode == EXT_RGMII)
        {

            if ((retVal = rtl8367c_setAsicReg(RTL8367C_REG_PARA_LED_IO_EN3, 0)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicReg(RTL8367C_REG_PARA_LED_IO_EN1, 0)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicReg(RTL8367C_REG_PARA_LED_IO_EN2, 0)) != RT_ERR_OK)
                return retVal;


            if (id == 1)
            {

                if ((retVal = rtl8367c_setAsicRegBit(0x1303, 9, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1303, 6, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1303, 4, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1303, 1, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1307, 3, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x13f9, 0x38, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1307, 0x7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1304, 0x7000, 4)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x13f9, 0x700, 4)) != RT_ERR_OK)
                    return retVal;
            }
            else if (id == 2)
            {

                if ((retVal = rtl8367c_setAsicRegBit(0x1303, 10, 1)) != RT_ERR_OK)
                    return retVal;

                /*drving 1*/
                if ((retVal = rtl8367c_setAsicRegBit(0x13e2, 2, 1)) != RT_ERR_OK)
                    return retVal;

                /*drving 1*/
                if ((retVal = rtl8367c_setAsicRegBit(0x13e2, 1, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x13e2, 0, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x13c5, 3, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x13f9, 0x1c0, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x13c5, 0x7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x13e2, 0x1c0, 4)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x13e2, 0x38, 4)) != RT_ERR_OK)
                    return retVal;
            }
        }
        else if (mode == EXT_SGMII)
        {
            if (id == 1)
            {
                /*sds 1     reg 1    page 0x21     write value  0xec91*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0xec91)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x21<<5) | 1)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C1)) != RT_ERR_OK)
                    return retVal;

                /*sds 1     reg 5    page 0x24     write value  0x5825*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x5825)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x24<<5) | 5)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C1)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 2)) != RT_ERR_OK)
                    return retVal;

                /*?????????????????*/

            }
            else if (id == 2)
            {
                /*sds 0     reg 0    page 0x28     write value  0x942c*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x942c)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x28<<5) | 0)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                    return retVal;

                /*sds 0     reg 0    page 0x24     write value  0x942c*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x942c)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x24<<5) | 0)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                    return retVal;

                /*sds 0     reg 5    page 0x21     write value  0x8dc3*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x8dc3)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x21<<5) | 5)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 2)) != RT_ERR_OK)
                    return retVal;

                /*?????????????????*/
            }
        }
        else if (mode == EXT_HSGMII)
        {
            if (id == 2)
            {
                /*sds 0     reg 0    page 0x28     write value  0x942c*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x942c)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x28<<5) | 0)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                    return retVal;

                /*sds 0     reg 0    page 0x24     write value  0x942c*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x942c)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x24<<5) | 0)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                    return retVal;

                /*sds 0     reg 5    page 0x21     write value  0x8dc3*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x8dc3)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x21<<5) | 5)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                    return retVal;


                /* optimizing HISGMII performance while RGMII used & */
                /*sds 0     reg 9     page 0x21     write value 0x3931*/
                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_DATA, 0x3931)) != RT_ERR_OK)
                        return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_ADR, (0x21<<5)|9) ) != RT_ERR_OK)
                        return retVal;

                if( (retVal = rtl8367c_setAsicReg(RTL8367C_REG_SDS_INDACS_CMD, 0x00C0)) != RT_ERR_OK)
                        return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 0x12)) != RT_ERR_OK)
                    return retVal;

                /*?????????????????*/
            }
        }
        else if (mode == EXT_1000X)
        {
            if (id == 1)
            {

                if( (retVal = rtl8367c_setAsicSdsReg(1, 1, 0x21, 0xec91)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 5, 0x24, 0x5825)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 4)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;

                /*patch speed change sds1 1000M*/
                if( (retVal = rtl8367c_getAsicSdsReg(1, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFF0FFF;
                regValue |= 0x9000;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(1, 0, 2, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFdFFF;
                regValue |= 0x40;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 0, 2, regValue)) != RT_ERR_OK)
                    return retVal;


                if( (retVal = rtl8367c_getAsicSdsReg(1, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFEFFF;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 4)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x6000, 0)) != RT_ERR_OK)
                    return retVal;

            }
            else if (id == 2)
            {
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 0x28, 0x942c)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 0x24, 0x942c)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 5, 0x21, 0x8dc3)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 4)) != RT_ERR_OK)
                    return retVal;

                /*patch speed change sds0 1000M*/
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 0x1f)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFF0FFF;
                regValue |= 0x9000;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFDFFF;
                regValue |= 0x40;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 2, regValue)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFEFFF;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 4)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0xe0, 0)) != RT_ERR_OK)
                    return retVal;

            }
        }
        else if (mode == EXT_100FX)
        {
            if (id == 1)
            {
                if( (retVal = rtl8367c_setAsicSdsReg(1, 1, 0x21, 0xec91)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 5, 0x24, 0x5825)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 5)) != RT_ERR_OK)
                    return retVal;

                /*patch speed change sds1 100M*/
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_getAsicSdsReg(1, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFF0FFF;
                regValue |= 0xb000;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(1, 0, 2, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFFFBF;
                regValue |= 0x2000;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 0, 2, regValue)) != RT_ERR_OK)
                    return retVal;
#if 0
                if( (retVal = rtl8367c_setAsicReg(0x6214, 0x1a0)) != RT_ERR_OK)
                    return retVal;
#endif
                if( (retVal = rtl8367c_getAsicSdsReg(1, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFEFFF;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 5)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x6000, 0)) != RT_ERR_OK)
                    return retVal;
            }
            else if (id == 2)
            {
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 0x28, 0x942c)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 0x24, 0x942c)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 5, 0x21, 0x8dc3)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 5)) != RT_ERR_OK)
                    return retVal;

                /*patch speed change sds0 100M*/
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 0x1f)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFF0FFF;
                regValue |= 0xb000;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFFFBF;
                regValue |= 0x2000;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 2, regValue)) != RT_ERR_OK)
                    return retVal;

                if( (retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue &= 0xFFFFEFFF;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 4, 0, regValue)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 5)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0xe0, 0)) != RT_ERR_OK)
                    return retVal;
            }
        }
        else if (mode == EXT_1000X_100FX)
        {
            if (id == 1)
            {
                if( (retVal = rtl8367c_setAsicSdsReg(1, 1, 0x21, 0xec91)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 5, 0x24, 0x5825)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 13, 0, 0x4616)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(1, 1, 0, 0xf20)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f00, 7)) != RT_ERR_OK)
                    return retVal;
            }
            else if (id == 2)
            {
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 0x28, 0x942c)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 0, 0x24, 0x942c)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 5, 0x21, 0x8dc3)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 13, 0, 0x4616)) != RT_ERR_OK)
                    return retVal;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 1, 0, 0xf20)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d92, 0x1f, 7)) != RT_ERR_OK)
                    return retVal;
            }
        }

    }
    else if (3 == type)
    {

        /*restore patch, by designer. patch Tx FIFO issue, when not HSGMII 2.5G mode
         #sds0, page 1, reg 1, bit4=0*/
        if( (retVal = rtl8367c_getAsicSdsReg(0, 1, 1, &regValue)) != RT_ERR_OK)
            return retVal;
        regValue &= 0xFFFFFFEF;
        if( (retVal = rtl8367c_setAsicSdsReg(0, 1, 1, regValue)) != RT_ERR_OK)
            return retVal;

        /*set for mac 6*/
        if (1 == id)
        {

            if ((retVal = rtl8367c_setAsicReg(0x137c, 0x1000)) != RT_ERR_OK)
                    return retVal;

            if ((retVal = rtl8367c_getAsicRegBit(0x1d9d, 6, &reg_data)) != RT_ERR_OK)
                    return retVal;
            while(reg_data == 0)
            {
                if ((retVal = rtl8367c_getAsicRegBit(0x1d9d, 6, &reg_data)) != RT_ERR_OK)
                    return retVal;
            }

            if (mode == EXT_SGMII)
            {

                if ((retVal = rtl8367c_getAsicRegBit(0x1d3d, 10, &reg_data)) != RT_ERR_OK)
                    return retVal;
                if(reg_data == 0)
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 0)) != RT_ERR_OK)
                        return retVal;
                }

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 1, 0)) != RT_ERR_OK)
                    return retVal;




                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 1, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 0, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 9, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 0)) != RT_ERR_OK)
                    return retVal;



                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x2)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 2, 0)) != RT_ERR_OK)
                    return retVal;


            }
            else if (mode == EXT_HSGMII)
            {

                /*restore patch, by designer. patch Tx FIFO issue, when  HSGMII 2.5G mode
                 #sds0, page 1, reg 1, bit4=1*/
                if( (retVal = rtl8367c_getAsicSdsReg(0, 1, 1, &regValue)) != RT_ERR_OK)
                    return retVal;
                regValue |= 0x10;
                if( (retVal = rtl8367c_setAsicSdsReg(0, 1, 1, regValue)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_getAsicRegBit(0x1d3d, 10, &reg_data)) != RT_ERR_OK)
                    return retVal;
                if(reg_data == 0)
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 0)) != RT_ERR_OK)
                        return retVal;
                }

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 1, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 1, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 0, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 9, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 1)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0xd0,7)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicReg(0x399, 7)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicReg(0x3fa, 7)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x12)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 2, 0)) != RT_ERR_OK)
                    return retVal;

            }
            else if(mode == EXT_1000X)
            {

                if((retVal = rtl8367c_getAsicSdsReg(0, 2, 0, &reg_data)) != RT_ERR_OK)
                    return retVal;
                reg_data &= 0xFFFFFCFF;
                if((retVal = rtl8367c_setAsicSdsReg(0,2,0, reg_data)) != RT_ERR_OK)
                        return retVal;


                if ((retVal = rtl8367c_getAsicRegBit(0x1d3d, 10, &reg_data)) != RT_ERR_OK)
                    return retVal;
                if(reg_data == 0)
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 0)) != RT_ERR_OK)
                        return retVal;
                }

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 1, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0x1d11, 0x1500)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13eb, 0x15bb)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13e7, 0xc)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 1)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 1)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x4)) != RT_ERR_OK)
                    return retVal;
            }
            else if(mode == EXT_100FX)
            {

                if((retVal = rtl8367c_getAsicSdsReg(0, 2, 0, &reg_data)) != RT_ERR_OK)
                    return retVal;
                reg_data &= 0xFFFFFCFF;
                if((retVal = rtl8367c_setAsicSdsReg(0,2,0, reg_data)) != RT_ERR_OK)
                        return retVal;


                if ((retVal = rtl8367c_getAsicRegBit(0x1d3d, 10, &reg_data)) != RT_ERR_OK)
                    return retVal;
                if(reg_data == 0)
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 0)) != RT_ERR_OK)
                        return retVal;
                }

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 1, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0x1d11, 0x1500)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13eb, 0x15bb)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13e7, 0xc)) != RT_ERR_OK)
                    return retVal;



                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 1)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 1)) != RT_ERR_OK)
                    return retVal;



                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x5)) != RT_ERR_OK)
                    return retVal;
            }
            else if(mode == EXT_1000X_100FX)
            {
                /* 0 2 0  bit 8~9  set 0, force n-way*/
                if((retVal = rtl8367c_getAsicSdsReg(0, 2, 0, &reg_data)) != RT_ERR_OK)
                    return retVal;
                reg_data &= 0xFFFFFCFF;
                if((retVal = rtl8367c_setAsicSdsReg(0,2,0, reg_data)) != RT_ERR_OK)
                        return retVal;


                if ((retVal = rtl8367c_getAsicRegBit(0x1d3d, 10, &reg_data)) != RT_ERR_OK)
                    return retVal;
                if(reg_data == 0)
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 0)) != RT_ERR_OK)
                        return retVal;
                }

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 1, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicReg(0x1d11, 0x1500)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13eb, 0x15bb)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13e7, 0xc)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 1)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x7)) != RT_ERR_OK)
                    return retVal;
            }
            else if(mode < EXT_SGMII)
            {
                if ((retVal = rtl8367c_setAsicRegBit(0x1d3d, 10, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 1, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 0)) != RT_ERR_OK)
                    return retVal;

                if (mode < EXT_GMII)
                {
                    /* set mac6 mode*/
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, mode)) != RT_ERR_OK)
                        return retVal;
                }
                else if(mode == EXT_RMII_MAC)
                {

                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 7)) != RT_ERR_OK)
                        return retVal;
                }
                else if(mode == EXT_RMII_PHY)
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, 8)) != RT_ERR_OK)
                        return retVal;
                }

                if ((mode == EXT_TMII_MAC) || (mode == EXT_TMII_PHY))
                {
                    if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 1, 1)) != RT_ERR_OK)
                        return retVal;
                }
            }

        }
        else if (2 == id)
        {

            /*force port7 linkdown*/
            if ((retVal = rtl8367c_setAsicReg(0x137d, 0x1000)) != RT_ERR_OK)
                    return retVal;

            if ((retVal = rtl8367c_getAsicRegBit(0x1d9d, 7, &reg_data)) != RT_ERR_OK)
                    return retVal;
            while(reg_data == 0)
            {
                if ((retVal = rtl8367c_getAsicRegBit(0x1d9d, 7, &reg_data)) != RT_ERR_OK)
                    return retVal;
            }

            if (mode == EXT_SGMII)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf,0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13c4, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 0, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x2)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 2, 0)) != RT_ERR_OK)
                    return retVal;
            }
            else if (mode == EXT_1000X)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13c4, 0)) != RT_ERR_OK)
                    return retVal;


                if((retVal = rtl8367c_getAsicSdsReg(0, 2, 0, &reg_data)) != RT_ERR_OK)
                    return retVal;
                reg_data &= 0xFFFFFCFF;
                if((retVal = rtl8367c_setAsicSdsReg(0,2,0, reg_data)) != RT_ERR_OK)
                        return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x1d11, 0x1500)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 3)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x4)) != RT_ERR_OK)
                    return retVal;

            }
            else if (mode == EXT_100FX)
            {

                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13c4, 0)) != RT_ERR_OK)
                    return retVal;


                if((retVal = rtl8367c_getAsicSdsReg(0, 2, 0, &reg_data)) != RT_ERR_OK)
                    return retVal;
                reg_data &= 0xFFFFFCFF;
                if((retVal = rtl8367c_setAsicSdsReg(0,2,0, reg_data)) != RT_ERR_OK)
                        return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x1d11, 0x1500)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 3)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x5)) != RT_ERR_OK)
                    return retVal;
            }
            else if (mode == EXT_1000X_100FX)
            {
                /*  disable mac7 MII/TMM/RMII/GMII/RGMII mode, mode_ext2 = disable  */
                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x13c4, 0)) != RT_ERR_OK)
                    return retVal;


                if((retVal = rtl8367c_getAsicSdsReg(0, 2, 0, &reg_data)) != RT_ERR_OK)
                    return retVal;
                reg_data &= 0xFFFFFCFF;
                if((retVal = rtl8367c_setAsicSdsReg(0,2,0, reg_data)) != RT_ERR_OK)
                        return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x1d11, 0x1500)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 5, 0)) != RT_ERR_OK)
                    return retVal;
                if ((retVal = rtl8367c_setAsicRegBit(0x1d41, 7, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 3)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x7)) != RT_ERR_OK)
                    return retVal;
            }
            else if (mode < EXT_SGMII)
            {
                if ((retVal = rtl8367c_setAsicRegBit(0x1d3d, 10, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicReg(0x1d95, 0x1f00)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x13c3, 0xf, mode)) != RT_ERR_OK)
                    return retVal;

                if ((mode == EXT_TMII_MAC) || (mode == EXT_TMII_PHY))
                {
                    if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 1)) != RT_ERR_OK)
                        return retVal;
                }

            }
            else if ((mode < EXT_END) && (mode > EXT_100FX))
            {
                if ((retVal = rtl8367c_setAsicRegBits(0x13C3, 0xf, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 0)) != RT_ERR_OK)
                    return retVal;


                if ((retVal = rtl8367c_setAsicRegBits(0x1d95, 3, 0)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_setAsicRegBit(0x1d3d, 10, 1)) != RT_ERR_OK)
                    return retVal;

                if ((retVal = rtl8367c_getAsicRegBit(0x1d11, 11, &reg_data)) != RT_ERR_OK)
                    return retVal;
                if(reg_data == 0)
                {
                    if ((retVal = rtl8367c_setAsicRegBit(0x1d11, 6, 1)) != RT_ERR_OK)
                        return retVal;
                }


                if (mode < EXT_RMII_MAC_2)
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, (mode-13))) != RT_ERR_OK)
                        return retVal;
                }
                else
                {
                    if ((retVal = rtl8367c_setAsicRegBits(0x1305, 0xf0, (mode-12))) != RT_ERR_OK)
                        return retVal;
                }

                if ((mode == EXT_TMII_MAC_2) || (mode == EXT_TMII_PHY_2))
                {
                    if ((retVal = rtl8367c_setAsicRegBit(0x3f7, 2, 1)) != RT_ERR_OK)
                        return retVal;
                }
            }

        }

    }
    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_getAsicPortExtMode
 * Description:
 *      Get external interface mode configuration
 * Input:
 *      id      - external interface id (0~1)
 *      pMode   - external interface mode
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - Success
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicPortExtMode(rtk_uint32 id, rtk_uint32 *pMode)
{
    ret_t   retVal;
    rtk_uint32 regData, regValue, type;

    if(id >= RTL8367C_EXTNO)
        return RT_ERR_OUT_OF_RANGE;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0249)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_getAsicReg(0x1300, &regValue)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0000)) != RT_ERR_OK)
        return retVal;

    type = 0;

    switch (regValue)
    {
        case 0x0276:
        case 0x0597:
        case 0x6367:
            type = 1;
            break;
        case 0x0652:
        case 0x6368:
            type = 2;
            break;
        case 0x0801:
        case 0x6511:
            type = 3;
            break;
        default:
            return RT_ERR_FAILED;
    }


    if (1 == type)
    {

        if (1 == id)
        {
            if( (retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_SGMII_OFFSET, &regData)) != RT_ERR_OK)
                return retVal;

            if(1 == regData)
            {
                *pMode = EXT_SGMII;
                return RT_ERR_OK;
            }

            if( (retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_HSGMII_OFFSET, &regData)) != RT_ERR_OK)
                return retVal;

            if(1 == regData)
            {
                *pMode = EXT_HSGMII;
                return RT_ERR_OK;
            }
        }

        if(0 == id || 1 == id)
            return rtl8367c_getAsicRegBits(RTL8367C_REG_DIGITAL_INTERFACE_SELECT, RTL8367C_SELECT_GMII_0_MASK << (id * RTL8367C_SELECT_GMII_1_OFFSET), pMode);
        else
           return rtl8367c_getAsicRegBits(RTL8367C_REG_DIGITAL_INTERFACE_SELECT_1, RTL8367C_SELECT_GMII_2_MASK, pMode);

    }
    else if (2 == type)
    {
        if (1 == id)
        {
            if ((retVal = rtl8367c_getAsicReg(0x1d92, &regData))!=RT_ERR_OK)
                return retVal;

            if (regData & 0x4000)
            {
                *pMode = EXT_SGMII;
                return RT_ERR_OK;
            }

            else if (((regData >> 8) & 0x1f) == 4)
            {
                *pMode = EXT_1000X;
                return RT_ERR_OK;
            }
            else if (((regData >> 8) & 0x1f) == 5)
            {
                *pMode = EXT_100FX;
                return RT_ERR_OK;
            }
            else if (((regData >> 8) & 0x1f) == 7)
            {
                *pMode = EXT_1000X_100FX;
                return RT_ERR_OK;
            }

            return rtl8367c_getAsicRegBits(0x1305, 0xf0, pMode);
        }
        else if (2 == id)
        {
#if 0
            if ((retVal = rtl8367c_getAsicRegBit(0x1d92, 6, &regData))!=RT_ERR_OK)
                return retVal;

            if (regData == 1)
            {
                *pMode = EXT_SGMII;
                return RT_ERR_OK;
            }

            if ((retVal = rtl8367c_getAsicRegBit(0x1d92, 7, &regData))!=RT_ERR_OK)
                return retVal;

            if (regData == 1)
            {
                *pMode = EXT_HSGMII;
                return RT_ERR_OK;
            }
#endif
            if ((retVal = rtl8367c_getAsicReg(0x1d92, &regData))!=RT_ERR_OK)
                return retVal;

            if (regData & 0x40)
            {
                *pMode = EXT_SGMII;
                return RT_ERR_OK;
            }
            else if (regData & 0x80)
            {
                *pMode = EXT_HSGMII;
                return RT_ERR_OK;
            }
            else if ((regData & 0x1f) == 4)
            {
                *pMode = EXT_1000X;
                return RT_ERR_OK;
            }
            else if ((regData & 0x1f) == 5)
            {
                *pMode = EXT_100FX;
                return RT_ERR_OK;
            }
            else if ((regData & 0x1f) == 7)
            {
                *pMode = EXT_1000X_100FX;
                return RT_ERR_OK;
            }

            return rtl8367c_getAsicRegBits(0x1305, 0xf, pMode);
        }
    }
    else if(3 == type)
    {
        if (1 == id)
        {
            /* SDS_CFG_NEW */
            if ((retVal = rtl8367c_getAsicReg(0x1d95, &regData))!=RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_getAsicReg(0x1d41, &regValue))!=RT_ERR_OK)
                return retVal;


            if((regValue & 0xa0)  == 0xa0 )
            {

                regData = regData >> 8;
                if((regData & 0x1f) == 4)
                {
                    *pMode = EXT_1000X;
                     return RT_ERR_OK;
                }
                else if((regData & 0x1f) == 5)
                {
                    *pMode = EXT_100FX;
                     return RT_ERR_OK;
                }
                else if((regData & 0x1f) == 7)
                {
                    *pMode = EXT_1000X_100FX;
                     return RT_ERR_OK;
                }

            }


            if ((retVal = rtl8367c_getAsicReg(0x1d11, &regData))!=RT_ERR_OK)
                return retVal;

            /* check cfg_mac6_sel_sgmii */
            if((regData >> 6) & 1)
            {
                *pMode = EXT_SGMII;
                return RT_ERR_OK;
            }
            else if((regData >> 11) & 1)
            {
                *pMode = EXT_HSGMII;
                return RT_ERR_OK;
            }
            else
            {
                /* check port6 MAC mode */
                if ((retVal = rtl8367c_getAsicRegBits(0x1305, 0xf0, &regData))!=RT_ERR_OK)
                    return retVal;

                *pMode = regData;
                return RT_ERR_OK;
            }
        }
        else if (2 == id)
        {
            if ((retVal = rtl8367c_getAsicReg(0x1d95, &regData))!=RT_ERR_OK)
                return retVal;


            if(((regData & 0x3) == 3) && (((regData >> 8) & 0x1f) == 0x4))
            {
                *pMode = EXT_1000X;
                    return RT_ERR_OK;
            }
            else if (((regData & 0x3) == 3) && (((regData >> 8) & 0x1f) == 0x5))
            {
                *pMode = EXT_100FX;
                    return RT_ERR_OK;
            }
            else if (((regData & 0x3) == 3) && (((regData >> 8) & 0x1f) == 0x7))
            {
                *pMode = EXT_1000X_100FX;
                    return RT_ERR_OK;
            }
            else if(regData & 1)
            {
                *pMode = EXT_SGMII;
                return RT_ERR_OK;
            }
            else
            {

                if ((retVal = rtl8367c_getAsicRegBits(0x13c3, 0xf, &regData))!=RT_ERR_OK)
                    return retVal;

                *pMode = regData;

                return RT_ERR_OK;
            }
        }
    }

    return RT_ERR_OK;
}


/* Function Name:
 *      rtl8367c_getAsicPortForceLinkExt
 * Description:
 *      Get external interface force linking configuration
 * Input:
 *      id          - external interface id (0~1)
 *      pPortAbility - port ability configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - Success
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Note:
 *      None
 */
ret_t rtl8367c_getAsicPortForceLinkExt(rtk_uint32 id, rtl8367c_port_ability_t *pPortAbility)
{
    rtk_uint32  reg_data, regValue, type;
    rtk_uint32  sgmiiSel;
    rtk_uint32  hsgmiiSel;
    rtk_uint32  Mode;
    ret_t       retVal;


    if(id >= RTL8367C_EXTNO)
        return RT_ERR_OUT_OF_RANGE;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0249)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_getAsicReg(0x1300, &regValue)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0000)) != RT_ERR_OK)
        return retVal;

    type = 0;

    switch (regValue)
    {
        case 0x0276:
        case 0x0597:
        case 0x6367:
            type = 1;
            break;
        case 0x0652:
        case 0x6368:
            type = 2;
            break;
        case 0x0801:
        case 0x6511:
            type = 3;
            break;
        default:
            return RT_ERR_FAILED;
    }

    if (1 == type)
    {
        if(1 == id)
        {
            if((retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_SGMII_OFFSET, &sgmiiSel)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_MAC8_SEL_HSGMII_OFFSET, &hsgmiiSel)) != RT_ERR_OK)
                return retVal;

            if( (sgmiiSel == 1) || (hsgmiiSel == 1) )
            {
                memset(pPortAbility, 0x00, sizeof(rtl8367c_port_ability_t));
                pPortAbility->forcemode = 1;

                if((retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_FDUP_OFFSET, &reg_data)) != RT_ERR_OK)
                    return retVal;

                pPortAbility->duplex = reg_data;

                if((retVal = rtl8367c_getAsicRegBits(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_SPD_MASK, &reg_data)) != RT_ERR_OK)
                    return retVal;

                pPortAbility->speed = reg_data;

                if((retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_LINK_OFFSET, &reg_data)) != RT_ERR_OK)
                    return retVal;

                pPortAbility->link = reg_data;

                if((retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_TXFC_OFFSET, &reg_data)) != RT_ERR_OK)
                    return retVal;

                pPortAbility->txpause = reg_data;

                if((retVal = rtl8367c_getAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_RXFC_OFFSET, &reg_data)) != RT_ERR_OK)
                    return retVal;

                pPortAbility->rxpause = reg_data;

                return RT_ERR_OK;
            }
        }

        if(0 == id || 1 == id)
            retVal = rtl8367c_getAsicReg(RTL8367C_REG_DIGITAL_INTERFACE0_FORCE+id, &reg_data);
        else
            retVal = rtl8367c_getAsicReg(RTL8367C_REG_DIGITAL_INTERFACE2_FORCE, &reg_data);

        if(retVal != RT_ERR_OK)
            return retVal;

        pPortAbility->forcemode = (reg_data >> 12) & 0x0001;
        pPortAbility->mstfault  = (reg_data >> 9) & 0x0001;
        pPortAbility->mstmode   = (reg_data >> 8) & 0x0001;
        pPortAbility->nway      = (reg_data >> 7) & 0x0001;
        pPortAbility->txpause   = (reg_data >> 6) & 0x0001;
        pPortAbility->rxpause   = (reg_data >> 5) & 0x0001;
        pPortAbility->link      = (reg_data >> 4) & 0x0001;
        pPortAbility->duplex    = (reg_data >> 2) & 0x0001;
        pPortAbility->speed     = reg_data & 0x0003;
    }
    else if (2 == type)
    {
        if (id == 1)
        {
            if ((retVal = rtl8367c_getAsicReg(0x1311, &reg_data))!=RT_ERR_OK)
                return retVal;

            pPortAbility->forcemode = (reg_data >> 12) & 1;
            pPortAbility->duplex = (reg_data >> 2) & 1;
            pPortAbility->link = (reg_data >> 4) & 1;
            pPortAbility->speed = reg_data & 3;
            pPortAbility->rxpause = (reg_data >> 5) & 1;
            pPortAbility->txpause = (reg_data >> 6) & 1;
        }
        else if (2 == id)
        {
            if ((retVal = rtl8367c_getAsicReg(0x13c4, &reg_data))!=RT_ERR_OK)
                return retVal;

            pPortAbility->forcemode = (reg_data >> 12) & 1;
            pPortAbility->duplex = (reg_data >> 2) & 1;
            pPortAbility->link = (reg_data >> 4) & 1;
            pPortAbility->speed = reg_data & 3;
            pPortAbility->rxpause = (reg_data >> 5) & 1;
            pPortAbility->txpause = (reg_data >> 6) & 1;
        }
    }
    else if (3 == type)
    {
        if (id == 1)
        {

            if((retVal = rtl8367c_getAsicPortExtMode(id, &Mode))!=RT_ERR_OK)
                return retVal;
            if(Mode < EXT_SGMII)
            {

                if ((retVal = rtl8367c_getAsicReg(0x1311, &reg_data))!=RT_ERR_OK)
                    return retVal;

                pPortAbility->forcemode = (reg_data >> 12) & 1;
                pPortAbility->duplex = (reg_data >> 2) & 1;
                pPortAbility->link = (reg_data >> 4) & 1;
                pPortAbility->speed = reg_data & 3;
                pPortAbility->rxpause = (reg_data >> 5) & 1;
                pPortAbility->txpause = (reg_data >> 6) & 1;
            }
            else if(Mode < EXT_1000X_100FX)
            {
                if ((retVal = rtl8367c_getAsicReg(0x1d11, &reg_data))!=RT_ERR_OK)
                    return retVal;

                //pPortAbility->forcemode = (reg_data >> 12) & 1;
                pPortAbility->duplex = (reg_data >> 10) & 1;
                pPortAbility->link = (reg_data >> 9) & 1;
                pPortAbility->speed = (reg_data >> 7) & 3;
                pPortAbility->rxpause = (reg_data >> 14) & 1;
                pPortAbility->txpause = (reg_data >> 13) & 1;
            }
            else if(Mode < EXT_RGMII_2)
            {
                if ((retVal = rtl8367c_getAsicReg(0x1358, &reg_data))!=RT_ERR_OK)
                    return retVal;

                //pPortAbility->forcemode = (reg_data >> 12) & 1;
                pPortAbility->duplex = (reg_data >> 2) & 1;
                pPortAbility->link = (reg_data >> 4) & 1;
                pPortAbility->speed = reg_data & 3;
                pPortAbility->rxpause = (reg_data >> 5) & 1;
                pPortAbility->txpause = (reg_data >> 6) & 1;
            }

        }
        else if (2 == id)
        {
            if((retVal = rtl8367c_getAsicPortExtMode(id, &Mode))!=RT_ERR_OK)
                return retVal;
            if(Mode < EXT_SGMII)
            {

                if ((retVal = rtl8367c_getAsicReg(0x13c4, &reg_data))!=RT_ERR_OK)
                    return retVal;

                pPortAbility->forcemode = (reg_data >> 12) & 1;
                pPortAbility->duplex = (reg_data >> 2) & 1;
                pPortAbility->link = (reg_data >> 4) & 1;
                pPortAbility->speed = reg_data & 3;
                pPortAbility->rxpause = (reg_data >> 5) & 1;
                pPortAbility->txpause = (reg_data >> 6) & 1;
            }
            else if(Mode < EXT_1000X_100FX)
            {
                if ((retVal = rtl8367c_getAsicReg(0x1d11, &reg_data))!=RT_ERR_OK)
                    return retVal;

                //pPortAbility->forcemode = (reg_data >> 12) & 1;
                pPortAbility->duplex = (reg_data >> 10) & 1;
                pPortAbility->link = (reg_data >> 9) & 1;
                pPortAbility->speed = (reg_data >> 7) & 3;
                pPortAbility->rxpause = (reg_data >> 14) & 1;
                pPortAbility->txpause = (reg_data >> 13) & 1;
            }
            else if(Mode < EXT_RGMII_2)
            {
                if ((retVal = rtl8367c_getAsicReg(0x1359, &reg_data))!=RT_ERR_OK)
                    return retVal;

                //pPortAbility->forcemode = (reg_data >> 12) & 1;
                pPortAbility->duplex = (reg_data >> 2) & 1;
                pPortAbility->link = (reg_data >> 4) & 1;
                pPortAbility->speed = reg_data & 3;
                pPortAbility->rxpause = (reg_data >> 5) & 1;
                pPortAbility->txpause = (reg_data >> 6) & 1;
            }
            else if(Mode < EXT_END)
            {

                if ((retVal = rtl8367c_getAsicReg(0x1311, &reg_data))!=RT_ERR_OK)
                    return retVal;

                pPortAbility->forcemode = (reg_data >> 12) & 1;
                pPortAbility->duplex = (reg_data >> 2) & 1;
                pPortAbility->link = (reg_data >> 4) & 1;
                pPortAbility->speed = reg_data & 3;
                pPortAbility->rxpause = (reg_data >> 5) & 1;
                pPortAbility->txpause = (reg_data >> 6) & 1;
            }
        }
    }
    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicPortForceLinkExt
 * Description:
 *      Set external interface force linking configuration
 * Input:
 *      id          - external interface id (0~2)
 *      portAbility - port ability configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - Success
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_OUT_OF_RANGE - input parameter out of range
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicPortForceLinkExt(rtk_uint32 id, rtl8367c_port_ability_t *pPortAbility)
{
    rtk_uint32 retVal, regValue, regValue2, type, sgmiibit, hisgmiibit;
    rtk_uint32 reg_data = 0;
    rtk_uint32 i = 0;

    /* Invalid input parameter */
    if(id >= RTL8367C_EXTNO)
        return RT_ERR_OUT_OF_RANGE;

    reg_data |= pPortAbility->forcemode << 12;
    reg_data |= pPortAbility->mstfault << 9;
    reg_data |= pPortAbility->mstmode << 8;
    reg_data |= pPortAbility->nway << 7;
    reg_data |= pPortAbility->txpause << 6;
    reg_data |= pPortAbility->rxpause << 5;
    reg_data |= pPortAbility->link << 4;
    reg_data |= pPortAbility->duplex << 2;
    reg_data |= pPortAbility->speed;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0249)) != RT_ERR_OK)
        return retVal;
    /*get chip ID */
    if((retVal = rtl8367c_getAsicReg(0x1300, &regValue)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0000)) != RT_ERR_OK)
        return retVal;

    type = 0;

    switch (regValue)
    {
        case 0x0276:
        case 0x0597:
        case 0x6367:
            type = 1;
            break;
        case 0x0652:
        case 0x6368:
            type = 2;
            break;
        case 0x0801:
        case 0x6511:
            type = 3;
            break;
        default:
            return RT_ERR_FAILED;
    }

    if (1 == type)
    {
        if(1 == id)
        {
            if ((retVal = rtl8367c_getAsicReg(RTL8367C_REG_REG_TO_ECO4, &regValue)) != RT_ERR_OK)
                return retVal;

            if((regValue & (0x0001 << 5)) && (regValue & (0x0001 << 7)))
            {
                return RT_ERR_OK;
            }

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_FDUP_OFFSET, pPortAbility->duplex)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_SPD_MASK, pPortAbility->speed)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_LINK_OFFSET, pPortAbility->link)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_TXFC_OFFSET, pPortAbility->txpause)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_RXFC_OFFSET, pPortAbility->rxpause)) != RT_ERR_OK)
                return retVal;
        }

        if(0 == id || 1 == id)
            return rtl8367c_setAsicReg(RTL8367C_REG_DIGITAL_INTERFACE0_FORCE + id, reg_data);
        else
            return rtl8367c_setAsicReg(RTL8367C_REG_DIGITAL_INTERFACE2_FORCE, reg_data);
    }
    else if (2 == type)
    {
        if (1 == id)
        {
             if((retVal = rtl8367c_setAsicRegBit(0x1311, 2, pPortAbility->duplex)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBits(0x1311, 0x3, pPortAbility->speed)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, pPortAbility->link)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x1311, 6, pPortAbility->txpause)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x1311, 5, pPortAbility->rxpause)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x1311, 12, pPortAbility->forcemode)) != RT_ERR_OK)
                return retVal;

            if (pPortAbility->link == 1)
            {
                if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, 0)) != RT_ERR_OK)
                    return retVal;

                if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, 1)) != RT_ERR_OK)
                    return retVal;
            }
            else
            {
                if((retVal = rtl8367c_setAsicRegBits(0x1311, 0x3, 2)) != RT_ERR_OK)
                    return retVal;
            }


            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_FDUP_OFFSET, pPortAbility->duplex)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_SPD_MASK, pPortAbility->speed)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_LINK_OFFSET, pPortAbility->link)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_TXFC_OFFSET, pPortAbility->txpause)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_RXFC_OFFSET, pPortAbility->rxpause)) != RT_ERR_OK)
                return retVal;
        }
        else if (2 == id)
        {
            if((retVal = rtl8367c_setAsicRegBit(0x13c4, 2, pPortAbility->duplex)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBits(0x13c4, 0x3, pPortAbility->speed)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x13c4, 4, pPortAbility->link)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x13c4, 6, pPortAbility->txpause)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x13c4, 5, pPortAbility->rxpause)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x13c4, 12, pPortAbility->forcemode)) != RT_ERR_OK)
                return retVal;

            if (pPortAbility->link == 1)
            {
                if((retVal = rtl8367c_setAsicRegBit(0x13c4, 4, 0)) != RT_ERR_OK)
                    return retVal;

                if((retVal = rtl8367c_setAsicRegBit(0x13c4, 4, 1)) != RT_ERR_OK)
                    return retVal;
            }
            else
            {
                if((retVal = rtl8367c_setAsicRegBits(0x13c4, 0x3, 2)) != RT_ERR_OK)
                    return retVal;
            }

            if((retVal = rtl8367c_setAsicRegBit(0x1dc1, RTL8367C_CFG_SGMII_FDUP_OFFSET, pPortAbility->duplex)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBits(0x1dc1, RTL8367C_CFG_SGMII_SPD_MASK, pPortAbility->speed)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x1dc1, RTL8367C_CFG_SGMII_LINK_OFFSET, pPortAbility->link)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x1dc1, RTL8367C_CFG_SGMII_TXFC_OFFSET, pPortAbility->txpause)) != RT_ERR_OK)
                return retVal;

            if((retVal = rtl8367c_setAsicRegBit(0x1dc1, RTL8367C_CFG_SGMII_RXFC_OFFSET, pPortAbility->rxpause)) != RT_ERR_OK)
                return retVal;
        }

    }
    else if(3 == type)
    {
        if(1 == id)
        {
            if((retVal = rtl8367c_getAsicRegBit(0x1d11, 6, &sgmiibit)) != RT_ERR_OK)
                return retVal;
            if((retVal = rtl8367c_getAsicRegBit(0x1d11, 11, &hisgmiibit)) != RT_ERR_OK)
                return retVal;

            if ((sgmiibit == 1) || (hisgmiibit == 1))
            {
                /*for 1000x/100fx/1000x_100fx, param has to be set to serdes registers*/
                if((retVal = rtl8367c_getAsicReg(0x1d41, &regValue)) != RT_ERR_OK)
                    return retVal;


                if((regValue & 0xa0) == 0xa0)
                {

                    if((retVal = rtl8367c_getAsicRegBits(0x1d95, 0x1f00, &regValue2)) != RT_ERR_OK)
                        return retVal;

                     /*1000X*/
                    if(regValue2 == 0x4)
                    {
#if 0
                        /* new_cfg_sds_mode:reset mode */
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                            return retVal;
#endif
                        /* Enable new sds mode config */
                        if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 4*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0x9000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 1,  bit13 set to 0, bit12 nway_en*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFDFFF;
                        reg_data |= 0x40;
                        if(pPortAbility->forcemode)
                            reg_data &= 0xffffefff;
                        else
                            reg_data |= 0x1000;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;

                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data &= (~0x80);

                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &= (~0x100);

                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /*new_cfg_sds_mode=1000x*/
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x4)) != RT_ERR_OK)
                            return retVal;

                    }
                    else if(regValue2 == 0x5)
                    {
#if 0
                        /*100FX*/
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                            return retVal;
#endif

                        if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 5*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0xB000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 0,  bit13 set to 1, bit12 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFFFBF;
                        reg_data |= 0x2000;
                        reg_data &= 0xffffefff;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data &= (~0x80);
                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &= (~0x100);
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;
                       /* new_cfg_sds_mode=1000x */
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x5)) != RT_ERR_OK)
                            return retVal;

                    }
                    else if(regValue2 == 0x7)
                    {
#if 0
                        /*100FX*/
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                            return retVal;
#endif
                        if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 4*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0x9000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 1,  bit13 set to 0, bit12 nway_en*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFDFFF;
                        reg_data |= 0x40;
                        if(pPortAbility->forcemode)
                            reg_data &= 0xffffefff;
                        else
                            reg_data |= 0x1000;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data &= (~0x80);
                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &=(~0x100);
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 5*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0xB000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 0,  bit13 set to 1, bit12 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFFFBF;
                        reg_data |= 0x2000;
                        reg_data &= 0xffffefff;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data &= 0xffffff7f;
                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &= 0xfffffeff;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;
                        /*sds_mode:*/
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x7)) != RT_ERR_OK)
                            return retVal;

                    }

                    /*disable force ability   ---      */
                    if((retVal = rtl8367c_setAsicRegBit(0x137c, 12, 0)) != RT_ERR_OK)
                        return retVal;
                    return RT_ERR_OK;

                }

                /* new_cfg_sds_mode */
                if((retVal = rtl8367c_getAsicRegBits(0x1d95, 0x1f00, &regValue2)) != RT_ERR_OK)
                    return retVal;
                if(regValue2 == 0x2)
                {
#if 0
                    /*SGMII*/
                    if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                        return retVal;
#endif
                    if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                        return retVal;

                    for(i=0;i<0xfff; i++);

                    if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x2)) != RT_ERR_OK)
                        return retVal;

                    for(i=0;i<0xfff; i++);

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_FDUP_OFFSET, pPortAbility->duplex)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_SPD_MASK, pPortAbility->speed)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_TXFC_OFFSET, pPortAbility->txpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_RXFC_OFFSET, pPortAbility->rxpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_LINK_OFFSET, pPortAbility->link)) != RT_ERR_OK)
                        return retVal;

                    /*disable force ability   ---      */
                    if((retVal = rtl8367c_setAsicRegBit(0x137c, 12, 0)) != RT_ERR_OK)
                        return retVal;
                    return RT_ERR_OK;
                }
                else if(regValue2 == 0x12)
                {
#if 0
                    /*HiSGMII*/
                    if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                        return retVal;
#endif
                    if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                        return retVal;

                    for(i=0;i<0xfff; i++);

                    if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x12)) != RT_ERR_OK)
                        return retVal;

                    for(i=0;i<0xfff; i++);

                    if((retVal = rtl8367c_setAsicRegBit(0x1d11, 11, 0x1)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_FDUP_OFFSET, pPortAbility->duplex)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_SPD_MASK, pPortAbility->speed)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_TXFC_OFFSET, pPortAbility->txpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_RXFC_OFFSET, pPortAbility->rxpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_LINK_OFFSET, pPortAbility->link)) != RT_ERR_OK)
                        return retVal;

                    /*disable force ability   ---      */
                    if((retVal = rtl8367c_setAsicRegBit(0x137c, 12, 0)) != RT_ERR_OK)
                        return retVal;
                    return RT_ERR_OK;

                }
            }
            else
            {
                if((retVal = rtl8367c_getAsicRegBits(0x1d3d, 10, &regValue2)) != RT_ERR_OK)
                    return retVal;
                if (regValue2 == 0)
                {
                    /*ext1_force_ablty*/
                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 2, pPortAbility->duplex)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBits(0x1311, 0x3, pPortAbility->speed)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, pPortAbility->link)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 6, pPortAbility->txpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 5, pPortAbility->rxpause)) != RT_ERR_OK)
                        return retVal;

                    /*force mode for ext1*/
                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 12, pPortAbility->forcemode)) != RT_ERR_OK)
                        return retVal;

                    if (pPortAbility->link == 1)
                    {
                        if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, 0)) != RT_ERR_OK)
                            return retVal;

                        if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, 1)) != RT_ERR_OK)
                            return retVal;
                    }
                    else
                    {
                        if((retVal = rtl8367c_setAsicRegBits(0x1311, 0x3, 2)) != RT_ERR_OK)
                            return retVal;
                    }

                    /*disable force ability   ---      */
                    if((retVal = rtl8367c_setAsicRegBit(0x137c, 12, 0)) != RT_ERR_OK)
                        return retVal;
                    return RT_ERR_OK;
                }
            }


        }
        else if (2 == id)
        {

            if((retVal = rtl8367c_getAsicRegBit(0x1d95, 0, &sgmiibit)) != RT_ERR_OK)
                    return retVal;
            if (sgmiibit == 1)
            {
                /*for 1000x/100fx/1000x_100fx, param has to bet set to serdes registers*/
                if((retVal = rtl8367c_getAsicReg(0x1d95, &regValue)) != RT_ERR_OK)
                    return retVal;
                /*cfg_mac7_sel_sgmii=1 & cfg_mac7_fib =1*/
                if((regValue & 0x3) == 0x3)
                {
                    if((retVal = rtl8367c_getAsicRegBits(0x1d95, 0x1f00, &regValue2)) != RT_ERR_OK)
                        return retVal;

                    if(regValue2 == 0x4)
                    {
                        /*1000X*/
#if 0
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                            return retVal;
#endif
                        if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 4*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0x9000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 1,  bit13 set to 0, bit12 nway_en*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFDFFF;
                        reg_data |= 0x40;
                        if(pPortAbility->forcemode)
                            reg_data &= 0xffffefff;
                        else
                            reg_data |= 0x1000;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data &= 0xffffff7f;
                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &= 0xfffffeff;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x4)) != RT_ERR_OK)
                            return retVal;

                    }
                    else if(regValue2 == 0x5)
                    {
                        /*100FX*/
#if 0
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                            return retVal;
#endif
                        if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 5*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0xB000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 0,  bit13 set to 1, bit12 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFFFBF;
                        reg_data |= 0x2000;
                        reg_data &= 0xffffefff;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data &= 0xffffff7f;
                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &= 0xfffffeff;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x5)) != RT_ERR_OK)
                            return retVal;

                    }
                    else if(regValue2 == 0x7)
                    {
                        /*100FX*/
#if 0
                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                            return retVal;
#endif
                        if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 4*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0x9000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 1,  bit13 set to 0, bit12 nway_en*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFDFFF;
                        reg_data |= 0x40;
                        if(pPortAbility->forcemode)
                            reg_data &= 0xffffefff;
                        else
                            reg_data |= 0x1000;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data &= 0xffffff7f;
                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &= 0xfffffeff;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 0  bit 12  set 1,  bit15~13 = 5*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFF0FFF;
                        reg_data |= 0xB000;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 0 2  bit 6  set 0,  bit13 set to 1, bit12 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 0, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFFFBF;
                        reg_data |= 0x2000;
                        reg_data &= 0xffffefff;

                        if((retVal = rtl8367c_setAsicSdsReg(0,0,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                        /* 0 4 2  bit 8  rx pause,  bit7 tx pause*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 2, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        if (pPortAbility->txpause)
                            reg_data |= 0x80;
                        else
                            reg_data  &= 0xffffff7f;
                        if (pPortAbility->rxpause)
                            reg_data |= 0x100;
                        else
                            reg_data &= 0xfffffeff;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,2, reg_data)) != RT_ERR_OK)
                            return retVal;

                         /* 0 4 0  bit 12  set 0*/
                        if((retVal = rtl8367c_getAsicSdsReg(0, 4, 0, &reg_data)) != RT_ERR_OK)
                            return retVal;
                        reg_data &= 0xFFFFEFFF;
                        if((retVal = rtl8367c_setAsicSdsReg(0,4,0, reg_data)) != RT_ERR_OK)
                            return retVal;

                        if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x7)) != RT_ERR_OK)
                            return retVal;

                    }

                    if((retVal = rtl8367c_setAsicRegBit(0x137d, 12, 0)) != RT_ERR_OK)
                        return retVal;
                    return RT_ERR_OK;

                }

                if((retVal = rtl8367c_getAsicRegBits(0x1d95, 0x1f00, &regValue2)) != RT_ERR_OK)
                        return retVal;
                if(regValue2 == 0x2)
                {
                    /*SGMII*/
#if 0
                    if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x1f)) != RT_ERR_OK)
                        return retVal;
#endif
                    if((retVal = rtl8367c_setAsicRegBit(0x1d95, 13, 1)) != RT_ERR_OK)
                        return retVal;

                    for(i=0;i<0xfff; i++);

                    /* 0 2 0  bit 8-9  nway*/
                    if((retVal = rtl8367c_getAsicSdsReg(0, 2, 0, &reg_data)) != RT_ERR_OK)
                        return retVal;
                    reg_data &= 0xfffffcff;
                    if (pPortAbility->nway)
                        reg_data &= 0xfffffcff;
                    else
                        reg_data |= 0x100;
                    if((retVal = rtl8367c_setAsicSdsReg(0,2,0, reg_data)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBits(0x1d95, 0x1f00, 0x2)) != RT_ERR_OK)
                        return retVal;

                    for(i=0;i<0xfff; i++);

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_FDUP_OFFSET, pPortAbility->duplex)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_SPD_MASK, pPortAbility->speed)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_TXFC_OFFSET, pPortAbility->txpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_RXFC_OFFSET, pPortAbility->rxpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_LINK_OFFSET, pPortAbility->link)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x137d, 12, 0)) != RT_ERR_OK)
                        return retVal;
                    return RT_ERR_OK;
                }
            }
            else
            {

                /*ext2_force_ablty*/
                if((retVal = rtl8367c_setAsicRegBit(0x13c4, 2, pPortAbility->duplex)) != RT_ERR_OK)
                    return retVal;

                if((retVal = rtl8367c_setAsicRegBits(0x13c4, 0x3, pPortAbility->speed)) != RT_ERR_OK)
                    return retVal;

                if((retVal = rtl8367c_setAsicRegBit(0x13c4, 4, pPortAbility->link)) != RT_ERR_OK)
                    return retVal;

                if((retVal = rtl8367c_setAsicRegBit(0x13c4, 6, pPortAbility->txpause)) != RT_ERR_OK)
                    return retVal;

                if((retVal = rtl8367c_setAsicRegBit(0x13c4, 5, pPortAbility->rxpause)) != RT_ERR_OK)
                    return retVal;

                /*force mode for ext2*/
                if((retVal = rtl8367c_setAsicRegBit(0x13c4, 12, pPortAbility->forcemode)) != RT_ERR_OK)
                    return retVal;

                if (pPortAbility->link == 1)
                {
                    if((retVal = rtl8367c_setAsicRegBit(0x13c4, 4, 0)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x13c4, 4, 1)) != RT_ERR_OK)
                        return retVal;
                }
                else
                {
                    if((retVal = rtl8367c_setAsicRegBits(0x13c4, 0x3, 2)) != RT_ERR_OK)
                        return retVal;
                }


                if((retVal = rtl8367c_getAsicRegBit(0x1d3d, 10, &reg_data)) != RT_ERR_OK)
                        return retVal;
                if(reg_data == 1)
                {
                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 2, pPortAbility->duplex)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBits(0x1311, 0x3, pPortAbility->speed)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, pPortAbility->link)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 6, pPortAbility->txpause)) != RT_ERR_OK)
                        return retVal;

                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 5, pPortAbility->rxpause)) != RT_ERR_OK)
                        return retVal;

                    /*force mode for ext1*/
                    if((retVal = rtl8367c_setAsicRegBit(0x1311, 12, pPortAbility->forcemode)) != RT_ERR_OK)
                        return retVal;

                    if (pPortAbility->link == 1)
                    {
                        if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, 0)) != RT_ERR_OK)
                            return retVal;

                        if((retVal = rtl8367c_setAsicRegBit(0x1311, 4, 1)) != RT_ERR_OK)
                            return retVal;
                    }
                    else
                    {
                        if((retVal = rtl8367c_setAsicRegBits(0x1311, 0x3, 2)) != RT_ERR_OK)
                            return retVal;
                    }
                }


            }

            /*disable force ability   ---      */
            if((retVal = rtl8367c_setAsicRegBit(0x137d, 12, 0)) != RT_ERR_OK)
                return retVal;
        }
#if 0
        if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_FDUP_OFFSET, pPortAbility->duplex)) != RT_ERR_OK)
            return retVal;

        if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_SPD_MASK, pPortAbility->speed)) != RT_ERR_OK)
            return retVal;

        if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_TXFC_OFFSET, pPortAbility->txpause)) != RT_ERR_OK)
            return retVal;

        if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_RXFC_OFFSET, pPortAbility->rxpause)) != RT_ERR_OK)
            return retVal;

        if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_SDS_MISC, RTL8367C_CFG_SGMII_LINK_OFFSET, pPortAbility->link)) != RT_ERR_OK)
            return retVal;
#endif
    }

    return RT_ERR_OK;
}



/* END SFP API */
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */



/* Function Name:
 *      rtk_switch_probe
 * Description:
 *      Probe switch
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK       - Switch probed
 *      RT_ERR_FAILED   - Switch Unprobed.
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_probe(switch_chip_t *pSwitchChip)
{
    rtk_uint32 retVal;
    rtk_uint32 data;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0249)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_getAsicReg(0x1300, &data)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0000)) != RT_ERR_OK)
        return retVal;

    switch (data)
    {
        case 0x0276:
        case 0x0597:
        case 0x6367:
            *pSwitchChip = CHIP_RTL8367C;
            halCtrl = &rtl8367c_hal_Ctrl;
            break;
        default:
		printf("rtk_switch_probe error: chipdata = %x\r\n", data);
            return RT_ERR_FAILED;
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_switch_initialState_set
 * Description:
 *      Set initial status
 * Input:
 *      state   - Initial state;
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK       - Initialized
 *      RT_ERR_FAILED   - Uninitialized
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_initialState_set(init_state_t state)
{
    if(state >= INIT_STATE_END)
        return RT_ERR_FAILED;

    init_state = state;
    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_switch_initialState_get
 * Description:
 *      Get initial status
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      INIT_COMPLETED     - Initialized
 *      INIT_NOT_COMPLETED - Uninitialized
 * Note:
 *
 */
init_state_t rtk_switch_initialState_get(void)
{
    return init_state;
}

/* Function Name:
 *      rtk_switch_logicalPortCheck
 * Description:
 *      Check logical port ID.
 * Input:
 *      logicalPort     - logical port ID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK       - Port ID is correct
 *      RT_ERR_FAILED   - Port ID is not correct
 *      RT_ERR_NOT_INIT - Not Initialize
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_logicalPortCheck(rtk_port_t logicalPort)
{
    if(init_state != INIT_COMPLETED)
        return RT_ERR_NOT_INIT;

    if(logicalPort >= RTK_SWITCH_PORT_NUM)
        return RT_ERR_FAILED;

    if(halCtrl->l2p_port[logicalPort] == 0xFF)
        return RT_ERR_FAILED;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_switch_isUtpPort
 * Description:
 *      Check is logical port a UTP port
 * Input:
 *      logicalPort     - logical port ID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK       - Port ID is a UTP port
 *      RT_ERR_FAILED   - Port ID is not a UTP port
 *      RT_ERR_NOT_INIT - Not Initialize
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_isUtpPort(rtk_port_t logicalPort)
{
    if(init_state != INIT_COMPLETED)
        return RT_ERR_NOT_INIT;

    if(logicalPort >= RTK_SWITCH_PORT_NUM)
        return RT_ERR_FAILED;

    if(halCtrl->log_port_type[logicalPort] == UTP_PORT)
        return RT_ERR_OK;
    else
        return RT_ERR_FAILED;
}


/* Function Name:
 *      rtk_switch_isHsgPort
 * Description:
 *      Check is logical port a HSG port
 * Input:
 *      logicalPort     - logical port ID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK       - Port ID is a HSG port
 *      RT_ERR_FAILED   - Port ID is not a HSG port
 *      RT_ERR_NOT_INIT - Not Initialize
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_isHsgPort(rtk_port_t logicalPort)
{
    if(init_state != INIT_COMPLETED)
        return RT_ERR_NOT_INIT;

    if(logicalPort >= RTK_SWITCH_PORT_NUM)
        return RT_ERR_FAILED;

    if(logicalPort == halCtrl->hsg_logical_port)
        return RT_ERR_OK;
    else
        return RT_ERR_FAILED;
}

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
/* Function Name:
 *      rtk_switch_isSgmiiPort
 * Description:
 *      Check is logical port a SGMII port
 * Input:
 *      logicalPort     - logical port ID
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK       - Port ID is a SGMII port
 *      RT_ERR_FAILED   - Port ID is not a SGMII port
 *      RT_ERR_NOT_INIT - Not Initialize
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_isSgmiiPort(rtk_port_t logicalPort)
{
    if(init_state != INIT_COMPLETED)
        return RT_ERR_NOT_INIT;

    if(logicalPort >= RTK_SWITCH_PORT_NUM)
        return RT_ERR_FAILED;

    if( ((0x01 << logicalPort) & halCtrl->sg_logical_portmask) != 0)
        return RT_ERR_OK;
    else
        return RT_ERR_FAILED;
}
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */


/* Function Name:
 *      rtk_switch_port_L2P_get
 * Description:
 *      Get physical port ID
 * Input:
 *      logicalPort       - logical port ID
 * Output:
 *      None
 * Return:
 *      Physical port ID
 * Note:
 *
 */
rtk_uint32 rtk_switch_port_L2P_get(rtk_port_t logicalPort)
{
    if(init_state != INIT_COMPLETED)
        return UNDEFINE_PHY_PORT;

    if(logicalPort >= RTK_SWITCH_PORT_NUM)
        return UNDEFINE_PHY_PORT;

    return (halCtrl->l2p_port[logicalPort]);
}

/* Function Name:
 *      rtk_switch_port_P2L_get
 * Description:
 *      Get logical port ID
 * Input:
 *      physicalPort       - physical port ID
 * Output:
 *      None
 * Return:
 *      logical port ID
 * Note:
 *
 */
rtk_port_t rtk_switch_port_P2L_get(rtk_uint32 physicalPort)
{
    if(init_state != INIT_COMPLETED)
        return UNDEFINE_PORT;

    if(physicalPort >= RTK_SWITCH_PORT_NUM)
        return UNDEFINE_PORT;

    return (halCtrl->p2l_port[physicalPort]);
}

/* Function Name:
 *      rtk_switch_isPortMaskValid
 * Description:
 *      Check portmask is valid or not
 * Input:
 *      pPmask       - logical port mask
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - port mask is valid
 *      RT_ERR_FAILED       - port mask is not valid
 *      RT_ERR_NOT_INIT     - Not Initialize
 *      RT_ERR_NULL_POINTER - Null pointer
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_isPortMaskValid(rtk_portmask_t *pPmask)
{
    if(init_state != INIT_COMPLETED)
        return RT_ERR_NOT_INIT;

    if(NULL == pPmask)
        return RT_ERR_NULL_POINTER;

    if( (pPmask->bits[0] | halCtrl->valid_portmask) != halCtrl->valid_portmask )
        return RT_ERR_FAILED;
    else
        return RT_ERR_OK;
}

/* Function Name:
 *      rtk_switch_maxMeterId_get
 * Description:
 *      Get Max Meter ID
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      0x00                - Not Initialize
 *      Other value         - Max Meter ID
 * Note:
 *
 */
rtk_uint32 rtk_switch_maxMeterId_get(void)
{
    if(init_state != INIT_COMPLETED)
        return 0x00;

    return (halCtrl->max_meter_id);
}

/* Function Name:
 *      rtk_switch_maxLutAddrNumber_get
 * Description:
 *      Get Max LUT Address number
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      0x00                - Not Initialize
 *      Other value         - Max LUT Address number
 * Note:
 *
 */
rtk_uint32 rtk_switch_maxLutAddrNumber_get(void)
{
    if(init_state != INIT_COMPLETED)
        return 0x00;

    return (halCtrl->max_lut_addr_num);
}

/* Function Name:
 *      rtk_switch_portmask_L2P_get
 * Description:
 *      Get physicl portmask from logical portmask
 * Input:
 *      pLogicalPmask       - logical port mask
 * Output:
 *      pPhysicalPortmask   - physical port mask
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_NOT_INIT     - Not Initialize
 *      RT_ERR_NULL_POINTER - Null pointer
 *      RT_ERR_PORT_MASK    - Error port mask
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_portmask_L2P_get(rtk_portmask_t *pLogicalPmask, rtk_uint32 *pPhysicalPortmask)
{
    rtk_uint32 log_port, phy_port;

    if(init_state != INIT_COMPLETED)
        return RT_ERR_NOT_INIT;

    if(NULL == pLogicalPmask)
        return RT_ERR_NULL_POINTER;

    if(NULL == pPhysicalPortmask)
        return RT_ERR_NULL_POINTER;

    if(rtk_switch_isPortMaskValid(pLogicalPmask) != RT_ERR_OK)
        return RT_ERR_PORT_MASK;

    /* reset physical port mask */
    *pPhysicalPortmask = 0;

    RTK_PORTMASK_SCAN((*pLogicalPmask), log_port)
    {
        phy_port = rtk_switch_port_L2P_get((rtk_port_t)log_port);
        *pPhysicalPortmask |= (0x0001 << phy_port);
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_switch_portmask_P2L_get
 * Description:
 *      Get logical portmask from physical portmask
 * Input:
 *      physicalPortmask    - physical port mask
 * Output:
 *      pLogicalPmask       - logical port mask
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_NOT_INIT     - Not Initialize
 *      RT_ERR_NULL_POINTER - Null pointer
 *      RT_ERR_PORT_MASK    - Error port mask
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_portmask_P2L_get(rtk_uint32 physicalPortmask, rtk_portmask_t *pLogicalPmask)
{
    rtk_uint32 log_port, phy_port;

    if(init_state != INIT_COMPLETED)
        return RT_ERR_NOT_INIT;

    if(NULL == pLogicalPmask)
        return RT_ERR_NULL_POINTER;

    RTK_PORTMASK_CLEAR(*pLogicalPmask);

    for(phy_port = halCtrl->min_phy_port; phy_port <= halCtrl->max_phy_port; phy_port++)
    {
        if(physicalPortmask & (0x0001 << phy_port))
        {
            log_port = rtk_switch_port_P2L_get(phy_port);
            if(log_port != UNDEFINE_PORT)
            {
                RTK_PORTMASK_PORT_SET(*pLogicalPmask, log_port);
            }
        }
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_switch_phyPortMask_get
 * Description:
 *      Get physical portmask
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      0x00                - Not Initialize
 *      Other value         - Physical port mask
 * Note:
 *
 */
rtk_uint32 rtk_switch_phyPortMask_get(void)
{
    if(init_state != INIT_COMPLETED)
        return 0x00; /* No port in portmask */

    return (halCtrl->phy_portmask);
}

/* Function Name:
 *      rtk_switch_logPortMask_get
 * Description:
 *      Get Logical portmask
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_NOT_INIT     - Not Initialize
 *      RT_ERR_NULL_POINTER - Null pointer
 * Note:
 *
 */
rtk_api_ret_t rtk_switch_logPortMask_get(rtk_portmask_t *pPortmask)
{
    if(init_state != INIT_COMPLETED)
        return RT_ERR_FAILED;

    if(NULL == pPortmask)
        return RT_ERR_NULL_POINTER;

    pPortmask->bits[0] = halCtrl->valid_portmask;
    return RT_ERR_OK;
}

static rtk_api_ret_t _rtk_switch_init_8367c(void)
{
    rtk_port_t port;
    rtk_uint32 retVal;
    rtk_uint32 regData;
    rtk_uint32 regValue;

    if( (retVal = rtl8367c_setAsicReg(0x13c2, 0x0249)) != RT_ERR_OK)
        return retVal;

    if( (retVal = rtl8367c_getAsicReg(0x1301, &regValue)) != RT_ERR_OK)
        return retVal;

    if( (retVal = rtl8367c_setAsicReg(0x13c2, 0x0000)) != RT_ERR_OK)
        return retVal;

    RTK_SCAN_ALL_LOG_PORT(port)
    {
         if(rtk_switch_isUtpPort(port) == RT_ERR_OK)
         {
             if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_PORT0_EEECFG + (0x20 * port), RTL8367C_PORT0_EEECFG_EEE_100M_OFFSET, 1)) != RT_ERR_OK)
                 return retVal;

             if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_PORT0_EEECFG + (0x20 * port), RTL8367C_PORT0_EEECFG_EEE_GIGA_500M_OFFSET, 1)) != RT_ERR_OK)
                 return retVal;

             if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_PORT0_EEECFG + (0x20 * port), RTL8367C_PORT0_EEECFG_EEE_TX_OFFSET, 1)) != RT_ERR_OK)
                 return retVal;

             if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_PORT0_EEECFG + (0x20 * port), RTL8367C_PORT0_EEECFG_EEE_RX_OFFSET, 1)) != RT_ERR_OK)
                 return retVal;

             if((retVal = rtl8367c_getAsicPHYOCPReg(port, 0xA428, &regData)) != RT_ERR_OK)
                return retVal;

             regData &= ~(0x0200);
             if((retVal = rtl8367c_setAsicPHYOCPReg(port, 0xA428, regData)) != RT_ERR_OK)
                 return retVal;

             if((regValue & 0x00F0) == 0x00A0)
             {
                 if((retVal = rtl8367c_getAsicPHYOCPReg(port, 0xA5D0, &regData)) != RT_ERR_OK)
                     return retVal;

                 regData |= 0x0006;
                 if((retVal = rtl8367c_setAsicPHYOCPReg(port, 0xA5D0, regData)) != RT_ERR_OK)
                     return retVal;
             }
         }
    }

    if((retVal = rtl8367c_setAsicReg(RTL8367C_REG_UTP_FIB_DET, 0x15BB)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x1303, 0x06D6)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x1304, 0x0700)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13E2, 0x003F)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13F9, 0x0090)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x121e, 0x03CA)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x1233, 0x0352)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x1237, 0x00a0)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x123a, 0x0030)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x1239, 0x0084)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x0301, 0x1000)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x1349, 0x001F)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicRegBit(0x18e0, 0, 0)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicRegBit(0x122b, 14, 1)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicRegBits(0x1305, 0xC000, 3)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_rate_igrBandwidthCtrlRate_set
 * Description:
 *      Set port ingress bandwidth control
 * Input:
 *      port        - Port id
 *      rate        - Rate of share meter
 *      ifg_include - include IFG or not, ENABLE:include DISABLE:exclude
 *      fc_enable   - enable flow control or not, ENABLE:use flow control DISABLE:drop
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_PORT_ID 		- Invalid port number.
 *      RT_ERR_ENABLE 		- Invalid IFG parameter.
 *      RT_ERR_INBW_RATE 	- Invalid ingress rate parameter.
 * Note:
 *      The rate unit is 1 kbps and the range is from 8k to 1048568k. The granularity of rate is 8 kbps.
 *      The ifg_include parameter is used for rate calculation with/without inter-frame-gap and preamble.
 */
rtk_api_ret_t rtk_rate_igrBandwidthCtrlRate_set(rtk_port_t port, rtk_rate_t rate, rtk_enable_t ifg_include, rtk_enable_t fc_enable)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_VALID(port);

    if(ifg_include >= RTK_ENABLE_END)
        return RT_ERR_INPUT;

    if(fc_enable >= RTK_ENABLE_END)
        return RT_ERR_INPUT;

    if(rtk_switch_isHsgPort(port) == RT_ERR_OK)
    {
        if ((rate > RTL8367C_QOS_RATE_INPUT_MAX_HSG) || (rate < RTL8367C_QOS_RATE_INPUT_MIN))
            return RT_ERR_QOS_EBW_RATE ;
    }
    else
    {
        if ((rate > RTL8367C_QOS_RATE_INPUT_MAX) || (rate < RTL8367C_QOS_RATE_INPUT_MIN))
            return RT_ERR_QOS_EBW_RATE ;
    }

    if (ifg_include >= RTK_ENABLE_END)
        return RT_ERR_ENABLE;

    if ((retVal = rtl8367c_setAsicPortIngressBandwidth(rtk_switch_port_L2P_get(port), rate>>3, ifg_include,fc_enable)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_rate_egrBandwidthCtrlRate_set
 * Description:
 *      Set port egress bandwidth control
 * Input:
 *      port        - Port id
 *      rate        - Rate of egress bandwidth
 *      ifg_include - include IFG or not, ENABLE:include DISABLE:exclude
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_PORT_ID 		- Invalid port number.
 *      RT_ERR_INPUT 		- Invalid input parameters.
 *      RT_ERR_QOS_EBW_RATE - Invalid egress bandwidth/rate
 * Note:
 *     The rate unit is 1 kbps and the range is from 8k to 1048568k. The granularity of rate is 8 kbps.
 *     The ifg_include parameter is used for rate calculation with/without inter-frame-gap and preamble.
 */
rtk_api_ret_t rtk_rate_egrBandwidthCtrlRate_set( rtk_port_t port, rtk_rate_t rate,  rtk_enable_t ifg_include)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_VALID(port);

    if(rtk_switch_isHsgPort(port) == RT_ERR_OK)
    {
        if ((rate > RTL8367C_QOS_RATE_INPUT_MAX_HSG) || (rate < RTL8367C_QOS_RATE_INPUT_MIN))
            return RT_ERR_QOS_EBW_RATE ;
    }
    else
    {
        if ((rate > RTL8367C_QOS_RATE_INPUT_MAX) || (rate < RTL8367C_QOS_RATE_INPUT_MIN))
            return RT_ERR_QOS_EBW_RATE ;
    }

    if (ifg_include >= RTK_ENABLE_END)
        return RT_ERR_ENABLE;

    if ((retVal = rtl8367c_setAsicPortEgressRate(rtk_switch_port_L2P_get(port), rate>>3)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPortEgressRateIfg(ifg_include)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_switch_init
 * Description:
 *      Set chip to default configuration enviroment
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 * Note:
 *      The API can set chip registers to default configuration for different release chip model.
 */
rtk_api_ret_t rtk_switch_init(void)
{
    rtk_uint32  retVal;
    rtl8367c_rma_t rmaCfg;
    switch_chip_t   switchChip;

    /* probe switch */
    if((retVal = rtk_switch_probe(&switchChip)) != RT_ERR_OK)
        return retVal;

    /* Set initial state */

    if((retVal = rtk_switch_initialState_set(INIT_COMPLETED)) != RT_ERR_OK)
        return retVal;

    /* Initial */
    switch(switchChip)
    {
        case CHIP_RTL8367C:
            if((retVal = _rtk_switch_init_8367c()) != RT_ERR_OK)
                return retVal;
            break;
        default:
            return RT_ERR_CHIP_NOT_FOUND;
    }

    /* Set Old max packet length to 16K */
    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_MAX_LENGTH_LIMINT_IPG, RTL8367C_MAX_LENTH_CTRL_MASK, 3)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_MAX_LEN_RX_TX, RTL8367C_MAX_LEN_RX_TX_MASK, 3)) != RT_ERR_OK)
        return retVal;

    /* ACL Mode */
    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_ACL_ACCESS_MODE, RTL8367C_ACL_ACCESS_MODE_MASK, 1)) != RT_ERR_OK)
        return retVal;

    /* Max rate */
    if((retVal = rtk_rate_igrBandwidthCtrlRate_set(halCtrl->hsg_logical_port, RTL8367C_QOS_RATE_INPUT_MAX_HSG, DISABLED, ENABLED)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtk_rate_egrBandwidthCtrlRate_set(halCtrl->hsg_logical_port, RTL8367C_QOS_RATE_INPUT_MAX_HSG, ENABLED)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x03fa, 0x0007)) != RT_ERR_OK)
        return retVal;

    /* Change unknown DA to per port setting */
    if((retVal = rtl8367c_setAsicRegBits(RTL8367C_PORT_SECURIT_CTRL_REG, RTL8367C_UNKNOWN_UNICAST_DA_BEHAVE_MASK, 3)) != RT_ERR_OK)
        return retVal;

    /* LUT lookup OP = 1 */
    if ((retVal = rtl8367c_setAsicLutIpLookupMethod(1))!=RT_ERR_OK)
        return retVal;

    /* Set RMA */
    rmaCfg.portiso_leaky = 0;
    rmaCfg.vlan_leaky = 0;
    rmaCfg.keep_format = 0;
    rmaCfg.trap_priority = 0;
    rmaCfg.discard_storm_filter = 0;
    rmaCfg.operation = 0;
    if ((retVal = rtl8367c_setAsicRma(2, &rmaCfg))!=RT_ERR_OK)
        return retVal;

    /* Enable TX Mirror isolation leaky */
    if ((retVal = rtl8367c_setAsicPortMirrorIsolationTxLeaky(ENABLED)) != RT_ERR_OK)
        return retVal;

    /* INT EN */
    if((retVal = rtl8367c_setAsicRegBit(RTL8367C_REG_IO_MISC_FUNC, RTL8367C_INT_EN_OFFSET, 1)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_port_phyReg_set
 * Description:
 *      Set PHY register data of the specific port.
 * Input:
 *      port    - port id.
 *      reg     - Register id
 *      regData - Register data
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK               - OK
 *      RT_ERR_FAILED           - Failed
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_PORT_ID          - Invalid port number.
 *      RT_ERR_PHY_REG_ID       - Invalid PHY address
 *      RT_ERR_BUSYWAIT_TIMEOUT - PHY access busy
 * Note:
 *      This API can set PHY register data of the specific port.
 */
rtk_api_ret_t rtk_port_phyReg_set(rtk_port_t port, rtk_port_phy_reg_t reg, rtk_port_phy_data_t regData)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_IS_UTP(port);

    if ((retVal = rtl8367c_setAsicPHYReg(rtk_switch_port_L2P_get(port), reg, regData)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_port_phyReg_get
 * Description:
 *      Get PHY register data of the specific port.
 * Input:
 *      port    - Port id.
 *      reg     - Register id
 * Output:
 *      pData   - Register data
 * Return:
 *      RT_ERR_OK               - OK
 *      RT_ERR_FAILED           - Failed
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_PORT_ID          - Invalid port number.
 *      RT_ERR_PHY_REG_ID       - Invalid PHY address
 *      RT_ERR_BUSYWAIT_TIMEOUT - PHY access busy
 * Note:
 *      This API can get PHY register data of the specific port.
 */
rtk_api_ret_t rtk_port_phyReg_get(rtk_port_t port, rtk_port_phy_reg_t reg, rtk_port_phy_data_t *pData)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_IS_UTP(port);

    if ((retVal = rtl8367c_getAsicPHYReg(rtk_switch_port_L2P_get(port), reg, pData)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_port_phyEnableAll_set
 * Description:
 *      Set all PHY enable status.
 * Input:
 *      enable - PHY Enable State.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_ENABLE       - Invalid enable input.
 * Note:
 *      This API can set all PHY status.
 *      The configuration of all PHY is as following:
 *      - DISABLE
 *      - ENABLE
 */
rtk_api_ret_t rtk_port_phyEnableAll_set(rtk_enable_t enable)
{
    rtk_api_ret_t retVal;
    rtk_uint32 data;
    rtk_uint32 port;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if (enable >= RTK_ENABLE_END)
        return RT_ERR_ENABLE;

    if ((retVal = rtl8367c_setAsicPortEnableAll(enable)) != RT_ERR_OK)
        return retVal;

    RTK_SCAN_ALL_LOG_PORT(port)
    {
        if(rtk_switch_isUtpPort(port) == RT_ERR_OK)
        {
            if ((retVal = rtk_port_phyReg_get(port, PHY_CONTROL_REG, &data)) != RT_ERR_OK)
                return retVal;

            if (ENABLED == enable)
            {
                data &= 0xF7FF;
                data |= 0x0200;
            }
            else
            {
                data |= 0x0800;
            }

            if ((retVal = rtk_port_phyReg_set(port, PHY_CONTROL_REG, data)) != RT_ERR_OK)
                return retVal;
        }
    }

    return RT_ERR_OK;

}

#define MIB_NOT_SUPPORT     (0xFFFF)
static rtk_api_ret_t _get_asic_mib_idx(rtk_stat_port_type_t cnt_idx, RTL8367C_MIBCOUNTER *pMib_idx)
{
    RTL8367C_MIBCOUNTER mib_asic_idx[STAT_PORT_CNTR_END]=
    {
        ifInOctets,                     /* STAT_IfInOctets */
        dot3StatsFCSErrors,             /* STAT_Dot3StatsFCSErrors */
        dot3StatsSymbolErrors,          /* STAT_Dot3StatsSymbolErrors */
        dot3InPauseFrames,              /* STAT_Dot3InPauseFrames */
        dot3ControlInUnknownOpcodes,    /* STAT_Dot3ControlInUnknownOpcodes */
        etherStatsFragments,            /* STAT_EtherStatsFragments */
        etherStatsJabbers,              /* STAT_EtherStatsJabbers */
        ifInUcastPkts,                  /* STAT_IfInUcastPkts */
        etherStatsDropEvents,           /* STAT_EtherStatsDropEvents */
        etherStatsOctets,               /* STAT_EtherStatsOctets */
        etherStatsUnderSizePkts,        /* STAT_EtherStatsUnderSizePkts */
        etherOversizeStats,             /* STAT_EtherOversizeStats */
        etherStatsPkts64Octets,         /* STAT_EtherStatsPkts64Octets */
        etherStatsPkts65to127Octets,    /* STAT_EtherStatsPkts65to127Octets */
        etherStatsPkts128to255Octets,   /* STAT_EtherStatsPkts128to255Octets */
        etherStatsPkts256to511Octets,   /* STAT_EtherStatsPkts256to511Octets */
        etherStatsPkts512to1023Octets,  /* STAT_EtherStatsPkts512to1023Octets */
        etherStatsPkts1024to1518Octets, /* STAT_EtherStatsPkts1024to1518Octets */
        ifInMulticastPkts,              /* STAT_EtherStatsMulticastPkts */
        ifInBroadcastPkts,              /* STAT_EtherStatsBroadcastPkts */
        ifOutOctets,                    /* STAT_IfOutOctets */
        dot3StatsSingleCollisionFrames, /* STAT_Dot3StatsSingleCollisionFrames */
        dot3StatMultipleCollisionFrames,/* STAT_Dot3StatsMultipleCollisionFrames */
        dot3sDeferredTransmissions,     /* STAT_Dot3StatsDeferredTransmissions */
        dot3StatsLateCollisions,        /* STAT_Dot3StatsLateCollisions */
        etherStatsCollisions,           /* STAT_EtherStatsCollisions */
        dot3StatsExcessiveCollisions,   /* STAT_Dot3StatsExcessiveCollisions */
        dot3OutPauseFrames,             /* STAT_Dot3OutPauseFrames */
        MIB_NOT_SUPPORT,                /* STAT_Dot1dBasePortDelayExceededDiscards */
        dot1dTpPortInDiscards,          /* STAT_Dot1dTpPortInDiscards */
        ifOutUcastPkts,                 /* STAT_IfOutUcastPkts */
        ifOutMulticastPkts,             /* STAT_IfOutMulticastPkts */
        ifOutBroadcastPkts,             /* STAT_IfOutBroadcastPkts */
        outOampduPkts,                  /* STAT_OutOampduPkts */
        inOampduPkts,                   /* STAT_InOampduPkts */
        MIB_NOT_SUPPORT,                /* STAT_PktgenPkts */
        inMldChecksumError,             /* STAT_InMldChecksumError */
        inIgmpChecksumError,            /* STAT_InIgmpChecksumError */
        inMldSpecificQuery,             /* STAT_InMldSpecificQuery */
        inMldGeneralQuery,              /* STAT_InMldGeneralQuery */
        inIgmpSpecificQuery,            /* STAT_InIgmpSpecificQuery */
        inIgmpGeneralQuery,             /* STAT_InIgmpGeneralQuery */
        inMldLeaves,                    /* STAT_InMldLeaves */
        inIgmpLeaves,          			/* STAT_InIgmpInterfaceLeaves */
        inIgmpJoinsSuccess,             /* STAT_InIgmpJoinsSuccess */
        inIgmpJoinsFail,                /* STAT_InIgmpJoinsFail */
        inMldJoinsSuccess,              /* STAT_InMldJoinsSuccess */
        inMldJoinsFail,                 /* STAT_InMldJoinsFail */
        inReportSuppressionDrop,        /* STAT_InReportSuppressionDrop */
        inLeaveSuppressionDrop,         /* STAT_InLeaveSuppressionDrop */
        outIgmpReports,                 /* STAT_OutIgmpReports */
        outIgmpLeaves,                  /* STAT_OutIgmpLeaves */
        outIgmpGeneralQuery,            /* STAT_OutIgmpGeneralQuery */
        outIgmpSpecificQuery,           /* STAT_OutIgmpSpecificQuery */
        outMldReports,                  /* STAT_OutMldReports */
        outMldLeaves,                   /* STAT_OutMldLeaves */
        outMldGeneralQuery,             /* STAT_OutMldGeneralQuery */
        outMldSpecificQuery,            /* STAT_OutMldSpecificQuery */
        inKnownMulticastPkts,           /* STAT_InKnownMulticastPkts */
        ifInMulticastPkts,              /* STAT_IfInMulticastPkts */
        ifInBroadcastPkts,              /* STAT_IfInBroadcastPkts */
        ifOutDiscards                   /* STAT_IfOutDiscards */
    };

    if(cnt_idx >= STAT_PORT_CNTR_END)
        return RT_ERR_STAT_INVALID_PORT_CNTR;

    if(mib_asic_idx[cnt_idx] == MIB_NOT_SUPPORT)
        return RT_ERR_CHIP_NOT_SUPPORTED;

    *pMib_idx = mib_asic_idx[cnt_idx];
    return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_getAsicMIBsCounter
 * Description:
 *      Get MIBs counter
 * Input:
 *      port 		- Physical port number (0~7)
 *      mibIdx 		- MIB counter index
 *      pCounter 	- MIB retrived counter
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 *      RT_ERR_PORT_ID  		- Invalid port number
 *      RT_ERR_BUSYWAIT_TIMEOUT - MIB is busy at retrieving
 *      RT_ERR_STAT_CNTR_FAIL  	- MIB is resetting
 * Note:
 * 		Before MIBs counter retrieving, writting accessing address to ASIC at first and check the MIB
 * 		control register status. If busy bit of MIB control is set, that means MIB counter have been
 * 		waiting for preparing, then software must wait atfer this busy flag reset by ASIC. This driver
 * 		did not recycle reading user desired counter. Software must use driver again to get MIB counter
 * 		if return value is not RT_ERR_OK.
 */
ret_t rtl8367c_getAsicMIBsCounter(rtk_uint32 port, RTL8367C_MIBCOUNTER mibIdx, rtk_uint64* pCounter)
{
	ret_t retVal;
	rtk_uint32 regAddr;
	rtk_uint32 regData;
	rtk_uint32 mibAddr;
	rtk_uint32 mibOff=0;

	/* address offset to MIBs counter */
	CONST rtk_uint16 mibLength[RTL8367C_MIBS_NUMBER]= {
        4,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
        4,2,2,2,2,2,2,2,2,
        4,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
        2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2};

	rtk_uint16 i;
	rtk_uint64 mibCounter;


	if(port > RTL8367C_PORTIDMAX)
		return RT_ERR_PORT_ID;

	if(mibIdx >= RTL8367C_MIBS_NUMBER)
		return RT_ERR_STAT_INVALID_CNTR;

	if(dot1dTpLearnedEntryDiscards == mibIdx)
	{
		mibAddr = RTL8367C_MIB_LEARNENTRYDISCARD_OFFSET;
	}
	else
	{
		i = 0;
		mibOff = RTL8367C_MIB_PORT_OFFSET * port;

		if(port > 7)
			mibOff = mibOff + 68;

		while(i < mibIdx)
		{
			mibOff += mibLength[i];
			i++;
		}

		mibAddr = mibOff;
	}


	/*writing access counter address first*/
    /*This address is SRAM address, and SRAM address = MIB register address >> 2*/
	/*then ASIC will prepare 64bits counter wait for being retrived*/
	/*Write Mib related address to access control register*/
	retVal = rtl8367c_setAsicReg(RTL8367C_REG_MIB_ADDRESS, (mibAddr >> 2));
	if(retVal != RT_ERR_OK)
		return retVal;



    /* polling busy flag */
    i = 100;
    while(i > 0)
    {
        /*read MIB control register*/
        retVal = rtl8367c_getAsicReg(RTL8367C_MIB_CTRL_REG,&regData);

        if((regData & RTL8367C_MIB_CTRL0_BUSY_FLAG_MASK) == 0)
        {
            break;
        }

        i--;
    }

	if(regData & RTL8367C_MIB_CTRL0_BUSY_FLAG_MASK)
		return RT_ERR_BUSYWAIT_TIMEOUT;

	if(regData & RTL8367C_RESET_FLAG_MASK)
		return RT_ERR_STAT_CNTR_FAIL;

	mibCounter = 0;
	i = mibLength[mibIdx];
	if(4 == i)
		regAddr = RTL8367C_MIB_COUNTER_BASE_REG + 3;
	else
		regAddr = RTL8367C_MIB_COUNTER_BASE_REG + ((mibOff + 1) % 4);

	while(i)
	{
		retVal = rtl8367c_getAsicReg(regAddr, &regData);
		if(retVal != RT_ERR_OK)
			return retVal;

		mibCounter = (mibCounter << 16) | (regData & 0xFFFF);

		regAddr --;
		i --;

	}

	*pCounter = mibCounter;

	return RT_ERR_OK;
}

/* Function Name:
 *      rtl8367c_setAsicMIBsCounterReset
 * Description:
 *      Reset global/queue manage or per-port MIB counter
 * Input:
 *      greset 	- Global reset
 *      qmreset - Queue maganement reset
 *      portmask 	- Port reset mask
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK 				- Success
 *      RT_ERR_SMI  			- SMI access error
 * Note:
 *      None
 */
ret_t rtl8367c_setAsicMIBsCounterReset(rtk_uint32 greset, rtk_uint32 qmreset, rtk_uint32 portmask)
{
	ret_t retVal;
	rtk_uint32 regData;
	rtk_uint32 regBits;

	regBits = RTL8367C_GLOBAL_RESET_MASK |
				RTL8367C_QM_RESET_MASK |
					RTL8367C_MIB_PORT07_MASK |
					((rtk_uint32)0x7 << 13);
	regData = ((greset << RTL8367C_GLOBAL_RESET_OFFSET) & RTL8367C_GLOBAL_RESET_MASK) |
				((qmreset << RTL8367C_QM_RESET_OFFSET) & RTL8367C_QM_RESET_MASK) |
				(((portmask & 0xFF) << RTL8367C_PORT0_RESET_OFFSET) & RTL8367C_MIB_PORT07_MASK) |
				(((portmask >> 8)&0x7) << 13);


	retVal = rtl8367c_setAsicRegBits(RTL8367C_REG_MIB_CTRL0, regBits, (regData >> RTL8367C_PORT0_RESET_OFFSET));

	return retVal;
}

/* Function Name:
 *      rtk_stat_port_reset
 * Description:
 *      Reset per port MIB counter by port.
 * Input:
 *      port - port id.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 * Note:
 *
 */
rtk_api_ret_t rtk_stat_port_reset(rtk_port_t port)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check port valid */
    RTK_CHK_PORT_VALID(port);

    if ((retVal = rtl8367c_setAsicMIBsCounterReset(FALSE,FALSE,1 << rtk_switch_port_L2P_get(port))) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_stat_port_get
 * Description:
 *      Get per port MIB counter by index
 * Input:
 *      port        - port id.
 *      cntr_idx    - port counter index.
 * Output:
 *      pCntr - MIB retrived counter.
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 * Note:
 *      Get per port MIB counter by index definition.
 */
rtk_api_ret_t rtk_stat_port_get(rtk_port_t port, rtk_stat_port_type_t cntr_idx, rtk_stat_counter_t *pCntr)
{
    rtk_api_ret_t       retVal;
    RTL8367C_MIBCOUNTER mib_idx;
    rtk_stat_counter_t  second_cnt;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pCntr)
        return RT_ERR_NULL_POINTER;

    /* Check port valid */
    RTK_CHK_PORT_VALID(port);

    if (cntr_idx>=STAT_PORT_CNTR_END)
        return RT_ERR_STAT_INVALID_PORT_CNTR;

    if((retVal = _get_asic_mib_idx(cntr_idx, &mib_idx)) != RT_ERR_OK)
        return retVal;

    if(mib_idx == MIB_NOT_SUPPORT)
        return RT_ERR_CHIP_NOT_SUPPORTED;

    if ((retVal = rtl8367c_getAsicMIBsCounter(rtk_switch_port_L2P_get(port), mib_idx, pCntr)) != RT_ERR_OK)
        return retVal;

    if(cntr_idx == STAT_EtherStatsMulticastPkts)
    {
        if((retVal = _get_asic_mib_idx(STAT_IfOutMulticastPkts, &mib_idx)) != RT_ERR_OK)
            return retVal;

        if((retVal = rtl8367c_getAsicMIBsCounter(rtk_switch_port_L2P_get(port), mib_idx, &second_cnt)) != RT_ERR_OK)
            return retVal;

        *pCntr += second_cnt;
    }

    if(cntr_idx == STAT_EtherStatsBroadcastPkts)
    {
        if((retVal = _get_asic_mib_idx(STAT_IfOutBroadcastPkts, &mib_idx)) != RT_ERR_OK)
            return retVal;

        if((retVal = rtl8367c_getAsicMIBsCounter(rtk_switch_port_L2P_get(port), mib_idx, &second_cnt)) != RT_ERR_OK)
            return retVal;

        *pCntr += second_cnt;
    }

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_vlan_init
 * Description:
 *      Initialize VLAN.
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 * Note:
 *      VLAN is disabled by default. User has to call this API to enable VLAN before
 *      using it. And It will set a default VLAN(vid 1) including all ports and set
 *      all ports PVID to the default VLAN.
 */
rtk_api_ret_t rtk_vlan_init(void)
{
    rtk_api_ret_t retVal;
    rtk_uint32 i;
    rtl8367c_user_vlan4kentry vlan4K;
    rtl8367c_vlanconfiguser vlanMC;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Clean Database */
    memset(vlan_mbrCfgVid, 0x00, sizeof(rtk_vlan_t) * RTL8367C_CVIDXNO);
    memset(vlan_mbrCfgUsage, 0x00, sizeof(vlan_mbrCfgType_t) * RTL8367C_CVIDXNO);

    /* clean 32 VLAN member configuration */
    for (i = 0; i <= RTL8367C_CVIDXMAX; i++)
    {
        vlanMC.evid = 0;
        vlanMC.mbr = 0;
        vlanMC.fid_msti = 0;
        vlanMC.envlanpol = 0;
        vlanMC.meteridx = 0;
        vlanMC.vbpen = 0;
        vlanMC.vbpri = 0;
        if ((retVal = rtl8367c_setAsicVlanMemberConfig(i, &vlanMC)) != RT_ERR_OK)
            return retVal;
    }

    /* Set a default VLAN with vid 1 to 4K table for all ports */
    memset(&vlan4K, 0, sizeof(rtl8367c_user_vlan4kentry));
    vlan4K.vid = 1;
    vlan4K.mbr = RTK_PHY_PORTMASK_ALL;
    vlan4K.untag = RTK_PHY_PORTMASK_ALL;
    vlan4K.fid_msti = 0;
    if ((retVal = rtl8367c_setAsicVlan4kEntry(&vlan4K)) != RT_ERR_OK)
        return retVal;

    /* Also set the default VLAN to 32 member configuration index 0 */
    memset(&vlanMC, 0, sizeof(rtl8367c_vlanconfiguser));
    vlanMC.evid = 1;
    vlanMC.mbr = RTK_PHY_PORTMASK_ALL;
    vlanMC.fid_msti = 0;
    if ((retVal = rtl8367c_setAsicVlanMemberConfig(0, &vlanMC)) != RT_ERR_OK)
            return retVal;

    /* Set all ports PVID to default VLAN and tag-mode to original */
    RTK_SCAN_ALL_PHY_PORTMASK(i)
    {
        if ((retVal = rtl8367c_setAsicVlanPortBasedVID(i, 0, 0)) != RT_ERR_OK)
            return retVal;
        if ((retVal = rtl8367c_setAsicVlanEgressTagMode(i, EG_TAG_MODE_ORI)) != RT_ERR_OK)
            return retVal;
    }

    /* Updata Databse */
    vlan_mbrCfgUsage[0] = MBRCFG_USED_BY_VLAN;
    vlan_mbrCfgVid[0] = 1;

    /* Enable Ingress filter */
    RTK_SCAN_ALL_PHY_PORTMASK(i)
    {
        if ((retVal = rtl8367c_setAsicVlanIngressFilter(i, ENABLED)) != RT_ERR_OK)
            return retVal;
    }

    /* enable VLAN */
    if ((retVal = rtl8367c_setAsicVlanFilter(ENABLED)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_vlan_set
 * Description:
 *      Set a VLAN entry.
 * Input:
 *      vid - VLAN ID to configure.
 *      pVlanCfg - VLAN Configuration
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_INPUT 		        - Invalid input parameters.
 *      RT_ERR_L2_FID               - Invalid FID.
 *      RT_ERR_VLAN_PORT_MBR_EXIST  - Invalid member port mask.
 *      RT_ERR_VLAN_VID             - Invalid VID parameter.
 * Note:
 *
 */
rtk_api_ret_t rtk_vlan_set(rtk_vlan_t vid, rtk_vlan_cfg_t *pVlanCfg)
{
    rtk_api_ret_t retVal;
    rtk_uint32 phyMbrPmask;
    rtk_uint32 phyUntagPmask;
    rtl8367c_user_vlan4kentry vlan4K;
    rtl8367c_vlanconfiguser vlanMC;
    rtk_uint32 idx;
    rtk_uint32 empty_index = 0xffff;
    rtk_uint32 update_evid = 0;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* vid must be 0~8191 */
    if (vid > RTL8367C_EVIDMAX)
        return RT_ERR_VLAN_VID;

    /* Null pointer check */
    if(NULL == pVlanCfg)
        return RT_ERR_NULL_POINTER;

    /* Check port mask valid */
    RTK_CHK_PORTMASK_VALID(&(pVlanCfg->mbr));

    if (vid <= RTL8367C_VIDMAX)
    {
        /* Check untag port mask valid */
        RTK_CHK_PORTMASK_VALID(&(pVlanCfg->untag));
    }

    /* IVL_EN */
    if(pVlanCfg->ivl_en >= RTK_ENABLE_END)
        return RT_ERR_ENABLE;

    /* fid must be 0~15 */
    if(pVlanCfg->fid_msti > RTL8367C_FIDMAX)
        return RT_ERR_L2_FID;

    /* Policing */
    if(pVlanCfg->envlanpol >= RTK_ENABLE_END)
        return RT_ERR_ENABLE;

    /* Meter ID */
    if(pVlanCfg->meteridx > RTK_MAX_METER_ID)
        return RT_ERR_INPUT;

    /* VLAN based priority */
    if(pVlanCfg->vbpen >= RTK_ENABLE_END)
        return RT_ERR_ENABLE;

    /* Priority */
    if(pVlanCfg->vbpri > RTL8367C_PRIMAX)
        return RT_ERR_INPUT;

    /* Get physical port mask */
    if(rtk_switch_portmask_L2P_get(&(pVlanCfg->mbr), &phyMbrPmask) != RT_ERR_OK)
        return RT_ERR_FAILED;

    if(rtk_switch_portmask_L2P_get(&(pVlanCfg->untag), &phyUntagPmask) != RT_ERR_OK)
        return RT_ERR_FAILED;

    if (vid <= RTL8367C_VIDMAX)
    {
        /* update 4K table */
        memset(&vlan4K, 0, sizeof(rtl8367c_user_vlan4kentry));
        vlan4K.vid = vid;

        vlan4K.mbr    = (phyMbrPmask & 0xFFFF);
        vlan4K.untag  = (phyUntagPmask & 0xFFFF);

        vlan4K.ivl_svl      = pVlanCfg->ivl_en;
        vlan4K.fid_msti     = pVlanCfg->fid_msti;
        vlan4K.envlanpol    = pVlanCfg->envlanpol;
        vlan4K.meteridx     = pVlanCfg->meteridx;
        vlan4K.vbpen        = pVlanCfg->vbpen;
        vlan4K.vbpri        = pVlanCfg->vbpri;

        if ((retVal = rtl8367c_setAsicVlan4kEntry(&vlan4K)) != RT_ERR_OK)
            return retVal;

        /* Update Member configuration if exist */
        for (idx = 0; idx <= RTL8367C_CVIDXMAX; idx++)
        {
            if(vlan_mbrCfgUsage[idx] == MBRCFG_USED_BY_VLAN)
            {
                if(vlan_mbrCfgVid[idx] == vid)
                {
                    /* Found! Update */
                    if(phyMbrPmask == 0x00)
                    {
                        /* Member port = 0x00, delete this VLAN from Member Configuration */
                        memset(&vlanMC, 0x00, sizeof(rtl8367c_vlanconfiguser));
                        if ((retVal = rtl8367c_setAsicVlanMemberConfig(idx, &vlanMC)) != RT_ERR_OK)
                            return retVal;

                        /* Clear Database */
                        vlan_mbrCfgUsage[idx] = MBRCFG_UNUSED;
                        vlan_mbrCfgVid[idx]   = 0;
                    }
                    else
                    {
                        /* Normal VLAN config, update to member configuration */
                        vlanMC.evid = vid;
                        vlanMC.mbr = vlan4K.mbr;
                        vlanMC.fid_msti = vlan4K.fid_msti;
                        vlanMC.meteridx = vlan4K.meteridx;
                        vlanMC.envlanpol= vlan4K.envlanpol;
                        vlanMC.vbpen = vlan4K.vbpen;
                        vlanMC.vbpri = vlan4K.vbpri;
                        if ((retVal = rtl8367c_setAsicVlanMemberConfig(idx, &vlanMC)) != RT_ERR_OK)
                            return retVal;
                    }

                    break;
                }
            }
        }
    }
    else
    {
        /* vid > 4095 */
        for (idx = 0; idx <= RTL8367C_CVIDXMAX; idx++)
        {
            if(vlan_mbrCfgUsage[idx] == MBRCFG_USED_BY_VLAN)
            {
                if(vlan_mbrCfgVid[idx] == vid)
                {
                    /* Found! Update */
                    if(phyMbrPmask == 0x00)
                    {
                        /* Member port = 0x00, delete this VLAN from Member Configuration */
                        memset(&vlanMC, 0x00, sizeof(rtl8367c_vlanconfiguser));
                        if ((retVal = rtl8367c_setAsicVlanMemberConfig(idx, &vlanMC)) != RT_ERR_OK)
                            return retVal;

                        /* Clear Database */
                        vlan_mbrCfgUsage[idx] = MBRCFG_UNUSED;
                        vlan_mbrCfgVid[idx]   = 0;
                    }
                    else
                    {
                        /* Normal VLAN config, update to member configuration */
                        vlanMC.evid = vid;
                        vlanMC.mbr = phyMbrPmask;
                        vlanMC.fid_msti = pVlanCfg->fid_msti;
                        vlanMC.meteridx = pVlanCfg->meteridx;
                        vlanMC.envlanpol= pVlanCfg->envlanpol;
                        vlanMC.vbpen = pVlanCfg->vbpen;
                        vlanMC.vbpri = pVlanCfg->vbpri;
                        if ((retVal = rtl8367c_setAsicVlanMemberConfig(idx, &vlanMC)) != RT_ERR_OK)
                            return retVal;

                        break;
                    }

                    update_evid = 1;
                }
            }

            if(vlan_mbrCfgUsage[idx] == MBRCFG_UNUSED)
            {
                if(0xffff == empty_index)
                    empty_index = idx;
            }
        }

        /* doesn't find out same EVID entry and there is empty index in member configuration */
        if( (phyMbrPmask != 0x00) && (update_evid == 0) && (empty_index != 0xFFFF) )
        {
            vlanMC.evid = vid;
            vlanMC.mbr = phyMbrPmask;
            vlanMC.fid_msti = pVlanCfg->fid_msti;
            vlanMC.meteridx = pVlanCfg->meteridx;
            vlanMC.envlanpol= pVlanCfg->envlanpol;
            vlanMC.vbpen = pVlanCfg->vbpen;
            vlanMC.vbpri = pVlanCfg->vbpri;
            if ((retVal = rtl8367c_setAsicVlanMemberConfig(empty_index, &vlanMC)) != RT_ERR_OK)
                return retVal;

            vlan_mbrCfgUsage[empty_index] = MBRCFG_USED_BY_VLAN;
            vlan_mbrCfgVid[empty_index] = vid;

        }
    }

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_vlan_checkAndCreateMbr
 * Description:
 *      Check and create Member configuration and return index
 * Input:
 *      vid  - VLAN id.
 * Output:
 *      pIndex  - Member configuration index
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_VLAN_VID     - Invalid VLAN ID.
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - VLAN not found
 *      RT_ERR_TBL_FULL     - Member Configuration table full
 * Note:
 *
 */
rtk_api_ret_t rtk_vlan_checkAndCreateMbr(rtk_vlan_t vid, rtk_uint32 *pIndex)
{
    rtk_api_ret_t retVal;
    rtl8367c_user_vlan4kentry vlan4K;
    rtl8367c_vlanconfiguser vlanMC;
    rtk_uint32 idx;
    rtk_uint32 empty_idx = 0xFFFF;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* vid must be 0~8191 */
    if (vid > RTL8367C_EVIDMAX)
        return RT_ERR_VLAN_VID;

    /* Null pointer check */
    if(NULL == pIndex)
        return RT_ERR_NULL_POINTER;

    /* Get 4K VLAN */
    if (vid <= RTL8367C_VIDMAX)
    {
        memset(&vlan4K, 0x00, sizeof(rtl8367c_user_vlan4kentry));
        vlan4K.vid = vid;
        if ((retVal = rtl8367c_getAsicVlan4kEntry(&vlan4K)) != RT_ERR_OK)
            return retVal;
    }

    /* Search exist entry */
    for (idx = 0; idx <= RTL8367C_CVIDXMAX; idx++)
    {
        if(vlan_mbrCfgUsage[idx] == MBRCFG_USED_BY_VLAN)
        {
            if(vlan_mbrCfgVid[idx] == vid)
            {
                /* Found! return index */
                *pIndex = idx;
                return RT_ERR_OK;
            }
        }
    }

    /* Not found, Read H/W Member Configuration table to update database */
    for (idx = 0; idx <= RTL8367C_CVIDXMAX; idx++)
    {
        if ((retVal = rtl8367c_getAsicVlanMemberConfig(idx, &vlanMC)) != RT_ERR_OK)
            return retVal;

        if( (vlanMC.evid == 0) && (vlanMC.mbr == 0x00))
        {
            vlan_mbrCfgUsage[idx]   = MBRCFG_UNUSED;
            vlan_mbrCfgVid[idx]     = 0;
        }
        else
        {
            vlan_mbrCfgUsage[idx]   = MBRCFG_USED_BY_VLAN;
            vlan_mbrCfgVid[idx]     = vlanMC.evid;
        }
    }

    /* Search exist entry again */
    for (idx = 0; idx <= RTL8367C_CVIDXMAX; idx++)
    {
        if(vlan_mbrCfgUsage[idx] == MBRCFG_USED_BY_VLAN)
        {
            if(vlan_mbrCfgVid[idx] == vid)
            {
                /* Found! return index */
                *pIndex = idx;
                return RT_ERR_OK;
            }
        }
    }

    /* try to look up an empty index */
    for (idx = 0; idx <= RTL8367C_CVIDXMAX; idx++)
    {
        if(vlan_mbrCfgUsage[idx] == MBRCFG_UNUSED)
        {
            empty_idx = idx;
            break;
        }
    }

    if(empty_idx == 0xFFFF)
    {
        /* No empty index */
        return RT_ERR_TBL_FULL;
    }

    if (vid > RTL8367C_VIDMAX)
    {
        /* > 4K, there is no 4K entry, create on member configuration directly */
        memset(&vlanMC, 0x00, sizeof(rtl8367c_vlanconfiguser));
        vlanMC.evid = vid;
        if ((retVal = rtl8367c_setAsicVlanMemberConfig(empty_idx, &vlanMC)) != RT_ERR_OK)
            return retVal;
    }
    else
    {
        /* Copy from 4K table */
        vlanMC.evid = vid;
        vlanMC.mbr = vlan4K.mbr;
        vlanMC.fid_msti = vlan4K.fid_msti;
        vlanMC.meteridx= vlan4K.meteridx;
        vlanMC.envlanpol= vlan4K.envlanpol;
        vlanMC.vbpen = vlan4K.vbpen;
        vlanMC.vbpri = vlan4K.vbpri;
        if ((retVal = rtl8367c_setAsicVlanMemberConfig(empty_idx, &vlanMC)) != RT_ERR_OK)
            return retVal;
    }

    /* Update Database */
    vlan_mbrCfgUsage[empty_idx] = MBRCFG_USED_BY_VLAN;
    vlan_mbrCfgVid[empty_idx] = vid;

    *pIndex = empty_idx;
    return RT_ERR_OK;
}

/* Function Name:
 *     rtk_vlan_portPvid_set
 * Description:
 *      Set port to specified VLAN ID(PVID).
 * Input:
 *      port - Port id.
 *      pvid - Specified VLAN ID.
 *      priority - 802.1p priority for the PVID.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_PORT_ID              - Invalid port number.
 *      RT_ERR_VLAN_PRIORITY        - Invalid priority.
 *      RT_ERR_VLAN_ENTRY_NOT_FOUND - VLAN entry not found.
 *      RT_ERR_VLAN_VID             - Invalid VID parameter.
 * Note:
 *       The API is used for Port-based VLAN. The untagged frame received from the
 *       port will be classified to the specified VLAN and assigned to the specified priority.
 */
rtk_api_ret_t rtk_vlan_portPvid_set(rtk_port_t port, rtk_vlan_t pvid, rtk_pri_t priority)
{
    rtk_api_ret_t retVal;
    rtk_uint32 index;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_VALID(port);

    /* vid must be 0~8191 */
    if (pvid > RTL8367C_EVIDMAX)
        return RT_ERR_VLAN_VID;

    /* priority must be 0~7 */
    if (priority > RTL8367C_PRIMAX)
        return RT_ERR_VLAN_PRIORITY;

    if((retVal = rtk_vlan_checkAndCreateMbr(pvid, &index)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicVlanPortBasedVID(rtk_switch_port_L2P_get(port), index, priority)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_l2_addr_get
 * Description:
 *      Get LUT unicast entry.
 * Input:
 *      pMac    - 6 bytes unicast(I/G bit is 0) mac address to be written into LUT.
 * Output:
 *      pL2_data - Unicast entry parameter
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_PORT_ID              - Invalid port number.
 *      RT_ERR_MAC                  - Invalid MAC address.
 *      RT_ERR_L2_FID               - Invalid FID .
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *      If the unicast mac address existed in LUT, it will return the port and fid where
 *      the mac is learned. Otherwise, it will return a RT_ERR_L2_ENTRY_NOTFOUND error.
 */
rtk_api_ret_t rtk_l2_addr_get(rtk_mac_t *pMac, rtk_l2_ucastAddr_t *pL2_data)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* must be unicast address */
    if ((pMac == NULL) || (pMac->octet[0] & 0x1))
        return RT_ERR_MAC;

    if (pL2_data->fid > RTL8367C_FIDMAX || pL2_data->efid > RTL8367C_EFIDMAX)
        return RT_ERR_L2_FID;

    memset(&l2Table, 0, sizeof(rtl8367c_luttb));

    memcpy(l2Table.mac.octet, pMac->octet, ETHER_ADDR_LEN);
    l2Table.ivl_svl     = pL2_data->ivl;
    l2Table.cvid_fid    = pL2_data->cvid;
    l2Table.fid         = pL2_data->fid;
    l2Table.efid        = pL2_data->efid;
    method = LUTREADMETHOD_MAC;

    if ((retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table)) != RT_ERR_OK)
        return retVal;

    memcpy(pL2_data->mac.octet, pMac->octet,ETHER_ADDR_LEN);
    pL2_data->port      = rtk_switch_port_P2L_get(l2Table.spa);
    pL2_data->fid       = l2Table.fid;
    pL2_data->efid      = l2Table.efid;
    pL2_data->ivl       = l2Table.ivl_svl;
    pL2_data->cvid      = l2Table.cvid_fid;
    pL2_data->is_static = l2Table.nosalearn;
    pL2_data->auth      = l2Table.auth;
    pL2_data->sa_block  = l2Table.sa_block;
    pL2_data->da_block  = l2Table.da_block;
    pL2_data->priority  = l2Table.lut_pri;
    pL2_data->sa_pri_en = l2Table.sa_en;
    pL2_data->fwd_pri_en= l2Table.fwd_en;
    pL2_data->address   = l2Table.address;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_l2_addr_next_get
 * Description:
 *      Get Next LUT unicast entry.
 * Input:
 *      read_method     - The reading method.
 *      port            - The port number if the read_metohd is READMETHOD_NEXT_L2UCSPA
 *      pAddress        - The Address ID
 * Output:
 *      pL2_data - Unicast entry parameter
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_PORT_ID              - Invalid port number.
 *      RT_ERR_MAC                  - Invalid MAC address.
 *      RT_ERR_L2_FID               - Invalid FID .
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *      Get the next unicast entry after the current entry pointed by pAddress.
 *      The address of next entry is returned by pAddress. User can use (address + 1)
 *      as pAddress to call this API again for dumping all entries is LUT.
 */
rtk_api_ret_t rtk_l2_addr_next_get(rtk_l2_read_method_t read_method, rtk_port_t port, rtk_uint32 *pAddress, rtk_l2_ucastAddr_t *pL2_data)
{
    rtk_api_ret_t   retVal;
    rtk_uint32      method;
    rtl8367c_luttb  l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Error Checking */
    if ((pL2_data == NULL) || (pAddress == NULL))
        return RT_ERR_MAC;

    if(read_method == READMETHOD_NEXT_L2UC)
        method = LUTREADMETHOD_NEXT_L2UC;
    else if(read_method == READMETHOD_NEXT_L2UCSPA)
        method = LUTREADMETHOD_NEXT_L2UCSPA;
    else
        return RT_ERR_INPUT;

    /* Check Port Valid */
    RTK_CHK_PORT_VALID(port);

    if(*pAddress > RTK_MAX_LUT_ADDR_ID )
        return RT_ERR_L2_L2UNI_PARAM;

    memset(&l2Table, 0, sizeof(rtl8367c_luttb));
    l2Table.address = *pAddress;

    if(read_method == READMETHOD_NEXT_L2UCSPA)
        l2Table.spa = rtk_switch_port_L2P_get(port);

    if ((retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table)) != RT_ERR_OK)
        return retVal;

    if(l2Table.address < *pAddress)
        return RT_ERR_L2_ENTRY_NOTFOUND;

    memcpy(pL2_data->mac.octet, l2Table.mac.octet, ETHER_ADDR_LEN);
    pL2_data->port      = rtk_switch_port_P2L_get(l2Table.spa);
    pL2_data->fid       = l2Table.fid;
    pL2_data->efid      = l2Table.efid;
    pL2_data->ivl       = l2Table.ivl_svl;
    pL2_data->cvid      = l2Table.cvid_fid;
    pL2_data->is_static = l2Table.nosalearn;
    pL2_data->auth      = l2Table.auth;
    pL2_data->sa_block  = l2Table.sa_block;
    pL2_data->da_block  = l2Table.da_block;
    pL2_data->priority  = l2Table.lut_pri;
    pL2_data->sa_pri_en = l2Table.sa_en;
    pL2_data->fwd_pri_en= l2Table.fwd_en;
    pL2_data->address   = l2Table.address;

    *pAddress = l2Table.address;

    return RT_ERR_OK;

}

/* Function Name:
 *      rtk_l2_addr_del
 * Description:
 *      Delete LUT unicast entry.
 * Input:
 *      pMac - 6 bytes unicast(I/G bit is 0) mac address to be written into LUT.
 *      fid - Filtering database
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_PORT_ID              - Invalid port number.
 *      RT_ERR_MAC                  - Invalid MAC address.
 *      RT_ERR_L2_FID               - Invalid FID .
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *      If the mac has existed in the LUT, it will be deleted. Otherwise, it will return RT_ERR_L2_ENTRY_NOTFOUND.
 */
rtk_api_ret_t rtk_l2_addr_del(rtk_mac_t *pMac, rtk_l2_ucastAddr_t *pL2_data)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* must be unicast address */
    if ((pMac == NULL) || (pMac->octet[0] & 0x1))
        return RT_ERR_MAC;

    if (pL2_data->fid > RTL8367C_FIDMAX || pL2_data->efid > RTL8367C_EFIDMAX)
        return RT_ERR_L2_FID;

    memset(&l2Table, 0, sizeof(rtl8367c_luttb));

    /* fill key (MAC,FID) to get L2 entry */
    memcpy(l2Table.mac.octet, pMac->octet, ETHER_ADDR_LEN);
    l2Table.ivl_svl     = pL2_data->ivl;
    l2Table.cvid_fid    = pL2_data->cvid;
    l2Table.fid         = pL2_data->fid;
    l2Table.efid        = pL2_data->efid;
    method = LUTREADMETHOD_MAC;
    retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table);
    if (RT_ERR_OK ==  retVal)
    {
        memcpy(l2Table.mac.octet, pMac->octet, ETHER_ADDR_LEN);
        l2Table.ivl_svl     = pL2_data->ivl;
        l2Table.cvid_fid    = pL2_data->cvid;
	    l2Table.fid = pL2_data->fid;
	    l2Table.efid = pL2_data->efid;
        l2Table.spa = 0;
        l2Table.nosalearn = 0;
        l2Table.sa_block = 0;
        l2Table.da_block = 0;
        l2Table.auth = 0;
        l2Table.age = 0;
        l2Table.lut_pri = 0;
        l2Table.sa_en = 0;
        l2Table.fwd_en = 0;
        if((retVal = rtl8367c_setAsicL2LookupTb(&l2Table)) != RT_ERR_OK)
            return retVal;

        pL2_data->address = l2Table.address;
        return RT_ERR_OK;
    }
    else
        return retVal;
}

/* Function Name:
 *      rtk_l2_ipMcastAddr_add
 * Description:
 *      Add Lut IP multicast entry
 * Input:
 *      pIpMcastAddr    - IP Multicast entry
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK               - OK
 *      RT_ERR_FAILED           - Failed
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_PORT_ID          - Invalid port number.
 *      RT_ERR_L2_INDEXTBL_FULL - hashed index is full of entries.
 *      RT_ERR_PORT_MASK        - Invalid portmask.
 *      RT_ERR_INPUT            - Invalid input parameters.
 * Note:
 *      System supports L2 entry with IP multicast DIP/SIP to forward IP multicasting frame as user
 *      desired. If this function is enabled, then system will be looked up L2 IP multicast entry to
 *      forward IP multicast frame directly without flooding.
 */
rtk_api_ret_t rtk_l2_ipMcastAddr_add(rtk_l2_ipMcastAddr_t *pIpMcastAddr)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;
    rtk_uint32 pmask;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pIpMcastAddr)
        return RT_ERR_NULL_POINTER;

    /* check port mask */
    RTK_CHK_PORTMASK_VALID(&pIpMcastAddr->portmask);

    if( (pIpMcastAddr->dip & 0xF0000000) != 0xE0000000)
        return RT_ERR_INPUT;

    if(pIpMcastAddr->fwd_pri_en >= RTK_ENABLE_END)
        return RT_ERR_ENABLE;

    if(pIpMcastAddr->priority > RTL8367C_PRIMAX)
        return RT_ERR_INPUT;

    /* Get Physical port mask */
    if ((retVal = rtk_switch_portmask_L2P_get(&pIpMcastAddr->portmask, &pmask)) != RT_ERR_OK)
        return retVal;

    memset(&l2Table, 0x00, sizeof(rtl8367c_luttb));
    l2Table.sip = pIpMcastAddr->sip;
    l2Table.dip = pIpMcastAddr->dip;
    l2Table.l3lookup = 1;
    l2Table.l3vidlookup = 0;
    method = LUTREADMETHOD_MAC;
    retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table);
    if (RT_ERR_OK == retVal)
    {
        l2Table.sip = pIpMcastAddr->sip;
        l2Table.dip = pIpMcastAddr->dip;
        l2Table.mbr = pmask;
        l2Table.nosalearn = 1;
        l2Table.l3lookup = 1;
        l2Table.l3vidlookup = 0;
        l2Table.lut_pri = pIpMcastAddr->priority;
        l2Table.fwd_en  = pIpMcastAddr->fwd_pri_en;
        if((retVal = rtl8367c_setAsicL2LookupTb(&l2Table)) != RT_ERR_OK)
            return retVal;

        pIpMcastAddr->address = l2Table.address;
        return RT_ERR_OK;
    }
    else if (RT_ERR_L2_ENTRY_NOTFOUND == retVal)
    {
        memset(&l2Table, 0, sizeof(rtl8367c_luttb));
        l2Table.sip = pIpMcastAddr->sip;
        l2Table.dip = pIpMcastAddr->dip;
        l2Table.mbr = pmask;
        l2Table.nosalearn = 1;
        l2Table.l3lookup = 1;
        l2Table.l3vidlookup = 0;
        l2Table.lut_pri = pIpMcastAddr->priority;
        l2Table.fwd_en  = pIpMcastAddr->fwd_pri_en;
        if ((retVal = rtl8367c_setAsicL2LookupTb(&l2Table)) != RT_ERR_OK)
            return retVal;

        pIpMcastAddr->address = l2Table.address;

        method = LUTREADMETHOD_MAC;
        retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table);
        if (RT_ERR_L2_ENTRY_NOTFOUND == retVal)
            return     RT_ERR_L2_INDEXTBL_FULL;
        else
            return retVal;

    }
    else
        return retVal;

}


/* Function Name:
 *      rtk_l2_ipMcastAddr_get
 * Description:
 *      Get LUT IP multicast entry.
 * Input:
 *      pIpMcastAddr    - IP Multicast entry
 * Output:
 *      pIpMcastAddr    - IP Multicast entry
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *      The API can get Lut table of IP multicast entry.
 */
rtk_api_ret_t rtk_l2_ipMcastAddr_get(rtk_l2_ipMcastAddr_t *pIpMcastAddr)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pIpMcastAddr)
        return RT_ERR_NULL_POINTER;

    if( (pIpMcastAddr->dip & 0xF0000000) != 0xE0000000)
        return RT_ERR_INPUT;

    memset(&l2Table, 0x00, sizeof(rtl8367c_luttb));
    l2Table.sip = pIpMcastAddr->sip;
    l2Table.dip = pIpMcastAddr->dip;
    l2Table.l3lookup = 1;
    l2Table.l3vidlookup = 0;
    method = LUTREADMETHOD_MAC;
    if ((retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table)) != RT_ERR_OK)
        return retVal;

    /* Get Logical port mask */
    if ((retVal = rtk_switch_portmask_P2L_get(l2Table.mbr, &pIpMcastAddr->portmask)) != RT_ERR_OK)
        return retVal;

    pIpMcastAddr->priority      = l2Table.lut_pri;
    pIpMcastAddr->fwd_pri_en    = l2Table.fwd_en;
    pIpMcastAddr->igmp_asic     = l2Table.igmp_asic;
    pIpMcastAddr->igmp_index    = l2Table.igmpidx;
    pIpMcastAddr->address       = l2Table.address;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_l2_ipMcastAddr_next_get
 * Description:
 *      Get Next IP Multicast entry.
 * Input:
 *      pAddress        - The Address ID
 * Output:
 *      pIpMcastAddr    - IP Multicast entry
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *      Get the next IP multicast entry after the current entry pointed by pAddress.
 *      The address of next entry is returned by pAddress. User can use (address + 1)
 *      as pAddress to call this API again for dumping all IP multicast entries is LUT.
 */
rtk_api_ret_t rtk_l2_ipMcastAddr_next_get(rtk_uint32 *pAddress, rtk_l2_ipMcastAddr_t *pIpMcastAddr)
{
    rtk_api_ret_t   retVal;
    rtl8367c_luttb  l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Error Checking */
    if ((pAddress == NULL) || (pIpMcastAddr == NULL) )
        return RT_ERR_INPUT;

    if(*pAddress > RTK_MAX_LUT_ADDR_ID )
        return RT_ERR_L2_L2UNI_PARAM;

    memset(&l2Table, 0, sizeof(rtl8367c_luttb));
    l2Table.address = *pAddress;

    do
    {
        if ((retVal = rtl8367c_getAsicL2LookupTb(LUTREADMETHOD_NEXT_L3MC, &l2Table)) != RT_ERR_OK)
            return retVal;

        if(l2Table.address < *pAddress)
            return RT_ERR_L2_ENTRY_NOTFOUND;

    }while(l2Table.l3vidlookup == 1);

    pIpMcastAddr->sip = l2Table.sip;
    pIpMcastAddr->dip = l2Table.dip;

    /* Get Logical port mask */
    if ((retVal = rtk_switch_portmask_P2L_get(l2Table.mbr, &pIpMcastAddr->portmask)) != RT_ERR_OK)
        return retVal;

    pIpMcastAddr->priority      = l2Table.lut_pri;
    pIpMcastAddr->fwd_pri_en    = l2Table.fwd_en;
    pIpMcastAddr->igmp_asic     = l2Table.igmp_asic;
    pIpMcastAddr->igmp_index    = l2Table.igmpidx;
    pIpMcastAddr->address       = l2Table.address;
    *pAddress = l2Table.address;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_l2_ipMcastAddr_del
 * Description:
 *      Delete a ip multicast address entry from the specified device.
 * Input:
 *      pIpMcastAddr    - IP Multicast entry
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *      The API can delete a IP multicast address entry from the specified device.
 */
rtk_api_ret_t rtk_l2_ipMcastAddr_del(rtk_l2_ipMcastAddr_t *pIpMcastAddr)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Error Checking */
    if (pIpMcastAddr == NULL)
        return RT_ERR_INPUT;

    if( (pIpMcastAddr->dip & 0xF0000000) != 0xE0000000)
        return RT_ERR_INPUT;

    memset(&l2Table, 0x00, sizeof(rtl8367c_luttb));
    l2Table.sip = pIpMcastAddr->sip;
    l2Table.dip = pIpMcastAddr->dip;
    l2Table.l3lookup = 1;
    l2Table.l3vidlookup = 0;
    method = LUTREADMETHOD_MAC;
    retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table);
    if (RT_ERR_OK == retVal)
    {
        l2Table.sip = pIpMcastAddr->sip;
        l2Table.dip = pIpMcastAddr->dip;
        l2Table.mbr = 0;
        l2Table.nosalearn = 0;
        l2Table.l3lookup = 1;
        l2Table.l3vidlookup = 0;
        l2Table.lut_pri = 0;
        l2Table.fwd_en  = 0;
        if((retVal = rtl8367c_setAsicL2LookupTb(&l2Table)) != RT_ERR_OK)
            return retVal;

        pIpMcastAddr->address = l2Table.address;
        return RT_ERR_OK;
    }
    else
        return retVal;
}

/* Function Name:
 *      rtk_l2_ipVidMcastAddr_add
 * Description:
 *      Add Lut IP multicast+VID entry
 * Input:
 *      pIpVidMcastAddr - IP & VID multicast Entry
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK               - OK
 *      RT_ERR_FAILED           - Failed
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_PORT_ID          - Invalid port number.
 *      RT_ERR_L2_INDEXTBL_FULL - hashed index is full of entries.
 *      RT_ERR_PORT_MASK        - Invalid portmask.
 *      RT_ERR_INPUT            - Invalid input parameters.
 * Note:
 *
 */
rtk_api_ret_t rtk_l2_ipVidMcastAddr_add(rtk_l2_ipVidMcastAddr_t *pIpVidMcastAddr)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;
    rtk_uint32 pmask;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pIpVidMcastAddr)
        return RT_ERR_NULL_POINTER;

    /* check port mask */
    RTK_CHK_PORTMASK_VALID(&pIpVidMcastAddr->portmask);

    if (pIpVidMcastAddr->vid > RTL8367C_VIDMAX)
        return RT_ERR_L2_VID;

    if( (pIpVidMcastAddr->dip & 0xF0000000) != 0xE0000000)
        return RT_ERR_INPUT;

    /* Get Physical port mask */
    if ((retVal = rtk_switch_portmask_L2P_get(&pIpVidMcastAddr->portmask, &pmask)) != RT_ERR_OK)
        return retVal;

    memset(&l2Table, 0x00, sizeof(rtl8367c_luttb));
    l2Table.sip = pIpVidMcastAddr->sip;
    l2Table.dip = pIpVidMcastAddr->dip;
    l2Table.l3lookup = 1;
    l2Table.l3vidlookup = 1;
    l2Table.l3_vid = pIpVidMcastAddr->vid;
    method = LUTREADMETHOD_MAC;
    retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table);
    if (RT_ERR_OK == retVal)
    {
        l2Table.sip = pIpVidMcastAddr->sip;
        l2Table.dip = pIpVidMcastAddr->dip;
        l2Table.mbr = pmask;
        l2Table.nosalearn = 1;
        l2Table.l3lookup = 1;
        l2Table.l3vidlookup = 1;
        l2Table.l3_vid = pIpVidMcastAddr->vid;
        if((retVal = rtl8367c_setAsicL2LookupTb(&l2Table)) != RT_ERR_OK)
            return retVal;

        pIpVidMcastAddr->address = l2Table.address;
        return RT_ERR_OK;
    }
    else if (RT_ERR_L2_ENTRY_NOTFOUND == retVal)
    {
        memset(&l2Table, 0, sizeof(rtl8367c_luttb));
        l2Table.sip = pIpVidMcastAddr->sip;
        l2Table.dip = pIpVidMcastAddr->dip;
        l2Table.mbr = pmask;
        l2Table.nosalearn = 1;
        l2Table.l3lookup = 1;
        l2Table.l3vidlookup = 1;
        l2Table.l3_vid = pIpVidMcastAddr->vid;
        if ((retVal = rtl8367c_setAsicL2LookupTb(&l2Table)) != RT_ERR_OK)
            return retVal;

        pIpVidMcastAddr->address = l2Table.address;

        method = LUTREADMETHOD_MAC;
        retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table);
        if (RT_ERR_L2_ENTRY_NOTFOUND == retVal)
            return     RT_ERR_L2_INDEXTBL_FULL;
        else
            return retVal;

    }
    else
        return retVal;
}

/* Function Name:
 *      rtk_l2_ipVidMcastAddr_get
 * Description:
 *      Get LUT IP multicast+VID entry.
 * Input:
 *      pIpVidMcastAddr - IP & VID multicast Entry
 * Output:
 *      pIpVidMcastAddr - IP & VID multicast Entry
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *
 */
rtk_api_ret_t rtk_l2_ipVidMcastAddr_get(rtk_l2_ipVidMcastAddr_t *pIpVidMcastAddr)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pIpVidMcastAddr)
        return RT_ERR_NULL_POINTER;

    if (pIpVidMcastAddr->vid > RTL8367C_VIDMAX)
        return RT_ERR_L2_VID;

    if( (pIpVidMcastAddr->dip & 0xF0000000) != 0xE0000000)
        return RT_ERR_INPUT;

    memset(&l2Table, 0x00, sizeof(rtl8367c_luttb));
    l2Table.sip = pIpVidMcastAddr->sip;
    l2Table.dip = pIpVidMcastAddr->dip;
    l2Table.l3lookup = 1;
    l2Table.l3vidlookup = 1;
    l2Table.l3_vid = pIpVidMcastAddr->vid;
    method = LUTREADMETHOD_MAC;
    if ((retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table)) != RT_ERR_OK)
        return retVal;

    pIpVidMcastAddr->address = l2Table.address;

     /* Get Logical port mask */
    if ((retVal = rtk_switch_portmask_P2L_get(l2Table.mbr, &pIpVidMcastAddr->portmask)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_l2_ipVidMcastAddr_next_get
 * Description:
 *      Get Next IP Multicast+VID entry.
 * Input:
 *      pAddress        - The Address ID
 * Output:
 *      pIpVidMcastAddr - IP & VID multicast Entry
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *      Get the next IP multicast entry after the current entry pointed by pAddress.
 *      The address of next entry is returned by pAddress. User can use (address + 1)
 *      as pAddress to call this API again for dumping all IP multicast entries is LUT.
 */
rtk_api_ret_t rtk_l2_ipVidMcastAddr_next_get(rtk_uint32 *pAddress, rtk_l2_ipVidMcastAddr_t *pIpVidMcastAddr)
{
    rtk_api_ret_t   retVal;
    rtl8367c_luttb  l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Error Checking */
    if ((pAddress == NULL) || (pIpVidMcastAddr == NULL))
        return RT_ERR_INPUT;

    if(*pAddress > RTK_MAX_LUT_ADDR_ID )
        return RT_ERR_L2_L2UNI_PARAM;

    memset(&l2Table, 0, sizeof(rtl8367c_luttb));
    l2Table.address = *pAddress;

    do
    {
        if ((retVal = rtl8367c_getAsicL2LookupTb(LUTREADMETHOD_NEXT_L3MC, &l2Table)) != RT_ERR_OK)
            return retVal;

        if(l2Table.address < *pAddress)
            return RT_ERR_L2_ENTRY_NOTFOUND;

    }while(l2Table.l3vidlookup == 0);

    pIpVidMcastAddr->sip        = l2Table.sip;
    pIpVidMcastAddr->dip        = l2Table.dip;
    pIpVidMcastAddr->vid        = l2Table.l3_vid;
    pIpVidMcastAddr->address    = l2Table.address;

    /* Get Logical port mask */
    if ((retVal = rtk_switch_portmask_P2L_get(l2Table.mbr, &pIpVidMcastAddr->portmask)) != RT_ERR_OK)
        return retVal;

    *pAddress = l2Table.address;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_l2_ipVidMcastAddr_del
 * Description:
 *      Delete a ip multicast+VID address entry from the specified device.
 * Input:
 *      pIpVidMcastAddr - IP & VID multicast Entry
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK                   - OK
 *      RT_ERR_FAILED               - Failed
 *      RT_ERR_SMI                  - SMI access error
 *      RT_ERR_L2_ENTRY_NOTFOUND    - No such LUT entry.
 *      RT_ERR_INPUT                - Invalid input parameters.
 * Note:
 *
 */
rtk_api_ret_t rtk_l2_ipVidMcastAddr_del(rtk_l2_ipVidMcastAddr_t *pIpVidMcastAddr)
{
    rtk_api_ret_t retVal;
    rtk_uint32 method;
    rtl8367c_luttb l2Table;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pIpVidMcastAddr)
        return RT_ERR_NULL_POINTER;

    if (pIpVidMcastAddr->vid > RTL8367C_VIDMAX)
        return RT_ERR_L2_VID;

    if( (pIpVidMcastAddr->dip & 0xF0000000) != 0xE0000000)
        return RT_ERR_INPUT;

    memset(&l2Table, 0x00, sizeof(rtl8367c_luttb));
    l2Table.sip = pIpVidMcastAddr->sip;
    l2Table.dip = pIpVidMcastAddr->dip;
    l2Table.l3lookup = 1;
    l2Table.l3vidlookup = 1;
    l2Table.l3_vid = pIpVidMcastAddr->vid;
    method = LUTREADMETHOD_MAC;
    retVal = rtl8367c_getAsicL2LookupTb(method, &l2Table);
    if (RT_ERR_OK == retVal)
    {
        l2Table.sip = pIpVidMcastAddr->sip;
        l2Table.dip = pIpVidMcastAddr->dip;
        l2Table.mbr= 0;
        l2Table.nosalearn = 0;
        l2Table.l3lookup = 1;
        l2Table.l3vidlookup = 1;
        l2Table.l3_vid = pIpVidMcastAddr->vid;
        if((retVal = rtl8367c_setAsicL2LookupTb(&l2Table)) != RT_ERR_OK)
            return retVal;

        pIpVidMcastAddr->address = l2Table.address;
        return RT_ERR_OK;
    }
    else
        return retVal;
}

/* Function Name:
 *      rtk_l2_ipMcastAddrLookup_set
 * Description:
 *      Set Lut IP multicast lookup function
 * Input:
 *      type - Lookup type for IPMC packet.
 * Output:
 *      None.
 * Return:
 *      RT_ERR_OK          - OK
 *      RT_ERR_FAILED      - Failed
 *      RT_ERR_SMI         - SMI access error
 * Note:
 *      LOOKUP_MAC      - Lookup by MAC address
 *      LOOKUP_IP       - Lookup by IP address
 *      LOOKUP_IP_VID   - Lookup by IP address & VLAN ID
 */
rtk_api_ret_t rtk_l2_ipMcastAddrLookup_set(rtk_l2_ipmc_lookup_type_t type)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(type == LOOKUP_MAC)
    {
        if((retVal = rtl8367c_setAsicLutIpMulticastLookup(DISABLED)) != RT_ERR_OK)
            return retVal;
    }
    else if(type == LOOKUP_IP)
    {
        if((retVal = rtl8367c_setAsicLutIpMulticastLookup(ENABLED)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicLutIpMulticastVidLookup(DISABLED))!=RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicLutIpLookupMethod(1))!=RT_ERR_OK)
            return retVal;
    }
    else if(type == LOOKUP_IP_VID)
    {
        if((retVal = rtl8367c_setAsicLutIpMulticastLookup(ENABLED)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicLutIpMulticastVidLookup(ENABLED))!=RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicLutIpLookupMethod(1))!=RT_ERR_OK)
            return retVal;
    }
    else
        return RT_ERR_INPUT;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_l2_ipMcastAddrLookup_get
 * Description:
 *      Get Lut IP multicast lookup function
 * Input:
 *      None.
 * Output:
 *      pType - Lookup type for IPMC packet.
 * Return:
 *      RT_ERR_OK          - OK
 *      RT_ERR_FAILED      - Failed
 *      RT_ERR_SMI         - SMI access error
 * Note:
 *      None.
 */
rtk_api_ret_t rtk_l2_ipMcastAddrLookup_get(rtk_l2_ipmc_lookup_type_t *pType)
{
    rtk_api_ret_t       retVal;
    rtk_uint32          enabled, vid_lookup;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pType)
        return RT_ERR_NULL_POINTER;

    if((retVal = rtl8367c_getAsicLutIpMulticastLookup(&enabled)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_getAsicLutIpMulticastVidLookup(&vid_lookup))!=RT_ERR_OK)
        return retVal;

    if(enabled == ENABLED)
    {
        if(vid_lookup == ENABLED)
            *pType = LOOKUP_IP_VID;
        else
            *pType = LOOKUP_IP;
    }
    else
        *pType = LOOKUP_MAC;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_igmp_init
 * Description:
 *      This API enables H/W IGMP and set a default initial configuration.
 * Input:
 *      None.
 * Output:
 *      None.
 * Return:
 *      RT_ERR_OK              - OK
 *      RT_ERR_FAILED          - Failed
 *      RT_ERR_SMI             - SMI access error
 * Note:
 *      This API enables H/W IGMP and set a default initial configuration.
 */
rtk_api_ret_t rtk_igmp_init(void)
{
    rtk_api_ret_t retVal;
    rtk_port_t port;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if ((retVal = rtl8367c_setAsicLutIpMulticastLookup(ENABLED))!=RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicLutIpLookupMethod(1))!=RT_ERR_OK)
        return retVal;

    RTK_SCAN_ALL_PHY_PORTMASK(port)
    {
        if ((retVal = rtl8367c_setAsicIGMPv1Opeartion(port, PROTOCOL_OP_ASIC))!=RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicIGMPv2Opeartion(port, PROTOCOL_OP_ASIC))!=RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicIGMPv3Opeartion(port, /*PROTOCOL_OP_FLOOD*/ PROTOCOL_OP_ASIC))!=RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicMLDv1Opeartion(port, PROTOCOL_OP_ASIC))!=RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicMLDv2Opeartion(port, /*PROTOCOL_OP_FLOOD*/ PROTOCOL_OP_ASIC))!=RT_ERR_OK)
            return retVal;
    }

    if ((retVal = rtl8367c_setAsicIGMPAllowDynamicRouterPort(rtk_switch_phyPortMask_get()))!=RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicIGMPFastLeaveEn(ENABLED))!=RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicIGMPReportLeaveFlood(1))!=RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicIgmp(ENABLED))!=RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_igmp_state_set
 * Description:
 *      This API set H/W IGMP state.
 * Input:
 *      enabled     - H/W IGMP state
 * Output:
 *      None.
 * Return:
 *      RT_ERR_OK              - OK
 *      RT_ERR_FAILED          - Failed
 *      RT_ERR_SMI             - SMI access error
 *      RT_ERR_INPUT           - Error parameter
 * Note:
 *      This API set H/W IGMP state.
 */
rtk_api_ret_t rtk_igmp_state_set(rtk_enable_t enabled)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if (enabled >= RTK_ENABLE_END)
        return RT_ERR_INPUT;

    if ((retVal = rtl8367c_setAsicIgmp(enabled))!=RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_igmp_state_get
 * Description:
 *      This API get H/W IGMP state.
 * Input:
 *      None.
 * Output:
 *      pEnabled        - H/W IGMP state
 * Return:
 *      RT_ERR_OK              - OK
 *      RT_ERR_FAILED          - Failed
 *      RT_ERR_SMI             - SMI access error
 *      RT_ERR_INPUT           - Error parameter
 * Note:
 *      This API set current H/W IGMP state.
 */
rtk_api_ret_t rtk_igmp_state_get(rtk_enable_t *pEnabled)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(pEnabled == NULL)
        return RT_ERR_NULL_POINTER;

    if ((retVal = rtl8367c_getAsicIgmp(pEnabled))!=RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_igmp_static_router_port_set
 * Description:
 *      Configure static router port
 * Input:
 *      pPortmask    - Static Port mask
 * Output:
 *      None.
 * Return:
 *      RT_ERR_OK              - OK
 *      RT_ERR_FAILED          - Failed
 *      RT_ERR_SMI             - SMI access error
 *      RT_ERR_PORT_MASK       - Error parameter
 * Note:
 *      This API set static router port
 */
rtk_api_ret_t rtk_igmp_static_router_port_set(rtk_portmask_t *pPortmask)
{
    rtk_api_ret_t retVal;
    rtk_uint32 pmask;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Valid port mask */
    if(pPortmask == NULL)
        return RT_ERR_NULL_POINTER;

    RTK_CHK_PORTMASK_VALID(pPortmask);

    if ((retVal = rtk_switch_portmask_L2P_get(pPortmask, &pmask))!=RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicIGMPStaticRouterPort(pmask))!=RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_igmp_static_router_port_get
 * Description:
 *      Get static router port
 * Input:
 *      None.
 * Output:
 *      pPortmask       - Static port mask
 * Return:
 *      RT_ERR_OK              - OK
 *      RT_ERR_FAILED          - Failed
 *      RT_ERR_SMI             - SMI access error
 *      RT_ERR_PORT_MASK       - Error parameter
 * Note:
 *      This API get static router port
 */
rtk_api_ret_t rtk_igmp_static_router_port_get(rtk_portmask_t *pPortmask)
{
    rtk_api_ret_t retVal;
    rtk_uint32 pmask;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(pPortmask == NULL)
        return RT_ERR_NULL_POINTER;

    if ((retVal = rtl8367c_getAsicIGMPStaticRouterPort(&pmask))!=RT_ERR_OK)
        return retVal;

    if ((retVal = rtk_switch_portmask_P2L_get(pmask, pPortmask))!=RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_qos_init
 * Description:
 *      Configure Qos default settings with queue number assigment to each port.
 * Input:
 *      queueNum - Queue number of each port.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_QUEUE_NUM 	- Invalid queue number.
 *      RT_ERR_INPUT 		- Invalid input parameters.
 * Note:
 *      This API will initialize related Qos setting with queue number assigment.
 *      The queue number is from 1 to 8.
 */
rtk_api_ret_t rtk_qos_init(rtk_queue_num_t queueNum)
{
    CONST_T rtk_uint16 g_prioritytToQid[8][8]= {
            {0, 0,0,0,0,0,0,0},
            {0, 0,0,0,7,7,7,7},
            {0, 0,0,0,1,1,7,7},
            {0, 0,1,1,2,2,7,7},
            {0, 0,1,1,2,3,7,7},
            {0, 0,1,2,3,4,7,7},
            {0, 0,1,2,3,4,5,7},
            {0,1,2,3,4,5,6,7}
    };

    CONST_T rtk_uint32 g_priorityDecision[8] = {0x01, 0x80,0x04,0x02,0x20,0x40,0x10,0x08};
    CONST_T rtk_uint32 g_prioritytRemap[8] = {0,1,2,3,4,5,6,7};

    rtk_api_ret_t retVal;
    rtk_uint32 qmapidx;
    rtk_uint32 priority;
    rtk_uint32 priDec;
    rtk_uint32 port;
    rtk_uint32 dscp;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if (queueNum <= 0 || queueNum > RTK_MAX_NUM_OF_QUEUE)
        return RT_ERR_QUEUE_NUM;

    /*Set Output Queue Number*/
    if (RTK_MAX_NUM_OF_QUEUE == queueNum)
        qmapidx = 0;
    else
        qmapidx = queueNum;

    RTK_SCAN_ALL_PHY_PORTMASK(port)
    {
        if ((retVal = rtl8367c_setAsicOutputQueueMappingIndex(port, qmapidx)) != RT_ERR_OK)
            return retVal;
    }

    /*Set Priority to Qid*/
    for (priority = 0; priority <= RTK_PRIMAX; priority++)
    {
        if ((retVal = rtl8367c_setAsicPriorityToQIDMappingTable(queueNum - 1, priority, g_prioritytToQid[queueNum - 1][priority])) != RT_ERR_OK)
            return retVal;
    }

    /*Set Flow Control Type to Ingress Flow Control*/
    if ((retVal = rtl8367c_setAsicFlowControlSelect(FC_INGRESS)) != RT_ERR_OK)
        return retVal;


    /*Priority Decision Order*/
    for (priDec = 0;priDec < PRIDEC_END;priDec++)
    {
        if ((retVal = rtl8367c_setAsicPriorityDecision(PRIDECTBL_IDX0, priDec, g_priorityDecision[priDec])) != RT_ERR_OK)
            return retVal;
        if ((retVal = rtl8367c_setAsicPriorityDecision(PRIDECTBL_IDX1, priDec, g_priorityDecision[priDec])) != RT_ERR_OK)
            return retVal;
    }

    /*Set Port-based Priority to 0*/
    RTK_SCAN_ALL_PHY_PORTMASK(port)
    {
        if ((retVal = rtl8367c_setAsicPriorityPortBased(port, 0)) != RT_ERR_OK)
            return retVal;
    }

    /*Disable 1p Remarking*/
    RTK_SCAN_ALL_PHY_PORTMASK(port)
    {
        if ((retVal = rtl8367c_setAsicRemarkingDot1pAbility(port, DISABLED)) != RT_ERR_OK)
            return retVal;
    }

    /*Disable DSCP Remarking*/
    if ((retVal = rtl8367c_setAsicRemarkingDscpAbility(DISABLED)) != RT_ERR_OK)
        return retVal;

    /*Set 1p & DSCP  Priority Remapping & Remarking*/
    for (priority = 0; priority <= RTL8367C_PRIMAX; priority++)
    {
        if ((retVal = rtl8367c_setAsicPriorityDot1qRemapping(priority, g_prioritytRemap[priority])) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicRemarkingDot1pParameter(priority, 0)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicRemarkingDscpParameter(priority, 0)) != RT_ERR_OK)
            return retVal;
    }

    /*Set DSCP Priority*/
    for (dscp = 0; dscp <= 63; dscp++)
    {
        if ((retVal = rtl8367c_setAsicPriorityDscpBased(dscp, 0)) != RT_ERR_OK)
            return retVal;
    }

    /* Finetune B/T value */
    if((retVal = rtl8367c_setAsicReg(0x1722, 0x1158)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_qos_priMap_set
 * Description:
 *      Set output queue number for each port.
 * Input:
 *      queue_num   - Queue number usage.
 *      pPri2qid    - Priority mapping to queue ID.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK              	- OK
 *      RT_ERR_FAILED          	- Failed
 *      RT_ERR_SMI             	- SMI access error
 *      RT_ERR_INPUT 			- Invalid input parameters.
 *      RT_ERR_QUEUE_NUM 		- Invalid queue number.
 *      RT_ERR_QUEUE_ID 		- Invalid queue id.
 *      RT_ERR_PORT_ID 			- Invalid port number.
 *      RT_ERR_QOS_INT_PRIORITY - Invalid priority.
 * Note:
 *      ASIC supports priority mapping to queue with different queue number from 1 to 8.
 *      For different queue numbers usage, ASIC supports different internal available queue IDs.
 */
rtk_api_ret_t rtk_qos_priMap_set(rtk_queue_num_t queue_num, rtk_qos_pri2queue_t *pPri2qid)
{
    rtk_api_ret_t retVal;
    rtk_uint32 pri;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if ((0 == queue_num) || (queue_num > RTK_MAX_NUM_OF_QUEUE))
        return RT_ERR_QUEUE_NUM;

    for (pri = 0; pri <= RTK_PRIMAX; pri++)
    {
        if (pPri2qid->pri2queue[pri] > RTK_QIDMAX)
            return RT_ERR_QUEUE_ID;

        if ((retVal = rtl8367c_setAsicPriorityToQIDMappingTable(queue_num - 1, pri, pPri2qid->pri2queue[pri])) != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_qos_priSel_set
 * Description:
 *      Configure the priority order among different priority mechanism.
 * Input:
 *      index - Priority decision table index (0~1)
 *      pPriDec - Priority assign for port, dscp, 802.1p, cvlan, svlan, acl based priority decision.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK              		- OK
 *      RT_ERR_FAILED          		- Failed
 *      RT_ERR_SMI             		- SMI access error
 *      RT_ERR_QOS_SEL_PRI_SOURCE 	- Invalid priority decision source parameter.
 * Note:
 *      ASIC will follow user priority setting of mechanisms to select mapped queue priority for receiving frame.
 *      If two priority mechanisms are the same, the ASIC will chose the highest priority from mechanisms to
 *      assign queue priority to receiving frame.
 *      The priority sources are:
 *      - PRIDEC_PORT
 *      - PRIDEC_ACL
 *      - PRIDEC_DSCP
 *      - PRIDEC_1Q
 *      - PRIDEC_1AD
 *      - PRIDEC_CVLAN
 *      - PRIDEC_DA
 *      - PRIDEC_SA
 */
rtk_api_ret_t rtk_qos_priSel_set(rtk_qos_priDecTbl_t index, rtk_priority_select_t *pPriDec)
{
    rtk_api_ret_t retVal;
    rtk_uint32 port_pow;
    rtk_uint32 dot1q_pow;
    rtk_uint32 dscp_pow;
    rtk_uint32 acl_pow;
    rtk_uint32 svlan_pow;
    rtk_uint32 cvlan_pow;
    rtk_uint32 smac_pow;
    rtk_uint32 dmac_pow;
    rtk_uint32 i;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if (index < 0 || index >= PRIDECTBL_END)
        return RT_ERR_ENTRY_INDEX;

    if (pPriDec->port_pri >= 8 || pPriDec->dot1q_pri >= 8 || pPriDec->acl_pri >= 8 || pPriDec->dscp_pri >= 8 ||
       pPriDec->cvlan_pri >= 8 || pPriDec->svlan_pri >= 8 || pPriDec->dmac_pri >= 8 || pPriDec->smac_pri >= 8)
        return RT_ERR_QOS_SEL_PRI_SOURCE;

    port_pow = 1;
    for (i = pPriDec->port_pri; i > 0; i--)
        port_pow = (port_pow)*2;

    dot1q_pow = 1;
    for (i = pPriDec->dot1q_pri; i > 0; i--)
        dot1q_pow = (dot1q_pow)*2;

    acl_pow = 1;
    for (i = pPriDec->acl_pri; i > 0; i--)
        acl_pow = (acl_pow)*2;

    dscp_pow = 1;
    for (i = pPriDec->dscp_pri; i > 0; i--)
        dscp_pow = (dscp_pow)*2;

    svlan_pow = 1;
    for (i = pPriDec->svlan_pri; i > 0; i--)
        svlan_pow = (svlan_pow)*2;

    cvlan_pow = 1;
    for (i = pPriDec->cvlan_pri; i > 0; i--)
        cvlan_pow = (cvlan_pow)*2;

    dmac_pow = 1;
    for (i = pPriDec->dmac_pri; i > 0; i--)
        dmac_pow = (dmac_pow)*2;

    smac_pow = 1;
    for (i = pPriDec->smac_pri; i > 0; i--)
        smac_pow = (smac_pow)*2;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_PORT, port_pow)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_ACL, acl_pow)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_DSCP, dscp_pow)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_1Q, dot1q_pow)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_1AD, svlan_pow)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_CVLAN, cvlan_pow)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_DA, dmac_pow)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_setAsicPriorityDecision(index, PRIDEC_SA, smac_pow)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_qos_schedulingQueue_set
 * Description:
 *      Set weight and type of queues in dedicated port.
 * Input:
 *      port        - Port id.
 *      pQweights   - The array of weights for WRR/WFQ queue (0 for STRICT_PRIORITY queue).
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK              	- OK
 *      RT_ERR_FAILED          	- Failed
 *      RT_ERR_SMI             	- SMI access error
 *      RT_ERR_PORT_ID 			- Invalid port number.
 *      RT_ERR_QOS_QUEUE_WEIGHT - Invalid queue weight.
 * Note:
 *      The API can set weight and type, strict priority or weight fair queue (WFQ) for
 *      dedicated port for using queues. If queue id is not included in queue usage,
 *      then its type and weight setting in dummy for setting. There are priorities
 *      as queue id in strict queues. It means strict queue id 5 carrying higher priority
 *      than strict queue id 4. The WFQ queue weight is from 1 to 127, and weight 0 is
 *      for strict priority queue type.
 */
rtk_api_ret_t rtk_qos_schedulingQueue_set(rtk_port_t port, rtk_qos_queue_weights_t *pQweights)
{
    rtk_api_ret_t retVal;
    rtk_uint32 qid;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_VALID(port);

    for (qid = 0; qid < RTL8367C_QUEUENO; qid ++)
    {

        if (pQweights->weights[qid] > QOS_WEIGHT_MAX)
            return RT_ERR_QOS_QUEUE_WEIGHT;

        if (0 == pQweights->weights[qid])
        {
            if ((retVal = rtl8367c_setAsicQueueType(rtk_switch_port_L2P_get(port), qid, QTYPE_STRICT)) != RT_ERR_OK)
                return retVal;
        }
        else
        {
            if ((retVal = rtl8367c_setAsicQueueType(rtk_switch_port_L2P_get(port), qid, QTYPE_WFQ)) != RT_ERR_OK)
                return retVal;

            if ((retVal = rtl8367c_setAsicWFQWeight(rtk_switch_port_L2P_get(port),qid, pQweights->weights[qid])) != RT_ERR_OK)
                return retVal;
        }
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_qos_portPri_set
 * Description:
 *      Configure priority usage to each port.
 * Input:
 *      port - Port id.
 *      int_pri - internal priority value.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK              	- OK
 *      RT_ERR_FAILED          	- Failed
 *      RT_ERR_SMI             	- SMI access error
 *      RT_ERR_PORT_ID 			- Invalid port number.
 *      RT_ERR_QOS_SEL_PORT_PRI - Invalid port priority.
 *      RT_ERR_QOS_INT_PRIORITY - Invalid priority.
 * Note:
 *      The API can set priority of port assignments for queue usage and packet scheduling.
 */
rtk_api_ret_t rtk_qos_portPri_set(rtk_port_t port, rtk_pri_t int_pri)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_VALID(port);

    if (int_pri > RTL8367C_PRIMAX )
        return RT_ERR_QOS_INT_PRIORITY;

    if ((retVal = rtl8367c_setAsicPriorityPortBased(rtk_switch_port_L2P_get(port), int_pri)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_qos_portPriSelIndex_set
 * Description:
 *      Configure priority decision index to each port.
 * Input:
 *      port - Port id.
 *      index - priority decision index.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK              	- OK
 *      RT_ERR_FAILED          	- Failed
 *      RT_ERR_SMI             	- SMI access error
 *      RT_ERR_PORT_ID 			- Invalid port number.
 *      RT_ERR_ENTRY_INDEX - Invalid entry index.
 * Note:
 *      The API can set priority of port assignments for queue usage and packet scheduling.
 */
rtk_api_ret_t rtk_qos_portPriSelIndex_set(rtk_port_t port, rtk_qos_priDecTbl_t index)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    RTK_CHK_PORT_VALID(port);

    if (index >= PRIDECTBL_END )
        return RT_ERR_ENTRY_INDEX;

    if ((retVal = rtl8367c_setAsicPortPriorityDecisionIndex(rtk_switch_port_L2P_get(port), index)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

static rtk_api_ret_t _rtk_filter_igrAcl_writeDataField(rtl8367c_aclrule *aclRule, rtk_filter_field_t *fieldPtr)
{
    rtk_uint32 i, tempIdx,fieldIdx, ipValue, ipMask;
    rtk_uint32 ip6addr[RTK_IPV6_ADDR_WORD_LENGTH];
    rtk_uint32 ip6mask[RTK_IPV6_ADDR_WORD_LENGTH];

	for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
	{
		tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;

		aclRule[tempIdx].valid = TRUE;
	}

    switch (fieldPtr->fieldType)
    {
    /* use DMAC structure as representative for mac structure */
    case FILTER_FIELD_DMAC:
    case FILTER_FIELD_SMAC:

		for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
		{
			tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
			fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

			aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.mac.value.octet[5 - i*2] | (fieldPtr->filter_pattern_union.mac.value.octet[5 - (i*2 + 1)] << 8);
			aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.mac.mask.octet[5 - i*2] | (fieldPtr->filter_pattern_union.mac.mask.octet[5 - (i*2 + 1)] << 8);
		}
   		break;
    case FILTER_FIELD_ETHERTYPE:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
			fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.etherType.value;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.etherType.mask;
        }
        break;
    case FILTER_FIELD_IPV4_SIP:
    case FILTER_FIELD_IPV4_DIP:

		ipValue = fieldPtr->filter_pattern_union.sip.value;
		ipMask = fieldPtr->filter_pattern_union.sip.mask;

		for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
		{
			tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
			fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

			aclRule[tempIdx].data_bits.field[fieldIdx] = (ipValue & (0xFFFF << (i << 4))) >> (i << 4);
			aclRule[tempIdx].care_bits.field[fieldIdx] = (ipMask & (0xFFFF << (i << 4))) >> (i << 4);
		}
		break;
    case FILTER_FIELD_IPV4_TOS:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.ipTos.value & 0xFF;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.ipTos.mask  & 0xFF;
        }
        break;
    case FILTER_FIELD_IPV4_PROTOCOL:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.protocol.value & 0xFF;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.protocol.mask  & 0xFF;
        }
        break;
    case FILTER_FIELD_IPV6_SIPV6:
    case FILTER_FIELD_IPV6_DIPV6:
        for(i = 0; i < RTK_IPV6_ADDR_WORD_LENGTH; i++)
        {
            ip6addr[i] = fieldPtr->filter_pattern_union.sipv6.value.addr[i];
            ip6mask[i] = fieldPtr->filter_pattern_union.sipv6.mask.addr[i];
        }

		for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
		{
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
			fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            if(i < 2)
            {
                aclRule[tempIdx].data_bits.field[fieldIdx] = ((ip6addr[0] & (0xFFFF << (i * 16))) >> (i * 16));
                aclRule[tempIdx].care_bits.field[fieldIdx] = ((ip6mask[0] & (0xFFFF << (i * 16))) >> (i * 16));
            }
            else
            {
                /*default acl template for ipv6 address supports MSB 32-bits and LSB 32-bits only*/
                aclRule[tempIdx].data_bits.field[fieldIdx] = ((ip6addr[3] & (0xFFFF << ((i&1) * 16))) >> ((i&1) * 16));
                aclRule[tempIdx].care_bits.field[fieldIdx] = ((ip6mask[3] & (0xFFFF << ((i&1) * 16))) >> ((i&1) * 16));
            }
		}

		break;
	case FILTER_FIELD_CTAG:
    case FILTER_FIELD_STAG:

        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = (fieldPtr->filter_pattern_union.l2tag.pri.value << 13) | (fieldPtr->filter_pattern_union.l2tag.cfi.value << 12) | fieldPtr->filter_pattern_union.l2tag.vid.value;
            aclRule[tempIdx].care_bits.field[fieldIdx] = (fieldPtr->filter_pattern_union.l2tag.pri.mask << 13) | (fieldPtr->filter_pattern_union.l2tag.cfi.mask << 12) | fieldPtr->filter_pattern_union.l2tag.vid.mask;
        }
        break;
	case FILTER_FIELD_IPV4_FLAG:

        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] &= 0x1FFF;
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.ipFlag.xf.value << 15);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.ipFlag.df.value << 14);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.ipFlag.mf.value << 13);

            aclRule[tempIdx].care_bits.field[fieldIdx] &= 0x1FFF;
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.ipFlag.xf.mask << 15);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.ipFlag.df.mask << 14);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.ipFlag.mf.mask << 13);
        }

        break;
	case FILTER_FIELD_IPV4_OFFSET:

        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] &= 0xE000;
            aclRule[tempIdx].data_bits.field[fieldIdx] |= fieldPtr->filter_pattern_union.inData.value;

            aclRule[tempIdx].care_bits.field[fieldIdx] &= 0xE000;
            aclRule[tempIdx].care_bits.field[fieldIdx] |= fieldPtr->filter_pattern_union.inData.mask;
        }

        break;

	case FILTER_FIELD_IPV6_TRAFFIC_CLASS:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;


            aclRule[tempIdx].data_bits.field[fieldIdx] = (fieldPtr->filter_pattern_union.inData.value << 4)&0x0FF0;
            aclRule[tempIdx].care_bits.field[fieldIdx] = (fieldPtr->filter_pattern_union.inData.mask << 4)&0x0FF0;
        }
        break;
	case FILTER_FIELD_IPV6_NEXT_HEADER:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.inData.value << 8;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.inData.mask << 8;
        }
        break;
    case FILTER_FIELD_TCP_SPORT:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.tcpSrcPort.value;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.tcpSrcPort.mask;
        }
        break;
    case FILTER_FIELD_TCP_DPORT:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.tcpDstPort.value;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.tcpDstPort.mask;
        }
        break;
	case FILTER_FIELD_TCP_FLAG:

        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.cwr.value << 7);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.ece.value << 6);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.urg.value << 5);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.ack.value << 4);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.psh.value << 3);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.rst.value << 2);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.syn.value << 1);
            aclRule[tempIdx].data_bits.field[fieldIdx] |= fieldPtr->filter_pattern_union.tcpFlag.fin.value;

            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.cwr.mask << 7);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.ece.mask << 6);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.urg.mask << 5);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.ack.mask << 4);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.psh.mask << 3);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.rst.mask << 2);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.tcpFlag.syn.mask << 1);
            aclRule[tempIdx].care_bits.field[fieldIdx] |= fieldPtr->filter_pattern_union.tcpFlag.fin.mask;
        }
        break;
    case FILTER_FIELD_UDP_SPORT:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.udpSrcPort.value;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.udpSrcPort.mask;
        }
        break;
    case FILTER_FIELD_UDP_DPORT:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.udpDstPort.value;
            aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.udpDstPort.mask;
        }
        break;
	case FILTER_FIELD_ICMP_CODE:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] &= 0xFF00;
            aclRule[tempIdx].data_bits.field[fieldIdx] |= fieldPtr->filter_pattern_union.icmpCode.value;
            aclRule[tempIdx].care_bits.field[fieldIdx] &= 0xFF00;
            aclRule[tempIdx].care_bits.field[fieldIdx] |= fieldPtr->filter_pattern_union.icmpCode.mask;
        }
        break;
	case FILTER_FIELD_ICMP_TYPE:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] &= 0x00FF;
            aclRule[tempIdx].data_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.icmpType.value << 8);
            aclRule[tempIdx].care_bits.field[fieldIdx] &= 0x00FF;
            aclRule[tempIdx].care_bits.field[fieldIdx] |= (fieldPtr->filter_pattern_union.icmpType.mask << 8);
        }
        break;
	case FILTER_FIELD_IGMP_TYPE:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = (fieldPtr->filter_pattern_union.igmpType.value << 8);
            aclRule[tempIdx].care_bits.field[fieldIdx] = (fieldPtr->filter_pattern_union.igmpType.mask << 8);
        }
        break;
    case FILTER_FIELD_PATTERN_MATCH:
        for(i = 0; i < fieldPtr->fieldTemplateNo; i++)
        {
            tempIdx = (fieldPtr->fieldTemplateIdx[i] & 0xF0) >> 4;
            fieldIdx = fieldPtr->fieldTemplateIdx[i] & 0x0F;

            aclRule[tempIdx].data_bits.field[fieldIdx] = ((fieldPtr->filter_pattern_union.pattern.value[i/2] >> (16 * (i%2))) & 0x0000FFFF );
            aclRule[tempIdx].care_bits.field[fieldIdx] = ((fieldPtr->filter_pattern_union.pattern.mask[i/2] >> (16 * (i%2))) & 0x0000FFFF );
        }
        break;
    case FILTER_FIELD_VID_RANGE:
    case FILTER_FIELD_IP_RANGE:
    case FILTER_FIELD_PORT_RANGE:
    default:
		tempIdx = (fieldPtr->fieldTemplateIdx[0] & 0xF0) >> 4;
		fieldIdx = fieldPtr->fieldTemplateIdx[0] & 0x0F;

        aclRule[tempIdx].data_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.inData.value;
        aclRule[tempIdx].care_bits.field[fieldIdx] = fieldPtr->filter_pattern_union.inData.mask;
        break;
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_filter_igrAcl_cfg_delAll
 * Description:
 *      Delete all ACL entries from ASIC
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 * Note:
 *      This function delete all ACL configuration from ASIC.
 */
rtk_api_ret_t rtk_filter_igrAcl_cfg_delAll(void)
{
    rtk_uint32            i;
    rtk_api_ret_t     ret;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    for(i = 0; i < RTL8367C_ACLRULENO; i++)
    {
        if((ret = rtl8367c_setAsicAclActCtrl(i, FILTER_ENACT_INIT_MASK))!= RT_ERR_OK)
            return ret;
        if((ret = rtl8367c_setAsicAclNot(i, DISABLED)) != RT_ERR_OK )
            return ret;
    }

    return rtl8367c_setAsicRegBit(RTL8367C_REG_ACL_RESET_CFG, RTL8367C_ACL_RESET_CFG_OFFSET, TRUE);;
}

/* Function Name:
 *      rtk_filter_igrAcl_init
 * Description:
 *      ACL initialization function
 * Input:
 *      None
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK           - OK
 *      RT_ERR_FAILED       - Failed
 *      RT_ERR_SMI          - SMI access error
 *      RT_ERR_NULL_POINTER - Pointer pFilter_field or pFilter_cfg point to NULL.
 * Note:
 *      This function enable and intialize ACL function
 */
rtk_api_ret_t rtk_filter_igrAcl_init(void)
{
    rtl8367c_acltemplate_t       aclTemp;
    rtk_uint32                 i, j;
    rtk_api_ret_t          ret;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if ((ret = rtk_filter_igrAcl_cfg_delAll()) != RT_ERR_OK)
        return ret;

    for(i = 0; i < RTL8367C_ACLTEMPLATENO; i++)
    {
        for(j = 0; j < RTL8367C_ACLRULEFIELDNO;j++)
            aclTemp.field[j] = filter_templateField[i][j];

        if ((ret = rtl8367c_setAsicAclTemplate(i, &aclTemp)) != RT_ERR_OK)
            return ret;
    }

    for(i = 0; i < RTL8367C_FIELDSEL_FORMAT_NUMBER; i++)
    {
        if ((ret = rtl8367c_setAsicFieldSelector(i, field_selector[i][0], field_selector[i][1])) != RT_ERR_OK)
            return ret;
    }

    RTK_SCAN_ALL_PHY_PORTMASK(i)
    {
        if ((ret = rtl8367c_setAsicAcl(i, TRUE)) != RT_ERR_OK)
            return ret;

        if ((ret = rtl8367c_setAsicAclUnmatchedPermit(i, TRUE)) != RT_ERR_OK)
            return ret;
    }

    return RT_ERR_OK;
}


/* Function Name:
 *      rtk_filter_igrAcl_field_add
 * Description:
 *      Add comparison rule to an ACL configuration
 * Input:
 *      pFilter_cfg     - The ACL configuration that this function will add comparison rule
 *      pFilter_field   - The comparison rule that will be added.
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK              	- OK
 *      RT_ERR_FAILED          	- Failed
 *      RT_ERR_SMI             	- SMI access error
 *      RT_ERR_NULL_POINTER    	- Pointer pFilter_field or pFilter_cfg point to NULL.
 *      RT_ERR_INPUT 			- Invalid input parameters.
 * Note:
 *      This function add a comparison rule (*pFilter_field) to an ACL configuration (*pFilter_cfg).
 *      Pointer pFilter_cfg points to an ACL configuration structure, this structure keeps multiple ACL
 *      comparison rules by means of linked list. Pointer pFilter_field will be added to linked
 *      list keeped by structure that pFilter_cfg points to.
 */
rtk_api_ret_t rtk_filter_igrAcl_field_add(rtk_filter_cfg_t* pFilter_cfg, rtk_filter_field_t* pFilter_field)
{
	rtk_uint32 i;
	rtk_filter_field_t *tailPtr;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(NULL == pFilter_cfg || NULL == pFilter_field)
        return RT_ERR_NULL_POINTER;

    if(pFilter_field->fieldType >= FILTER_FIELD_END)
        return RT_ERR_ENTRY_INDEX;


	if(0 == pFilter_field->fieldTemplateNo)
	{
		pFilter_field->fieldTemplateNo = filter_fieldSize[pFilter_field->fieldType];

		for(i = 0; i < pFilter_field->fieldTemplateNo; i++)
		{
			pFilter_field->fieldTemplateIdx[i] = filter_fieldTemplateIndex[pFilter_field->fieldType][i];
		}
	}

    if(NULL == pFilter_cfg->fieldHead)
    {
        pFilter_cfg->fieldHead = pFilter_field;
    }
    else
    {
        if (pFilter_cfg->fieldHead->next == NULL)
        {
            pFilter_cfg->fieldHead->next = pFilter_field;
        }
        else
        {
            tailPtr = pFilter_cfg->fieldHead->next;
            while( tailPtr->next != NULL)
            {
                tailPtr = tailPtr->next;
            }
            tailPtr->next = pFilter_field;
        }
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_filter_igrAcl_cfg_add
 * Description:
 *      Add an ACL configuration to ASIC
 * Input:
 *      filter_id       - Start index of ACL configuration.
 *      pFilter_cfg     - The ACL configuration that this function will add comparison rule
 *      pFilter_action  - Action(s) of ACL configuration.
 * Output:
 *      ruleNum - number of rules written in acl table
 * Return:
 *      RT_ERR_OK              					- OK
 *      RT_ERR_FAILED          					- Failed
 *      RT_ERR_SMI             					- SMI access error
 *      RT_ERR_NULL_POINTER    					- Pointer pFilter_field or pFilter_cfg point to NULL.
 *      RT_ERR_INPUT 							- Invalid input parameters.
 *      RT_ERR_ENTRY_INDEX 						- Invalid filter_id .
 *      RT_ERR_NULL_POINTER 					- Pointer pFilter_action or pFilter_cfg point to NULL.
 *      RT_ERR_FILTER_INACL_ACT_NOT_SUPPORT 	- Action is not supported in this chip.
 *      RT_ERR_FILTER_INACL_RULE_NOT_SUPPORT 	- Rule is not supported.
 * Note:
 *      This function store pFilter_cfg, pFilter_action into ASIC. The starting
 *      index(es) is filter_id.
 */
rtk_api_ret_t rtk_filter_igrAcl_cfg_add(rtk_filter_id_t filter_id, rtk_filter_cfg_t* pFilter_cfg, rtk_filter_action_t* pFilter_action, rtk_filter_number_t *ruleNum)
{
    rtk_api_ret_t               retVal;
    rtk_uint32                  careTagData, careTagMask;
    rtk_uint32                  i,vidx, svidx, actType, ruleId;
    rtk_uint32                  aclActCtrl;
    rtk_uint32                  cpuPort;
    rtk_filter_field_t*         fieldPtr;
    rtl8367c_aclrule            aclRule[RTL8367C_ACLTEMPLATENO];
    rtl8367c_aclrule            tempRule;
    rtl8367c_acl_act_t          aclAct;
    rtk_uint32                  noRulesAdd;
    rtk_uint32                  portmask;
    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if(filter_id > RTL8367C_ACLRULEMAX )
        return RT_ERR_ENTRY_INDEX;

    if((NULL == pFilter_cfg) || (NULL == pFilter_action) || (NULL == ruleNum))
        return RT_ERR_NULL_POINTER;

    fieldPtr = pFilter_cfg->fieldHead;

    /* init RULE */
    for(i = 0; i < RTL8367C_ACLTEMPLATENO; i++)
    {
        memset(&aclRule[i], 0, sizeof(rtl8367c_aclrule));

        aclRule[i].data_bits.type= i;
        aclRule[i].care_bits.type= 0x7;
    }

    while(NULL != fieldPtr)
    {
        _rtk_filter_igrAcl_writeDataField(aclRule, fieldPtr);

        fieldPtr = fieldPtr->next;
    }

	/*set care tag mask in User Defined Field 15*/
	/*Follow care tag should not be used while ACL template and User defined fields are fully control by system designer*/
    /*those advanced packet type care tag is used in default template design structure only*/
	careTagData = 0;
	careTagMask = 0;

	for(i = CARE_TAG_TCP; i < CARE_TAG_END; i++)
    {
		if(pFilter_cfg->careTag.tagType[i].mask)
			careTagMask = careTagMask | (1 << (i-CARE_TAG_TCP));

		if(pFilter_cfg->careTag.tagType[i].value)
			careTagData = careTagData | (1 << (i-CARE_TAG_TCP));
    }

	if(careTagData || careTagMask)
	{
		i = 0;
		while(i < RTL8367C_ACLTEMPLATENO)
		{
			if(aclRule[i].valid == 1 && filter_advanceCaretagField[i][0] == TRUE)
			{

				aclRule[i].data_bits.field[filter_advanceCaretagField[i][1]] = careTagData & 0xFFFF;
				aclRule[i].care_bits.field[filter_advanceCaretagField[i][1]] = careTagMask & 0xFFFF;
				break;
			}
			i++;
		}
		/*none of previous used template containing field 15*/
		if(i == RTL8367C_ACLTEMPLATENO)
		{
			i = 0;
			while(i <= RTL8367C_ACLTEMPLATENO)
			{
				if(filter_advanceCaretagField[i][0] == TRUE)
				{
					aclRule[i].data_bits.field[filter_advanceCaretagField[i][1]] = careTagData & 0xFFFF;
					aclRule[i].care_bits.field[filter_advanceCaretagField[i][1]] = careTagMask & 0xFFFF;
					aclRule[i].valid = 1;
					break;
				}
				i++;
			}
		}
	}

	/*Check rule number*/
	noRulesAdd = 0;
    for(i = 0; i < RTL8367C_ACLTEMPLATENO; i++)
    {
		if(1 == aclRule[i].valid)
		{
			noRulesAdd ++;
		}
    }

	*ruleNum = noRulesAdd;

	if((filter_id + noRulesAdd - 1) > RTL8367C_ACLRULEMAX)
	{
		return RT_ERR_ENTRY_INDEX;
	}

	/*set care tag mask in TAG Indicator*/
    careTagData = 0;
	careTagMask = 0;

    for(i = 0; i <= CARE_TAG_IPV6;i++)
    {
        if(0 == pFilter_cfg->careTag.tagType[i].mask )
        {
            careTagMask &=  ~(1 << i);
        }
        else
        {
            careTagMask |= (1 << i);
            if(0 == pFilter_cfg->careTag.tagType[i].value )
                careTagData &= ~(1 << i);
            else
                careTagData |= (1 << i);
        }
    }

    for(i = 0; i < RTL8367C_ACLTEMPLATENO; i++)
    {
        aclRule[i].data_bits.tag_exist = (careTagData) & ACL_RULE_CARETAG_MASK;
        aclRule[i].care_bits.tag_exist = (careTagMask) & ACL_RULE_CARETAG_MASK;
    }

    RTK_CHK_PORTMASK_VALID(&pFilter_cfg->activeport.value);
    RTK_CHK_PORTMASK_VALID(&pFilter_cfg->activeport.mask);

    for(i = 0; i < RTL8367C_ACLTEMPLATENO; i++)
    {
		if(TRUE == aclRule[i].valid)
		{
		    rtk_switch_portmask_L2P_get(&pFilter_cfg->activeport.value, &portmask);
			aclRule[i].data_bits.active_portmsk = portmask;

            rtk_switch_portmask_L2P_get(&pFilter_cfg->activeport.mask, &portmask);
			aclRule[i].care_bits.active_portmsk = portmask;
		}
    }

    if(pFilter_cfg->invert >= FILTER_INVERT_END )
        return RT_ERR_INPUT;


	/*Last action gets high priority if actions are the same*/
    memset(&aclAct, 0, sizeof(rtl8367c_acl_act_t));
    aclActCtrl = 0;
    for(actType = 0; actType < FILTER_ENACT_END; actType ++)
    {
        if(pFilter_action->actEnable[actType])
        {
            switch (actType)
            {
#if 0
            case FILTER_ENACT_CVLAN_INGRESS:
                if(pFilter_action->filterCvlanVid > RTL8367C_EVIDMAX)
                    return RT_ERR_INPUT;

                if((retVal = rtk_vlan_checkAndCreateMbr(pFilter_action->filterCvlanVid, &vidx)) != RT_ERR_OK)
                {
                    return retVal;
                }
                aclAct.cact = FILTER_ENACT_CVLAN_TYPE(actType);
                aclAct.cvidx_cact = vidx;

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_TAGONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_VLANONLY;
                }

                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;
            case FILTER_ENACT_CVLAN_EGRESS:
                if(pFilter_action->filterCvlanVid > RTL8367C_EVIDMAX)
                    return RT_ERR_INPUT;

                if((retVal = rtk_vlan_checkAndCreateMbr(pFilter_action->filterCvlanVid, &vidx)) != RT_ERR_OK)
                    return retVal;

                aclAct.cact = FILTER_ENACT_CVLAN_TYPE(actType);
                aclAct.cvidx_cact = vidx;

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_TAGONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_VLANONLY;
                }

                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;
             case FILTER_ENACT_CVLAN_SVID:

                aclAct.cact = FILTER_ENACT_CVLAN_TYPE(actType);

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_TAGONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_VLANONLY;
                }

                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;
             case FILTER_ENACT_POLICING_1:
                if(pFilter_action->filterPolicingIdx[1] >= (RTK_METER_NUM + RTL8367C_MAX_LOG_CNT_NUM))
                    return RT_ERR_INPUT;

                aclAct.cact = FILTER_ENACT_CVLAN_TYPE(actType);
                aclAct.cvidx_cact = pFilter_action->filterPolicingIdx[1];

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_TAGONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_VLANONLY;
                }

                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;

            case FILTER_ENACT_SVLAN_INGRESS:
            case FILTER_ENACT_SVLAN_EGRESS:

                if((retVal = rtk_svlan_checkAndCreateMbr(pFilter_action->filterSvlanVid, &svidx)) != RT_ERR_OK)
				    return retVal;

                aclAct.sact = FILTER_ENACT_SVLAN_TYPE(actType);
				aclAct.svidx_sact = svidx;
                aclActCtrl |= FILTER_ENACT_SVLAN_MASK;
                break;
            case FILTER_ENACT_SVLAN_CVID:

                aclAct.sact = FILTER_ENACT_SVLAN_TYPE(actType);
                aclActCtrl |= FILTER_ENACT_SVLAN_MASK;
				break;
            case FILTER_ENACT_POLICING_2:
                if(pFilter_action->filterPolicingIdx[2] >= (RTK_METER_NUM + RTL8367C_MAX_LOG_CNT_NUM))
                    return RT_ERR_INPUT;

                aclAct.sact = FILTER_ENACT_SVLAN_TYPE(actType);
                aclAct.svidx_sact = pFilter_action->filterPolicingIdx[2];
                aclActCtrl |= FILTER_ENACT_SVLAN_MASK;
                break;
#endif

            case FILTER_ENACT_POLICING_0:
                if(pFilter_action->filterPolicingIdx[0] >= (RTK_METER_NUM + RTL8367C_MAX_LOG_CNT_NUM))
                    return RT_ERR_INPUT;

                aclAct.aclmeteridx = pFilter_action->filterPolicingIdx[0];
                aclActCtrl |= FILTER_ENACT_POLICING_MASK;
                break;

            case FILTER_ENACT_PRIORITY:
            case FILTER_ENACT_1P_REMARK:
                if(pFilter_action->filterPriority > RTL8367C_PRIMAX)
                    return RT_ERR_INPUT;

                aclAct.priact = FILTER_ENACT_PRI_TYPE(actType);
                aclAct.pridx = pFilter_action->filterPriority;
                aclActCtrl |= FILTER_ENACT_PRIORITY_MASK;
                break;
#if 0
            case FILTER_ENACT_DSCP_REMARK:
                if(pFilter_action->filterPriority > RTL8367C_DSCPMAX)
                    return RT_ERR_INPUT;

                aclAct.priact = FILTER_ENACT_PRI_TYPE(actType);
                aclAct.pridx = pFilter_action->filterPriority;
                aclActCtrl |= FILTER_ENACT_PRIORITY_MASK;
                break;
            case FILTER_ENACT_POLICING_3:
                if(pFilter_action->filterPriority >= (RTK_METER_NUM + RTL8367C_MAX_LOG_CNT_NUM))
                    return RT_ERR_INPUT;

                aclAct.priact = FILTER_ENACT_PRI_TYPE(actType);
                aclAct.pridx = pFilter_action->filterPolicingIdx[3];
                aclActCtrl |= FILTER_ENACT_PRIORITY_MASK;
                break;
#endif
            case FILTER_ENACT_DROP:

                aclAct.fwdact = FILTER_ENACT_FWD_TYPE(FILTER_ENACT_REDIRECT);
                aclAct.fwdact_ext = FALSE;

                aclAct.fwdpmask = 0;
                aclActCtrl |= FILTER_ENACT_FWD_MASK;
                break;
#if 0
            case FILTER_ENACT_REDIRECT:
                RTK_CHK_PORTMASK_VALID(&pFilter_action->filterPortmask);

                aclAct.fwdact = FILTER_ENACT_FWD_TYPE(actType);
                aclAct.fwdact_ext = FALSE;

                rtk_switch_portmask_L2P_get(&pFilter_action->filterPortmask, &portmask);
                aclAct.fwdpmask = portmask;

                aclActCtrl |= FILTER_ENACT_FWD_MASK;
                break;

            case FILTER_ENACT_ADD_DSTPORT:
                RTK_CHK_PORTMASK_VALID(&pFilter_action->filterPortmask);

                aclAct.fwdact = FILTER_ENACT_FWD_TYPE(actType);
                aclAct.fwdact_ext = FALSE;

                rtk_switch_portmask_L2P_get(&pFilter_action->filterPortmask, &portmask);
                aclAct.fwdpmask = portmask;

                aclActCtrl |= FILTER_ENACT_FWD_MASK;
                break;
            case FILTER_ENACT_MIRROR:
                RTK_CHK_PORTMASK_VALID(&pFilter_action->filterPortmask);

                aclAct.fwdact = FILTER_ENACT_FWD_TYPE(actType);
                aclAct.cact_ext = FALSE;

                rtk_switch_portmask_L2P_get(&pFilter_action->filterPortmask, &portmask);
                aclAct.fwdpmask = portmask;

                aclActCtrl |= FILTER_ENACT_FWD_MASK;
                break;
            case FILTER_ENACT_TRAP_CPU:

                aclAct.fwdact = FILTER_ENACT_FWD_TYPE(actType);
                aclAct.fwdact_ext = FALSE;

                aclActCtrl |= FILTER_ENACT_FWD_MASK;
                break;
            case FILTER_ENACT_COPY_CPU:
                if((retVal = rtl8367c_getAsicCputagTrapPort(&cpuPort)) != RT_ERR_OK)
                    return retVal;

                aclAct.fwdact = FILTER_ENACT_FWD_TYPE(FILTER_ENACT_MIRROR);
                aclAct.fwdact_ext = FALSE;

                aclAct.fwdpmask = 1 << cpuPort;
                aclActCtrl |= FILTER_ENACT_FWD_MASK;
                break;
            case FILTER_ENACT_ISOLATION:
                RTK_CHK_PORTMASK_VALID(&pFilter_action->filterPortmask);

                aclAct.fwdact_ext = TRUE;

                rtk_switch_portmask_L2P_get(&pFilter_action->filterPortmask, &portmask);
                aclAct.fwdpmask = portmask;

                aclActCtrl |= FILTER_ENACT_FWD_MASK;
                break;

            case FILTER_ENACT_INTERRUPT:

                aclAct.aclint = TRUE;
                aclActCtrl |= FILTER_ENACT_INTGPIO_MASK;
                break;
            case FILTER_ENACT_GPO:

                aclAct.gpio_en = TRUE;
                aclAct.gpio_pin = pFilter_action->filterPin;
                aclActCtrl |= FILTER_ENACT_INTGPIO_MASK;
                break;
             case FILTER_ENACT_EGRESSCTAG_TAG:

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_VLANONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_TAGONLY;
                }
                aclAct.tag_fmt = FILTER_CTAGFMT_TAG;
                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;
             case FILTER_ENACT_EGRESSCTAG_UNTAG:

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_VLANONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_TAGONLY;
                }
                aclAct.tag_fmt = FILTER_CTAGFMT_UNTAG;
                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;
             case FILTER_ENACT_EGRESSCTAG_KEEP:

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_VLANONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_TAGONLY;
                }
                aclAct.tag_fmt = FILTER_CTAGFMT_KEEP;
                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;
             case FILTER_ENACT_EGRESSCTAG_KEEPAND1PRMK:

                if(aclActCtrl &(FILTER_ENACT_CVLAN_MASK))
                {
                    if(aclAct.cact_ext == FILTER_ENACT_CACTEXT_VLANONLY)
                        aclAct.cact_ext = FILTER_ENACT_CACTEXT_BOTHVLANTAG;
                }
                else
                {
                    aclAct.cact_ext = FILTER_ENACT_CACTEXT_TAGONLY;
                }
                aclAct.tag_fmt = FILTER_CTAGFMT_KEEP1PRMK;
                aclActCtrl |= FILTER_ENACT_CVLAN_MASK;
                break;
#endif
           default:
                return RT_ERR_FILTER_INACL_ACT_NOT_SUPPORT;
            }
        }
    }


	/*check if free ACL rules are enough*/
    for(i = filter_id; i < (filter_id + noRulesAdd); i++)
    {
        if((retVal = rtl8367c_getAsicAclRule(i, &tempRule)) != RT_ERR_OK )
            return retVal;

        if(tempRule.valid == TRUE)
        {
            return RT_ERR_TBL_FULL;
        }
    }

	ruleId = 0;
    for(i = 0; i < RTL8367C_ACLTEMPLATENO; i++)
    {
        if(aclRule[i].valid == TRUE)
        {
            /* write ACL action control */
            if((retVal = rtl8367c_setAsicAclActCtrl(filter_id + ruleId, aclActCtrl)) != RT_ERR_OK )
                return retVal;
            /* write ACL action */
            if((retVal = rtl8367c_setAsicAclAct(filter_id + ruleId, &aclAct)) != RT_ERR_OK )
                return retVal;

            /* write ACL not */
            if((retVal = rtl8367c_setAsicAclNot(filter_id + ruleId, pFilter_cfg->invert)) != RT_ERR_OK )
                return retVal;
            /* write ACL rule */
            if((retVal = rtl8367c_setAsicAclRule(filter_id + ruleId, &aclRule[i])) != RT_ERR_OK )
                return retVal;

            /* only the first rule will be written with input action control, aclActCtrl of other rules will be zero */
            aclActCtrl = 0;
            memset(&aclAct, 0, sizeof(rtl8367c_acl_act_t));

			ruleId ++;
		}
    }

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_rate_shareMeter_set
 * Description:
 *      Set meter configuration
 * Input:
 *      index       - shared meter index
 *      type        - shared meter type
 *      rate        - rate of share meter
 *      ifg_include - include IFG or not, ENABLE:include DISABLE:exclude
 * Output:
 *      None
 * Return:
 *      RT_ERR_OK               - OK
 *      RT_ERR_FAILED           - Failed
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_FILTER_METER_ID  - Invalid meter
 *      RT_ERR_RATE             - Invalid rate
 *      RT_ERR_INPUT            - Invalid input parameters
 * Note:
 *      The API can set shared meter rate and ifg include for each meter.
 *      The rate unit is 1 kbps and the range is from 8k to 1048568k if type is METER_TYPE_KBPS and
 *      the granularity of rate is 8 kbps.
 *      The rate unit is packets per second and the range is 1 ~ 0x1FFF if type is METER_TYPE_PPS.
 *      The ifg_include parameter is used
 *      for rate calculation with/without inter-frame-gap and preamble.
 */
rtk_api_ret_t rtk_rate_shareMeter_set(rtk_meter_id_t index, rtk_meter_type_t type, rtk_rate_t rate, rtk_enable_t ifg_include)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if (index > RTK_MAX_METER_ID)
        return RT_ERR_FILTER_METER_ID;

    if (type >= METER_TYPE_END)
        return RT_ERR_INPUT;

    if (ifg_include >= RTK_ENABLE_END)
        return RT_ERR_INPUT;

    switch (type)
    {
        case METER_TYPE_KBPS:
            if (rate > RTL8367C_QOS_RATE_INPUT_MAX_HSG || rate < RTL8367C_QOS_RATE_INPUT_MIN)
                return RT_ERR_RATE ;

            if ((retVal = rtl8367c_setAsicShareMeter(index, rate >> 3, ifg_include)) != RT_ERR_OK)
                return retVal;

            break;
        case METER_TYPE_PPS:
            if (rate > RTL8367C_QOS_PPS_INPUT_MAX || rate < RTL8367C_QOS_PPS_INPUT_MIN)
                return RT_ERR_RATE ;

            if ((retVal = rtl8367c_setAsicShareMeter(index, rate, ifg_include)) != RT_ERR_OK)
                return retVal;

            break;
        default:
            return RT_ERR_INPUT;
    }

    /* Set Type */
    if ((retVal = rtl8367c_setAsicShareMeterType(index, (rtk_uint32)type)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}

/* Function Name:
 *      rtk_rate_shareMeterBucket_set
 * Description:
 *      Set meter Bucket Size
 * Input:
 *      index        - shared meter index
 *      bucket_size  - Bucket Size
 * Output:
 *      None.
 * Return:
 *      RT_ERR_OK               - OK
 *      RT_ERR_FAILED           - Failed
 *      RT_ERR_INPUT            - Error Input
 *      RT_ERR_SMI              - SMI access error
 *      RT_ERR_FILTER_METER_ID  - Invalid meter
 * Note:
 *      The API can set shared meter bucket size.
 */
rtk_api_ret_t rtk_rate_shareMeterBucket_set(rtk_meter_id_t index, rtk_uint32 bucket_size)
{
    rtk_api_ret_t retVal;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    if (index > RTK_MAX_METER_ID)
        return RT_ERR_FILTER_METER_ID;

    if(bucket_size > RTL8367C_METERBUCKETSIZEMAX)
        return RT_ERR_INPUT;

    if ((retVal = rtl8367c_setAsicShareMeterBucketSize(index, bucket_size)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
}
#endif
/**************************************************************************************************/
/*                                           PUBLIC_FUNCTIONS                                     */
/**************************************************************************************************/


rtk_api_ret_t rt_rtl8367_initVlan()
{
	rtk_api_ret_t ret;
	
	RTL8367_DEBUG("Call Func rt_rtl8367_initVlan()\n");

	if(ret = rtk_vlan_init() != RT_ERR_OK)
	{
		RTL8367_ERROR("rtk_vlan_init fail\n");
		return ret;
	}
	
       return RT_ERR_OK;
}

rtk_api_ret_t rt_rtl8367_initQoS()
{
	rtk_api_ret_t retVal = RT_ERR_OK;
	rtk_qos_pri2queue_t pri2queue;
	rtk_priority_select_t priSel;
	rtk_port_t port;
	rtk_qos_queue_weights_t qweight;
	rtk_filter_field_t filter_field;
	rtk_filter_cfg_t cfg;
	rtk_filter_action_t act;
	rtk_filter_number_t ruleNum;

#if 0
	/* port QoS Setting */
	if ((retVal = rtk_qos_init(8)) != RT_ERR_OK)
		return retVal;
	
	rtk_qos_portPri_set(UTP_PORT0, 0);
	rtk_qos_portPri_set(UTP_PORT1, 1);
	rtk_qos_portPri_set(UTP_PORT2, 2);
	rtk_qos_portPri_set(UTP_PORT3, 3);
	rtk_qos_portPri_set(UTP_PORT4, 4);

	priSel.port_pri 	= 7;
	priSel.dot1q_pri	= 0;
	priSel.acl_pri		= 0;
	priSel.dscp_pri 	= 0;
	priSel.cvlan_pri	= 0;
	priSel.svlan_pri	= 0;
	priSel.dmac_pri 	= 0;
	priSel.smac_pri 	= 0;
	if ((retVal = rtk_qos_priSel_set(PRIDECTBL_IDX0, &priSel)) != RT_ERR_OK)
		return retVal;

	rtk_qos_portPriSelIndex_set(UTP_PORT0, PRIDECTBL_IDX0);
	rtk_qos_portPriSelIndex_set(UTP_PORT1, PRIDECTBL_IDX0);
	rtk_qos_portPriSelIndex_set(UTP_PORT2, PRIDECTBL_IDX0);
	rtk_qos_portPriSelIndex_set(UTP_PORT3, PRIDECTBL_IDX0);
#if defined(CONFIG_TP_MODEL_C5V4)
	rtk_qos_portPriSelIndex_set(UTP_PORT4, PRIDECTBL_IDX0);
#endif

	pri2queue.pri2queue[0] = 0;
	pri2queue.pri2queue[1] = 1;
	pri2queue.pri2queue[2] = 2;
	pri2queue.pri2queue[3] = 3;
	pri2queue.pri2queue[4] = 4;
	pri2queue.pri2queue[5] = 5;
	pri2queue.pri2queue[6] = 6;
	pri2queue.pri2queue[7] = 7;
	if ((retVal = rtk_qos_priMap_set(8, &pri2queue)) != RT_ERR_OK)
		return retVal;
	
	RTK_SCAN_ALL_LOG_PORT(port)
	{
		qweight.weights[0] = 0; //Strict Priority
		qweight.weights[1] = 0; //Strict Priority
		qweight.weights[2] = 0; //Strict Priority
		qweight.weights[3] = 0; //Strict Priority
		qweight.weights[4] = 0; //Strict Priority
		qweight.weights[5] = 0; //Strict Priority			
		qweight.weights[6] = 0; //Strict Priority
		qweight.weights[7] = 0; //Strict Priority		 
		if((retVal=rtk_qos_schedulingQueue_set(port, &qweight))!= RT_ERR_OK)
			return retVal;
	}
#else
	/* ACL QoS Setting */
	if ((retVal = rtk_qos_init(8)) != RT_ERR_OK)
		return retVal;
	
	priSel.port_pri 	= 0;
	priSel.dot1q_pri	= 0;
	if(CHIP_RTL8367D == g_switch_chip)
	{
		/*CHIP_RTL8367D only 4 acl_pri*/
		priSel.acl_pri		= 4;
	}
	else
	{
		priSel.acl_pri		= 7;
	}
	priSel.dscp_pri 	= 0;
	priSel.cvlan_pri	= 0;
	priSel.svlan_pri	= 0;
	priSel.dmac_pri 	= 0;
	priSel.smac_pri 	= 0;
	if ((retVal = rtk_qos_priSel_set(PRIDECTBL_IDX0, &priSel)) != RT_ERR_OK)
		return retVal;

	rtk_qos_portPriSelIndex_set(UTP_PORT0, PRIDECTBL_IDX0);
	rtk_qos_portPriSelIndex_set(UTP_PORT1, PRIDECTBL_IDX0);
	rtk_qos_portPriSelIndex_set(UTP_PORT2, PRIDECTBL_IDX0);
	rtk_qos_portPriSelIndex_set(UTP_PORT3, PRIDECTBL_IDX0);
	rtk_qos_portPriSelIndex_set(UTP_PORT4, PRIDECTBL_IDX0);

	pri2queue.pri2queue[0] = 0;
	pri2queue.pri2queue[1] = 1;
	pri2queue.pri2queue[2] = 2;
	pri2queue.pri2queue[3] = 3;
	pri2queue.pri2queue[4] = 4;
	pri2queue.pri2queue[5] = 5;
	pri2queue.pri2queue[6] = 6;
	pri2queue.pri2queue[7] = 7;
	if ((retVal = rtk_qos_priMap_set(8, &pri2queue)) != RT_ERR_OK)
		return retVal;
	
	RTK_SCAN_ALL_LOG_PORT(port)
	{
		qweight.weights[0] = 0; //Strict Priority
		qweight.weights[1] = 0; //Strict Priority
		qweight.weights[2] = 0; //Strict Priority
		qweight.weights[3] = 0; //Strict Priority
		qweight.weights[4] = 0; //Strict Priority
		qweight.weights[5] = 0; //Strict Priority			
		qweight.weights[6] = 0; //Strict Priority
		qweight.weights[7] = 0; //Strict Priority		 
		if((retVal=rtk_qos_schedulingQueue_set(port, &qweight))!= RT_ERR_OK)
			return retVal;
	}

	/* ACL initial */
	if((retVal = rtk_filter_igrAcl_init()) != RT_ERR_OK)
		return retVal;
	
	memset(&cfg, 0, sizeof(rtk_filter_cfg_t));
	memset(&act, 0, sizeof(rtk_filter_action_t));
	memset(&filter_field, 0, sizeof(rtk_filter_field_t));
	filter_field.fieldType = FILTER_FIELD_DMAC;
	filter_field.filter_pattern_union.dmac.dataType = FILTER_FIELD_DATA_MASK;
	filter_field.filter_pattern_union.dmac.value.octet[0] = 0x00; /* bit8=0, unicast packet */
	filter_field.filter_pattern_union.dmac.value.octet[1] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[2] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[3] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[4] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[5] = 0x00;
	
	filter_field.filter_pattern_union.dmac.mask.octet[0] = 0x01; /* check bit8*/
	filter_field.filter_pattern_union.dmac.mask.octet[1] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[2] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[3] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[4] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[5] = 0x00;

	if ((retVal = rtk_filter_igrAcl_field_add(&cfg, &filter_field)) != RT_ERR_OK)
		 return retVal;
	
	cfg.careTag.tagType[CARE_TAG_IPV4].value = TRUE;
	cfg.careTag.tagType[CARE_TAG_IPV4].mask = TRUE;
#if defined(CONFIG_TP_MODEL_C5V4)
	RTK_PORTMASK_PORT_SET(cfg.activeport.value, UTP_PORT4); /* from WAN port */
#else
	RTK_PORTMASK_PORT_SET(cfg.activeport.value, UTP_PORT3); /* from EC220 WAN port */
 #if defined(CONFIG_TP_MODEL_EC220_G5sV1)
	RTK_PORTMASK_PORT_SET(cfg.activeport.value, EXT_PORT0); /* from EC220-G5s WAN port */
 #endif
#endif
	RTK_PORTMASK_ALLPORT_SET(cfg.activeport.mask);
	cfg.invert = FALSE;
	act.actEnable[FILTER_ENACT_POLICING_0] = TRUE; /* traffic shaping */
	act.filterPolicingIdx[0]=0; /* by meter 0 */
	
	if ((retVal = rtk_filter_igrAcl_cfg_add(0, &cfg, &act, &ruleNum)) != RT_ERR_OK)
		return retVal;

	memset(&cfg, 0, sizeof(rtk_filter_cfg_t));
	memset(&act, 0, sizeof(rtk_filter_action_t));
	memset(&filter_field, 0, sizeof(rtk_filter_field_t));
	filter_field.fieldType = FILTER_FIELD_DMAC;
	filter_field.filter_pattern_union.dmac.dataType = FILTER_FIELD_DATA_MASK;
	filter_field.filter_pattern_union.dmac.value.octet[0] = 0x01; /* bit8=1, multicast packet */
	filter_field.filter_pattern_union.dmac.value.octet[1] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[2] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[3] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[4] = 0x00;
	filter_field.filter_pattern_union.dmac.value.octet[5] = 0x00;
	
	filter_field.filter_pattern_union.dmac.mask.octet[0] = 0x01; /* check bit8*/
	filter_field.filter_pattern_union.dmac.mask.octet[1] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[2] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[3] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[4] = 0x00;
	filter_field.filter_pattern_union.dmac.mask.octet[5] = 0x00;

	if ((retVal = rtk_filter_igrAcl_field_add(&cfg, &filter_field)) != RT_ERR_OK)
		 return retVal;
	
	cfg.careTag.tagType[CARE_TAG_IPV4].value = TRUE;
	cfg.careTag.tagType[CARE_TAG_IPV4].mask = TRUE;
	RTK_PORTMASK_ALLPORT_SET(cfg.activeport.value);
	RTK_PORTMASK_ALLPORT_SET(cfg.activeport.mask);
	cfg.invert = FALSE;
	act.actEnable[FILTER_ENACT_PRIORITY] = TRUE;
	act.filterPriority = 7;
	
	if ((retVal = rtk_filter_igrAcl_cfg_add(1, &cfg, &act, &ruleNum)) != RT_ERR_OK)
		return retVal;

	/*Share meter setting*/
	if ((retVal = rtk_rate_shareMeter_set(0, METER_TYPE_KBPS, 900*1000, ENABLED)) != RT_ERR_OK)
		return retVal;

#endif

	return retVal;
}

#if defined(CONFIG_TP_MODEL_C5V4)
int rt_rt8367_chkLan(void)
{
	u32 regData = 0;
	int count = 0;
	int ret = 0;
	int rtl8367_port0_status_reg = (CHIP_RTL8367D == g_switch_chip) ? RTL8367D_REG_PORT0_STATUS :RTL8367C_REG_PORT0_STATUS;

	for (count = 0; count <= 3; count++)
	{
		RT_MAPPER->smi_read(rtl8367_port0_status_reg + count, &regData);
		if (regData & 0x10)
		{
			ret = 1;
			break;
		}
	}
	return ret;
}

/* For C5 port4 is WAN */
int rt_rt8367_chkWan(void)
{
	u32 regData = 0;
	int rtl8367_port0_status_reg = (CHIP_RTL8367D == g_switch_chip) ? RTL8367D_REG_PORT0_STATUS :RTL8367C_REG_PORT0_STATUS;
	RT_MAPPER->smi_read(rtl8367_port0_status_reg+4, &regData);
	if (regData & 0x10)
	{
		return 1;
	}
	return 0;
}
#else
/* For EC220  port 0~2 is LAN */
int rt_rt8367_chkLan(void)
{
	u32 regData = 0;
	int count = 0;
	int ret = 0;
	int rtl8367_port0_status_reg = (CHIP_RTL8367D == g_switch_chip) ? RTL8367D_REG_PORT0_STATUS :RTL8367C_REG_PORT0_STATUS;

	for (count = 0; count <= 2; count++)
	{
		RT_MAPPER->smi_read(rtl8367_port0_status_reg + count, &regData);
		if (regData & 0x10)
		{
			ret = 1;
			break;
		}
	}
	return ret;
}

/* For EC220 port3 is WAN */
int rt_rt8367_chkWan(void)
{
	u32 regData = 0;

	int rtl8367_port0_status_reg = (CHIP_RTL8367D == g_switch_chip) ? RTL8367D_REG_PORT0_STATUS :RTL8367C_REG_PORT0_STATUS;
	RT_MAPPER->smi_read(rtl8367_port0_status_reg+3, &regData);
	if (regData & 0x10)
	{
		return 1;
	}
	return 0;
}

#endif
void rt_rtl8367_phy_status(void)
{
#if 1
#else
	u32 regData = 0;
	int count = 0;
	rtl_smi_read(RTL8367_EXTINTF_CTRL_REG, &regData);
	printf("RTL8367_EXTINTF_CTRL_REG is 0x%x\n", regData);

	for (count = 0; count <= 7; count++)
	{
		regData = 0;
		rtl_smi_read(RTL8367_PORT0_STATUS_REG + count, &regData);
		printf("RTL8367_PORT_STATUS_REG(%d) is 0x%x\n", count, regData);
	}
#endif
	
}

/* 
 * According to <RTL8367S_Switch_ProgrammingGuide> 4.14 Force External Interface 
 * For RTL8367S, MAC7 <---> RG2(Port2)
 */
void rt_rtl8367_enableRgmii(void)
{
#if 0
	/* 
	 * 1. rtl8367c_setAsicPortExtMode
	 * (EXT_PORT_1, MODE_EXT_RGMII)
	 */

	/*RTL8367C_REG_BYPASS_LINE_RATE | RTL8367D_REG_BYPASS_LINE_RATE*/
	rtl8367c_setAsicRegBit(0x03f7, 2, 0);
	/* RTL8367C_REG_DIGITAL_INTERFACE_SELECT_1 | RTL8367D_REG_DIGITAL_INTERFACE_SELECT_1 */
	rtl8367c_setAsicRegBits(0x13c3, 0xF, 1);

	/* 2. rtl8367c_getAsicPortForceLinkExt */
	/* 3. rtl8367c_setAsicPortForceLinkExt */
	{
		u32 reg_data;
		//rtl8367c_port_ability_t *pExtPort1 = (u16*)&reg_data;
		// RTL8367D LOST  _rtl8367s_mii_type_refresh
		rtl_smi_read(RTL8367C_REG_DIGITAL_INTERFACE2_FORCE, &reg_data);

		reg_data &= ~0x10f7;
		reg_data |= ((1<<12) | (2 << 0) | (1 << 2) | (7 << 4));
		
		/*pExtPort1->forcemode = 1;
		pExtPort1->speed = 2;
		pExtPort1->duplex = 1;
		pExtPort1->link = 1;
		pExtPort1->nway = 0;
		pExtPort1->txpause = 1;
		pExtPort1->rxpause = 1;*/
		rtl_smi_write(RTL8367C_REG_DIGITAL_INTERFACE2_FORCE, reg_data);
	}
#endif
	int ret = 0;
	rtk_port_mac_ability_t ability;

	ability.forcemode = PORT_MAC_FORCE;
	ability.speed = PORT_SPEED_1000M;
	ability.duplex = PORT_FULL_DUPLEX;
	ability.link = PORT_LINKUP;
	ability.nway = DISABLED;
	ability.txpause = ENABLED;
	ability.rxpause = ENABLED;
	if ((ret = rtk_port_macForceLinkExt_set(EXT_PORT1, MODE_EXT_RGMII, &ability)) != RT_ERR_OK) 
	{
		RTL8367_ERROR("rtk_port_macForceLinkExt_set failed...ret=%d\n", ret);
	}
}


#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
#if 0 /* Use rt_rtl8367_enableSgmii() to replace this API */
static rtk_api_ret_t _rtk_port_macForceLinkExt_set(rtk_port_t port, rtk_mode_ext_t mode, rtk_port_mac_ability_t *pPortability)
{
    rtk_api_ret_t retVal;
    rtl8367c_port_ability_t ability;
    rtk_uint32 ext_id;

    if(NULL == pPortability)
        return RT_ERR_NULL_POINTER;

    if (mode >=MODE_EXT_END)
        return RT_ERR_INPUT;

    if(mode == MODE_EXT_HSGMII)
    {
        if (pPortability->forcemode > 1 || pPortability->speed != PORT_SPEED_2500M || pPortability->duplex != PORT_FULL_DUPLEX ||
           pPortability->link >= PORT_LINKSTATUS_END || pPortability->nway > 1 || pPortability->txpause > 1 || pPortability->rxpause > 1)
            return RT_ERR_INPUT;

        if(rtk_switch_isHsgPort(port) != RT_ERR_OK)
            return RT_ERR_PORT_ID;
    }
    else
    {
        if (pPortability->forcemode > 1 || pPortability->speed > PORT_SPEED_1000M || pPortability->duplex >= PORT_DUPLEX_END ||
           pPortability->link >= PORT_LINKSTATUS_END || pPortability->nway > 1 || pPortability->txpause > 1 || pPortability->rxpause > 1)
            return RT_ERR_INPUT;
    }

    ext_id = port - 15;

    if(mode == MODE_EXT_DISABLE)
    {
        memset(&ability, 0x00, sizeof(rtl8367c_port_ability_t));
        if ((retVal = rtl8367c_setAsicPortForceLinkExt(ext_id, &ability)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_setAsicPortExtMode(ext_id, mode)) != RT_ERR_OK)
            return retVal;
    }
    else
    {
        if ((retVal = rtl8367c_setAsicPortExtMode(ext_id, mode)) != RT_ERR_OK)
            return retVal;

        if ((retVal = rtl8367c_getAsicPortForceLinkExt(ext_id, &ability)) != RT_ERR_OK)
            return retVal;

        ability.forcemode = pPortability->forcemode;
        ability.speed     = (mode == MODE_EXT_HSGMII) ? PORT_SPEED_1000M : pPortability->speed;
        ability.duplex    = pPortability->duplex;
        ability.link      = pPortability->link;
        ability.nway      = pPortability->nway;
        ability.txpause   = pPortability->txpause;
        ability.rxpause   = pPortability->rxpause;

        if ((retVal = rtl8367c_setAsicPortForceLinkExt(ext_id, &ability)) != RT_ERR_OK)
            return retVal;
    }

    return RT_ERR_OK;
}
#endif

#if 0 /* For Debug: sgmii_speed_read_proc */
static rtk_api_ret_t _rtk_port_macForceLinkExt_get(rtk_port_t port, rtk_mode_ext_t *pMode, rtk_port_mac_ability_t *pPortability)
{
    rtk_api_ret_t retVal;
    rtl8367c_port_ability_t ability;
    rtk_uint32 ext_id;

    if(NULL == pMode)
        return RT_ERR_NULL_POINTER;

    if(NULL == pPortability)
        return RT_ERR_NULL_POINTER;

    ext_id = port - 15;

    if ((retVal = rtl8367c_getAsicPortExtMode(ext_id, (rtk_uint32 *)pMode)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_getAsicPortForceLinkExt(ext_id, &ability)) != RT_ERR_OK)
        return retVal;

    pPortability->forcemode = ability.forcemode;
    pPortability->speed     = (*pMode == MODE_EXT_HSGMII) ? PORT_SPEED_2500M : ability.speed;
    pPortability->duplex    = ability.duplex;
    pPortability->link      = ability.link;
    pPortability->nway      = ability.nway;
    pPortability->txpause   = ability.txpause;
    pPortability->rxpause   = ability.rxpause;

    return RT_ERR_OK;
        
}
#endif

rtk_api_ret_t rt_rtl8367_enableSgmii(rtk_port_t port, rtk_mode_ext_t mode, rtk_port_mac_ability_t *pPortability)
{
    rtk_api_ret_t retVal;
    rtl8367c_port_ability_t ability;
    rtk_uint32 ext_id;

    ext_id = port - 15;

    if ((retVal = rtl8367c_setAsicPortExtMode(ext_id, mode)) != RT_ERR_OK)
        return retVal;

    if ((retVal = rtl8367c_getAsicPortForceLinkExt(ext_id, &ability)) != RT_ERR_OK)
        return retVal;

    ability.forcemode = pPortability->forcemode;
    ability.speed     = (mode == MODE_EXT_HSGMII) ? PORT_SPEED_1000M : pPortability->speed;
    ability.duplex    = pPortability->duplex;
    ability.link      = pPortability->link;
    ability.nway      = pPortability->nway;
    ability.txpause   = pPortability->txpause;
    ability.rxpause   = pPortability->rxpause;

    if ((retVal = rtl8367c_setAsicPortForceLinkExt(ext_id, &ability)) != RT_ERR_OK)
        return retVal;

    return RT_ERR_OK;
        
}

#if 0 /* For Debug: sgmii_status_read_proc */
/* Function Name:
 *      rtl8367c_getSdsLinkStatus
 * Description:
 *      Get SGMII status
 * Input:
 *      id  - EXT ID
 * Output:
 *      None.
 * Return:
 *      RT_ERR_OK                   - Success
 *      RT_ERR_SMI                  - SMI access error
 * Note:
 *      None.
 */
ret_t rtl8367c_getSdsLinkStatus(rtk_uint32 ext_id, rtk_uint32 *pSignalDetect, rtk_uint32 *pSync, rtk_uint32 *pLink)
{
    rtk_uint32 retVal, regValue, type, running = 0, retVal2;


    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0249)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_getAsicReg(0x1300, &regValue)) != RT_ERR_OK)
        return retVal;

    if((retVal = rtl8367c_setAsicReg(0x13C2, 0x0000)) != RT_ERR_OK)
        return retVal;

    switch (regValue)
    {
        case 0x0276:
        case 0x0597:
        case 0x6367:
            type = 0;
            break;
        case 0x0652:
        case 0x6368:
            type = 1;
            break;
        case 0x0801:
        case 0x6511:
            type = 2;
            break;
        default:
            return RT_ERR_FAILED;
    }

    if(type == 0)
    {
        if (1 == ext_id)
        {
            if ((retVal = rtl8367c_getAsicRegBit(0x130c, 5, &running))!=RT_ERR_OK)
                return retVal;

            if(running == 1)
            {
                if ((retVal = rtl8367c_setAsicRegBit(0x130c, 5, 0))!=RT_ERR_OK)
                    return retVal;
            }

            retVal = rtl8367c_setAsicReg(0x6601, 0x003D);

            if(retVal == RT_ERR_OK)
                retVal = rtl8367c_setAsicReg(0x6600, 0x0080);

            if(retVal == RT_ERR_OK)
                retVal = rtl8367c_getAsicReg(0x6602, &regValue);

            if(running == 1)
            {
                if ((retVal2 = rtl8367c_setAsicRegBit(0x130c, 5, 1))!=RT_ERR_OK)
                    return retVal2;
            }

            if(retVal != RT_ERR_OK)
                return retVal;

            *pSignalDetect = (regValue & 0x0100) ? 1 : 0;
            *pSync = (regValue & 0x0001) ? 1 : 0;
            *pLink = (regValue & 0x0010) ? 1 : 0;
        }
        else
            return RT_ERR_PORT_ID;
    }
    else if(type == 1)
    {
        if (1 == ext_id)
        {
            if ((retVal = rtl8367c_setAsicReg(0x6601, 0x003D))!=RT_ERR_OK)
                return retVal;
            if ((retVal = rtl8367c_setAsicReg(0x6600, 0x0081))!=RT_ERR_OK)
                return retVal;
            if ((retVal = rtl8367c_getAsicReg(0x6602, &regValue))!=RT_ERR_OK)
                return retVal;

            *pSignalDetect = (regValue & 0x0100) ? 1 : 0;
            *pSync = (regValue & 0x0001) ? 1 : 0;
            *pLink = (regValue & 0x0010) ? 1 : 0;
        }
        else if (2 == ext_id)
        {
            if ((retVal = rtl8367c_setAsicReg(0x6601, 0x003D))!=RT_ERR_OK)
                return retVal;
            if ((retVal = rtl8367c_setAsicReg(0x6600, 0x0080))!=RT_ERR_OK)
                return retVal;
            if ((retVal = rtl8367c_getAsicReg(0x6602, &regValue))!=RT_ERR_OK)
                return retVal;

            *pSignalDetect = (regValue & 0x0100) ? 1 : 0;
            *pSync = (regValue & 0x0001) ? 1 : 0;
            *pLink = (regValue & 0x0010) ? 1 : 0;
        }
        else
            return RT_ERR_PORT_ID;
    }
    else if(type == 2)
    {
        if((retVal = rtl8367c_getAsicSdsReg(0, 30, 1, &regValue)) != RT_ERR_OK)
            return retVal;
        if((retVal = rtl8367c_getAsicSdsReg(0, 30, 1, &regValue)) != RT_ERR_OK)
            return retVal;

        *pSignalDetect = (regValue & 0x0100) ? 1 : 0;
        *pSync = (regValue & 0x0001) ? 1 : 0;
        *pLink = (regValue & 0x0010) ? 1 : 0;

    }

    return RT_ERR_OK;
}
#endif

#if 0 /* For Debug: sgmii_status_read_proc */
static rtk_api_ret_t _rtk_port_sgmiiLinkStatus_get(rtk_port_t port, rtk_data_t *pSignalDetect, rtk_data_t *pSync, rtk_port_linkStatus_t *pLink)
{
    rtk_uint32 ext_id;

    /* Check initialization state */
    RTK_CHK_INIT_STATE();

    /* Check Port Valid */
    if(rtk_switch_isSgmiiPort(port) != RT_ERR_OK)
        return RT_ERR_PORT_ID;

    if(NULL == pSignalDetect)
        return RT_ERR_NULL_POINTER;

    if(NULL == pSync)
        return RT_ERR_NULL_POINTER;

    if(NULL == pLink)
        return RT_ERR_NULL_POINTER;

    ext_id = port - 15;
    return rtl8367c_getSdsLinkStatus(ext_id, (rtk_uint32 *)pSignalDetect, (rtk_uint32 *)pSync, (rtk_uint32 *)pLink);
}
#endif
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */


void rt_rtl8367_stat_port_save(u32 port)
{
#if 0
	/* address offset to MIBs counter */
	const u16 mibLength[RTL8367B_MIBS_NUMBER]= {
		4,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
		4,2,2,2,2,2,2,2,2,
		4,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
		2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2};

	u32 mibAddr;
	u32 mibOff=0;
	u32 index = 0;
	u32 regData = 0;
	u32 mibCounterIn = 0;
	u32 mibCounterOut = 0;
	u32 regAddr = 0;

	if (port > 7)
	{
		return;
	}

	/* ifInOctets */

	index = 0;
	mibOff = RTL8367C_MIB_PORT_OFFSET * port;

	while(index < ifInOctets)
	{
		mibOff += mibLength[index];
		index++;
	}
	/*RTL8367_DEBUG("mibOff is 0x%x\n", mibOff);*/
	
	mibAddr = mibOff;

	/*RTL8367_DEBUG("Write 0x%x to 0x%x\n", (mibAddr >> 2), RTL8367B_REG_MIB_ADDRESS);*/

	rtl_smi_write(RTL8367C_REG_MIB_ADDRESS, (mibAddr >> 2));

	 /* polling busy flag */
    index = 100;
    while (index > 0)
    {
        /*read MIB control register*/
        rtl_smi_read(RTL8367C_MIB_CTRL_REG,&regData);
    
        if ((regData & 0x1) == 0)
        {
            break;
        }
    
        index--;
    }
	if (regData & 0x1)
	{
		RTL8367_DEBUG("MIB BUSYWAIT_TIMEOUT\n");
		return ;
	}
	if (regData & 0x2)
	{
		RTL8367_DEBUG("MIB STAT_CNTR_FAIL\n");
		return ;
	}

	
#if 0
	index = mibLength[ifInOctets];
	if(4 == index)
		regAddr = RTL8367B_REG_MIB_COUNTER0 + 3;
	else
		regAddr = RTL8367B_REG_MIB_COUNTER0 + ((mibOff + 1) % 4);

	regData = 0;
	mibCounterIn = 0;
	while(index)
	{
		rtl_smi_read(regAddr, &regData);
		RTL8367_DEBUG("Read from 0x%x is 0x%x \n", regAddr, regData);
		mibCounterIn = (mibCounterIn << 16) | (regData & 0xFFFF);
		/*RTL8367_DEBUG("mibCounterIn 0x%x \n", mibCounterIn);*/

		regAddr--;
		index--;
	}
#else
	mibCounterIn = 0;

	rtl_smi_read(RTL8367C_REG_MIB_COUNTER0 + 1, &regData);
	mibCounterIn = (regData & 0xFFFF);

	rtl_smi_read(RTL8367C_REG_MIB_COUNTER0, &regData);
	mibCounterIn = (mibCounterIn << 16) | (regData & 0xFFFF);

#endif
	/* ifOutOctets */

	index = 0;
	mibOff = RTL8367C_MIB_PORT_OFFSET * port;

	while(index < ifOutOctets)/*ifInOctets*/
	{
		mibOff += mibLength[index];
		index++;
	}		
	/*RTL8367_DEBUG("mibOff is 0x%x\n", mibOff);*/
	
	mibAddr = mibOff;

	/*RTL8367_DEBUG("Write 0x%x to 0x%x\n", (mibAddr >> 2), RTL8367B_REG_MIB_ADDRESS);*/

	rtl_smi_write(RTL8367C_REG_MIB_ADDRESS, (mibAddr >> 2));

	 /* polling busy flag */
    index = 100;
    while (index > 0)
    {
        /*read MIB control register*/
        rtl_smi_read(RTL8367C_MIB_CTRL_REG, &regData);
    
        if ((regData & 0x1) == 0)
        {
            break;
        }
    
        index--;
    }
	if (regData & 0x1)
	{
		RTL8367_DEBUG("MIB BUSYWAIT_TIMEOUT\n");
		return ;
	}
	if (regData & 0x2)
	{
		RTL8367_DEBUG("MIB STAT_CNTR_FAIL\n");
		return ;
	}

	
#if 0
	index = mibLength[ifOutOctets];
	if(4 == index)
		regAddr = RTL8367B_REG_MIB_COUNTER0 + 3;
	else
		regAddr = RTL8367B_REG_MIB_COUNTER0 + ((mibOff + 1) % 4);

	regData = 0;
	mibCounterOut = 0;
	while(index)
	{
		rtl_smi_read(regAddr, &regData);
		RTL8367_DEBUG("Read from 0x%x is 0x%x \n", regAddr, regData);

		mibCounterOut = (mibCounterOut << 16) | (regData & 0xFFFF);
		/*RTL8367_DEBUG("mibCounterOut 0x%x \n", mibCounterOut);*/

		regAddr--;
		index--;
	}
#else
		mibCounterOut = 0;
	
		rtl_smi_read(RTL8367C_REG_MIB_COUNTER0 + 1, &regData);
		mibCounterOut = (regData & 0xFFFF);
	
		rtl_smi_read(RTL8367C_REG_MIB_COUNTER0, &regData);
		mibCounterOut = (mibCounterOut << 16) | (regData & 0xFFFF);
	
#endif

	printf("Port %02d\t", port);
	printf("IN:0x%08x\tOUT:0x%08x\n", mibCounterIn, mibCounterOut);
#endif
	
}
void rt_rtl8367_stat(u32 port)
{
	u32 index;
	printf("==============================\n");
	printf("Port Stat:\n");
	if (port <= 7)
	{
		rt_rtl8367_stat_port_save(port);
		printf("==============================\n");
		return;
	}

	for (index = 0; index <= 7; index++)
	{
		rt_rtl8367_stat_port_save(index);
	}
	printf("==============================\n");
	return;

	
}

int isEthForwardEnable()
{
	int index = 0;
	/* RTL8367C_REG_PORT_ISOLATION_PORT0_MASK | RTL8367D_REG_PORT_ISOLATION_PORT0_MASK */
	u32 portIsolationCtrlReg = 0x08a2;
	u32 data = 0;
	int isEnable = 1;
	
	for (index = 0; index < 8; index++)
	{
		if(RT_MAPPER->smi_read(portIsolationCtrlReg + index, &data))
		{
			RTL8367_ERROR("rtl_smi_read fail\r\n", portIsolationCtrlReg + index);
		}
		RTL8367_DEBUG("port %d is 0x%x\n", index, data);
		if (data != 0xff)
		{
			isEnable = 0;
		}
	}

	return isEnable;
}

int isEthForwardDisable()
{
	int index = 0;
	/* RTL8367C_REG_PORT_ISOLATION_PORT0_MASK | RTL8367D_REG_PORT_ISOLATION_PORT0_MASK */
	u32 portIsolationCtrlReg = 0x08a2;
	u32 data = 0;
	int isDisable = 1;
	
	for (index = 0; index < 8; index++)
	{
		if(RT_MAPPER->smi_read(portIsolationCtrlReg + index, &data))
		{
			RTL8367_ERROR("rtl_smi_read fail 0x%x\r\n", portIsolationCtrlReg + index);
		}
		RTL8367_DEBUG("port %d is 0x%x\n", index, data);
		if (data != 0x00)
		{
			isDisable = 0;
		}
	}

	return isDisable;
}

rtk_api_ret_t enableEthForward()
{
	rtk_api_ret_t ret;
	int index = 0;
	/* RTL8367C_REG_PORT_ISOLATION_PORT0_MASK | RTL8367D_REG_PORT_ISOLATION_PORT0_MASK */
	u32 portIsolationCtrlReg = 0x08a2;

	for (index = 0; index < 8; index++)
	{
		if(RT_MAPPER->smi_write(portIsolationCtrlReg + index, 0xff))
		{
			RTL8367_ERROR("rtl_smi_write fail 0x%x\r\n", portIsolationCtrlReg + index);
		}
	}

	if(!isEthForwardEnable())
	{
		RTL8367_DEBUG("enable switch forward... fail\n");
	}
	else
	{
		RTL8367_DEBUG("enable switch forward... ok\n");
	}
	
	return RT_ERR_OK;
}

rtk_api_ret_t disableEthForward()
{
	rtk_api_ret_t ret;
	int index = 0;
	/*RTL8367C_REG_PORT_ISOLATION_PORT0_MASK | RTL8367D_REG_PORT_ISOLATION_PORT0_MASK*/
	u32 portIsolationCtrlReg = 0x08a2; 

	for (index = 0; index < 8; index++)
	{
		if(RT_MAPPER->smi_write(portIsolationCtrlReg + index, 0x0))
		{
			RTL8367_ERROR("rtl_smi_write fail 0x%x\r\n", portIsolationCtrlReg + index);
		}
	}

	if(!isEthForwardDisable())
	{
		RTL8367_DEBUG("disable switch forward... fail\n");
	}
	else
	{
		RTL8367_DEBUG("disable switch forward... ok\n");
	}

	return RT_ERR_OK;
}


rtk_api_ret_t resetPHY()
{
	rtk_api_ret_t ret;
	int index = 0;
	u32 phyRegBase = 0;
	u32 data = 0;

#if 0/* do nothing temporarily.  */
	phyRegBase = 0x2000;
	for (index = 0; index < 5; index++)
	{
		rtl_smi_read(phyRegBase + 0x20 * index, &data);
		RTL8367_DEBUG("port %d 0x%x is 0x%x\n", index, phyRegBase + 0x20 * index, data);
		data |= 0x1 << 15;
		rtl_smi_write(phyRegBase + 0x20 * index, data);
		RTL8367_DEBUG("set port %d 0x%x with 0x%x\n", index, phyRegBase + 0x20 * index, data);
	}
#endif

	return RT_ERR_OK;
}


void IsSwitchVlanTableBusy()
{
	int j = 0;
	unsigned int value = 0;

	for (j = 0; j < 20; j++) {
			/* RALINK */
            value = *(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90); //VTCR
	    if ((value & 0x80000000) == 0 ){ //table busy
		break;
	    }
	    udelay(1000);
	}
	if (j == 20)
	    RTL8367_DEBUG("set vlan timeout.\n");
}

void vlanDump()
{
	u32 reck[] = {0x2004,0x2104,0x2204,0x2304,0x2404,0x2504,0x2604,0x2704,
				0x2010,0x2110,0x2210,0x2310,0x2410,0x2510,0x2610,0x2710,
				0x2014,0x2114,0x2214,0x2314,0x2414,0x2514,0x2614,0x2714,
				0x94,0x90,0x100};
	u32 swReg;
	u8 index = 0;
	for (index = 0; index < 27; index++)
	{
		swReg = RALINK_ETH_SW_BASE + reck[index];
		RTL8367_DEBUG("switch reg 0x%x : 0x%08x\n", reck[index], *(volatile unsigned long *)(swReg));
	}
}

rtk_api_ret_t setVlanRtl8367()
{
#if 1
	rtk_port_t portIndex;
	rtk_vlan_t portVID = 0;
	rtk_api_ret_t ret;

	rtk_vlan_cfg_t vlanCfg;

	/* add lan vlan */
	memset(&vlanCfg, 0x0, sizeof(rtk_vlan_cfg_t));
#if defined(CONFIG_TP_MODEL_C5V4)
    vlanCfg.mbr.bits[0] = ((1<<UTP_PORT0) | (1<<UTP_PORT1) | (1<<UTP_PORT2) | (1<<UTP_PORT3) | (1<<EXT_PORT1) ); 
    vlanCfg.untag.bits[0] = ((1<<UTP_PORT0) | (1<<UTP_PORT1) | (1<<UTP_PORT2) | (1<<UTP_PORT3)) ;
#else
    /* EC220_G5V2 | EC220_G5sV1 */    
	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT0) | (1<<UTP_PORT1) | (1<<UTP_PORT2) | (1<<EXT_PORT1) );
	vlanCfg.untag.bits[0] = ((1<<UTP_PORT0) | (1<<UTP_PORT1) | (1<<UTP_PORT2)) ;
#endif
	vlanCfg.ivl_en = ENABLED;
	if ((ret = rtk_vlan_set(LAN_VLAN_ID, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set LAN VLAN error: 0x%08x...\n", ret);
		return ret;
	}
	
	/* add wan vlan */
	memset(&vlanCfg, 0x0, sizeof(rtk_vlan_cfg_t));
#if defined(CONFIG_TP_MODEL_C5V4)
	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT4) | (1<<EXT_PORT1) ); 
	vlanCfg.untag.bits[0] = (1<<UTP_PORT4) ;
#elif defined(CONFIG_TP_MODEL_EC220_G5sV1)
    vlanCfg.mbr.bits[0] = ((1<<UTP_PORT3) | (1<<EXT_PORT0) | (1<<EXT_PORT1) );
    vlanCfg.untag.bits[0] = ((1<<UTP_PORT3) | (1<<EXT_PORT0));
#else
    /* EC220_G5V2 */
 	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT3) | (1<<EXT_PORT1) ); 
	vlanCfg.untag.bits[0] = ((1<<UTP_PORT3) );
#endif
   
	vlanCfg.ivl_en = ENABLED;
	
	if ((ret = rtk_vlan_set(WAN_VLAN_ID, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set WAN VLAN error: 0x%08x...\n", ret);
		return ret;
	}

	/* set pvid */
#if defined(CONFIG_TP_MODEL_C5V4)
	for (portIndex = UTP_PORT0; portIndex <= UTP_PORT4; portIndex++)
	{
		if(portIndex == UTP_PORT4)
#else
	for (portIndex = UTP_PORT0; portIndex <= UTP_PORT3; portIndex++) /* EC220_G5V2 */
	{
		if(portIndex == UTP_PORT3)  /* EC220_G5V2 */
#endif
		{
			portVID = WAN_VLAN_PVID;
		}
		else
		{
			portVID = LAN_VLAN_PVID;
		}
		
		if ((ret = rtk_vlan_portPvid_set(portIndex, portVID, 0)) != RT_ERR_OK)
		{
			RTL8367_ERROR("set port %d PVID error: 0x%08x...\n", portIndex, ret);
			return ret;
		}
	}

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    /*
     * Set Pvid of SGMII(EXT_PORT0)
    */
    {
        if ((ret = rtk_vlan_portPvid_set(EXT_PORT0, WAN_VLAN_PVID, 0)) != RT_ERR_OK)
		{
			RTL8367_ERROR("set EXT_PORT0 PVID error: 0x%08x...\n", ret);
			return ret;
		}

    }
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */
#else
	rtk_port_t portIndex;
	rtk_vlan_t portVID = 0;
	rtk_api_ret_t ret;

	rtk_vlan_cfg_t vlanCfg;

	/* add lan vlan */
	memset(&vlanCfg, 0x0, sizeof(rtk_vlan_cfg_t));
	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT0) | (1<<EXT_PORT1) ); 
	vlanCfg.untag.bits[0] = ((1<<UTP_PORT0)) ;
	vlanCfg.ivl_en = ENABLED;
	if ((ret = rtk_vlan_set(3, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set LAN VLAN error: 0x%08x...\n", ret);
		return ret;
	}
	
	memset(&vlanCfg, 0x0, sizeof(rtk_vlan_cfg_t));
	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT1) | (1<<EXT_PORT1) ); 
	vlanCfg.untag.bits[0] = ((1<<UTP_PORT1)) ;
	vlanCfg.ivl_en = ENABLED;
	if ((ret = rtk_vlan_set(4, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set LAN VLAN error: 0x%08x...\n", ret);
		return ret;
	}
	
	memset(&vlanCfg, 0x0, sizeof(rtk_vlan_cfg_t));
	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT2) | (1<<EXT_PORT1) ); 
	vlanCfg.untag.bits[0] = ((1<<UTP_PORT2)) ;
	vlanCfg.ivl_en = ENABLED;
	if ((ret = rtk_vlan_set(5, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set LAN VLAN error: 0x%08x...\n", ret);
		return ret;
	}

	memset(&vlanCfg, 0x0, sizeof(rtk_vlan_cfg_t));
	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT3) | (1<<EXT_PORT1) ); 
	vlanCfg.untag.bits[0] = ((1<<UTP_PORT3)) ;
	vlanCfg.ivl_en = ENABLED;
	if ((ret = rtk_vlan_set(6, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set LAN VLAN error: 0x%08x...\n", ret);
		return ret;
	}
	
	/* add wan vlan */
	memset(&vlanCfg, 0x0, sizeof(rtk_vlan_cfg_t));
	vlanCfg.mbr.bits[0] = ((1<<UTP_PORT4) | (1<<EXT_PORT1) ); 
	vlanCfg.untag.bits[0] = (1<<UTP_PORT4) ;
	vlanCfg.ivl_en = ENABLED;
	
	if ((ret = rtk_vlan_set(WAN_VLAN_ID, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set WAN VLAN error: 0x%08x...\n", ret);
		return ret;
	}

	/* set pvid */
#if defined(CONFIG_TP_MODEL_C5V4)
	for (portIndex = UTP_PORT0; portIndex <= UTP_PORT4; portIndex++)
#else
	for (portIndex = UTP_PORT0; portIndex <= UTP_PORT3; portIndex++)
#endif 
	{
		if(portIndex== UTP_PORT0)
		{
			portVID = 3;
		}
		else if(portIndex == UTP_PORT1)
		{
			portVID = 4;
		}
		else if(portIndex == UTP_PORT2)
		{
			portVID = 5;
		}
		else if(portIndex == UTP_PORT3)
		{
			portVID = 6;
		}
		else if(portIndex == UTP_PORT4)
		{
			portVID = 2;
		}
		else
		{
			continue;
		}
		
		if ((ret = rtk_vlan_portPvid_set(portIndex, portVID, 0)) != RT_ERR_OK)
		{
			RTL8367_ERROR("set port %d PVID error: 0x%08x...\n", portIndex, ret);
			return ret;
		}
	}
#endif
	return RT_ERR_OK;
}

rtk_api_ret_t setVlanInner()
{
#if 1
	/*PCR: Port Control Rgister */
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2504) = ((2<<28) | (0xff<<16) | (1<<0)); //port5, egress tagged, fallback mode
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2604) = ((2<<28) | (0xff<<16) | (1<<0)); //port6, egress tagged, fallback mode
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2704) = ((2<<28) | (0xff<<16) | (1<<0)); //port7, egress tagged, fallback mode

	/*PVC: Port VLAN Control*/
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2510) = ((0x8100<<16) | (0<<6)); //port5, user port
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2610) = ((0x8100<<16) | (0<<6)); //port6, user port
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2710) = ((0x8100<<16) | (0<<6)); //port7, user port

	//PPBV1: Port-and-Protocol Based VLAN
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2514) = ((1<<16) | (1<<0)); //port5, PVID=1
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2614) = ((1<<16) | (1<<0)); //port6, PVID=1
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2714) = ((1<<16) | (1<<0)); //port7, PVID=1

	//VLAN member
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100) = ((3<<12)|(2<<0)); //VID0->VLAN 2, VID1->VLAN 3

	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = ((1<<30) | \
		(1<<23) |(1<<22) |(1<<21) |(0<<20) |(0<<19) |(0<<18) |(0<<17) |(0<<16) \
		|(1<<0)); //VAWD1, VLAN member= port7, port6, port5
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = ((1<<31) | (1<<12)|(0<<0)); //VTCR, VID0->VLAN 2
	IsSwitchVlanTableBusy();

	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = ((1<<30) | \
		(1<<23) |(1<<22) |(1<<21) |(0<<20) |(0<<19) |(0<<18) |(0<<17) |(0<<16) \
		|(1<<0)); //VAWD1, VLAN member= port7, port6, port5
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = ((1<<31) | (1<<12)|(1<<0)); //VTCR, VID1->VLAN 3
	IsSwitchVlanTableBusy();
#else
	/*PCR: Port Control Rgister */
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2504) = ((2<<28) | (0xff<<16) | (1<<0)); //port5, egress tagged, fallback mode
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2604) = ((2<<28) | (0xff<<16) | (1<<0)); //port6, egress tagged, fallback mode
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2704) = ((2<<28) | (0xff<<16) | (1<<0)); //port7, egress tagged, fallback mode

	/*PVC: Port VLAN Control*/
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2510) = ((0x8100<<16) | (0<<6)); //port5, user port
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2610) = ((0x8100<<16) | (0<<6)); //port6, user port
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2710) = ((0x8100<<16) | (0<<6)); //port7, user port

	//PPBV1: Port-and-Protocol Based VLAN
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2514) = ((1<<16) | (1<<0)); //port5, PVID=1
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2614) = ((1<<16) | (1<<0)); //port6, PVID=1
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2714) = ((1<<16) | (1<<0)); //port7, PVID=1

	//VLAN member
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100) = ((4<<12)|(3<<0)); //VID0->VLAN 3, VID1->VLAN 4
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x104) = ((6<<12)|(5<<0)); //VID2->VLAN 5, VID3->VLAN 6
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x108) = ((6<<12)|(2<<0)); //VID4->VLAN 2, VID5->VLAN 6
	
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = ((1<<30) | \
		(1<<23) |(1<<22) |(1<<21) |(0<<20) |(0<<19) |(0<<18) |(0<<17) |(0<<16) \
		|(1<<0)); //VAWD1, VLAN member= port7, port6, port5
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = ((1<<31) | (1<<12)|(0<<0)); //VTCR, VID0->VLAN 3
	IsSwitchVlanTableBusy();

	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = ((1<<30) | \
		(1<<23) |(1<<22) |(1<<21) |(0<<20) |(0<<19) |(0<<18) |(0<<17) |(0<<16) \
		|(1<<0)); //VAWD1, VLAN member= port7, port6, port5
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = ((1<<31) | (1<<12)|(1<<0)); //VTCR, VID1->VLAN 4
	IsSwitchVlanTableBusy();
	
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = ((1<<30) | \
		(1<<23) |(1<<22) |(1<<21) |(0<<20) |(0<<19) |(0<<18) |(0<<17) |(0<<16) \
		|(1<<0)); //VAWD1, VLAN member= port7, port6, port5
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = ((1<<31) | (1<<12)|(2<<0)); //VTCR, VID2->VLAN 5
	IsSwitchVlanTableBusy();

	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = ((1<<30) | \
		(1<<23) |(1<<22) |(1<<21) |(0<<20) |(0<<19) |(0<<18) |(0<<17) |(0<<16) \
		|(1<<0)); //VAWD1, VLAN member= port7, port6, port5
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = ((1<<31) | (1<<12)|(3<<0)); //VTCR, VID3->VLAN 6
	IsSwitchVlanTableBusy();

	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = ((1<<30) | \
		(1<<23) |(1<<22) |(1<<21) |(0<<20) |(0<<19) |(0<<18) |(0<<17) |(0<<16) \
		|(1<<0)); //VAWD1, VLAN member= port7, port6, port5
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = ((1<<31) | (1<<12)|(4<<0)); //VTCR, VID4->VLAN 2
	IsSwitchVlanTableBusy();
#endif
	return RT_ERR_OK;
}
rtk_api_ret_t ipMcastRuleSet(struct rtl8367IpMcastRule ipMcastRule, ipMcastRuleType ruleType)
{
#if 0
	rtk_l2_ucastAddr_t l2_entry;
	rtk_l2_ipMcastAddr_t IpMcastAddr;
	rtk_api_ret_t ret;
#ifdef CONFIG_X_TP_VLAN
	rtk_uint8 index = 0;
	rtk_uint32 vlanID[16] = {LAN_VLAN_ID, 3, 4, 5, 6, 8};/* add for multi-VLAN as LAN */
#endif
	
	l2_entry.ivl = 1;
#ifndef CONFIG_X_TP_VLAN
	l2_entry.cvid = LAN_VLAN_ID;
#endif
	l2_entry.fid = 0;
	l2_entry.efid = 0;

	if (ruleType > PORT_END)
	{
		return RT_ERR_FAILED;
	}
#ifdef CONFIG_X_TP_VLAN
	for (index  = 0; vlanID[index] != '\0'; index++)
	{
		l2_entry.cvid = vlanID[index];
		
		if ((ret = rtk_l2_addr_get(&(ipMcastRule.mac), &l2_entry)) != RT_ERR_OK)
		{
			if (ret != RT_ERR_L2_ENTRY_NOTFOUND)
			{
				RTL8367_ERROR("get L2 addr in VLAN %d error: 0x%08x...\n", vlanID[index], ret);
			}
		}
		else
		{
			break;
		}
	}

	if (ret == RT_ERR_L2_ENTRY_NOTFOUND)
	{
		return RT_ERR_OK;
	}
#else
	if ((ret = rtk_l2_addr_get(&(ipMcastRule.mac), &l2_entry)) != RT_ERR_OK)
	{
		RTL8367_ERROR("get L2 addr error: 0x%08x...\n", ret);
		return ret;
	}
#endif
	IpMcastAddr.dip = ipMcastRule.ip_addr;
	if ((ret = rtk_l2_ipMcastAddr_get(&IpMcastAddr)) != RT_ERR_OK)
	{
		if (ret == RT_ERR_L2_ENTRY_NOTFOUND)
		{
			IpMcastAddr.portmask.bits[0] = 0;
		}
		else
		{
			RTL8367_ERROR("get ipMcastAddr error: 0x%08x...\n", ret);
			return ret;
		}
	}
	
	if (ruleType == PORT_ADD)
	{
		IpMcastAddr.portmask.bits[0] |= (1 << 7) | (1 << l2_entry.port);
	}
	else if (ruleType == PORT_DEL)
	{
		IpMcastAddr.portmask.bits[0] &= ~(1 << l2_entry.port);
	}
	
	if ((ret = rtk_l2_ipMcastAddr_del(&IpMcastAddr)) != RT_ERR_OK)
	{
		if (ret != RT_ERR_L2_ENTRY_NOTFOUND)
		{
			RTL8367_ERROR("del ipMcastAddr error: 0x%08x...\n", ret);
			return ret;
		}
	}
	
	if ((IpMcastAddr.portmask.bits[0] & 0x1F) == 0)
	{
		RTL8367_DEBUG("delete this entry...\n");
		return RT_ERR_OK;
	}
	
	if ((ret = rtk_l2_ipMcastAddr_add(&IpMcastAddr)) != RT_ERR_OK)
	{
		RTL8367_ERROR("add ipMcastAddr error: 0x%08x...\n", ret);
		return ret;
	}
	
	if ((ret =rtk_l2_ipMcastAddrLookup_set(LOOKUP_IP)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set lookup table error: 0x%08x...\n", ret);
		return ret;
	}
#endif
	return RT_ERR_OK;
}


#ifdef CONFIG_X_TP_VLAN
/* vlan operation interface, add by wanghao  */
rtk_api_ret_t MT7620ClearVlanConfig()
{
	u8 index = 0;
	rtk_uint32 vlanTableIndexReg = 0;
	
	vlanTableIndex = 0x0;
	
	for (index = 0; index < 16; index++)
	{
		if (!(index % 2))
		{
			vlanTableIndexReg = index << 1;
			*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) &= ~0xFFF;//VTIM
			*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) |= 0x1;//VTIM
		}
		else
		{
			vlanTableIndexReg = (index - 1) << 1;
			*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) &= ~(0xFFF << 12);//VTIM
			*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) |= 0x1 << 12;//VTIM
		}
	
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = 0x40000001; //VAWD1		0000,0000
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = 0x80001000 + index; //VTCR
		IsSwitchVlanTableBusy();
	}
	
	return RT_ERR_OK;
}

rtk_api_ret_t MT7620AddVlan(struct vlanInfo vlan, rtk_uint32 portMap)
{
	rtk_uint32 vlanWrData1RegVal = 0x40000001;
	rtk_uint32 vlanTableCtlRegVal = 0x80001000;
	rtk_uint32 vlanTableIndexReg = 0;

	if (!(vlanTableIndex % 2))
	{
		vlanTableIndexReg = vlanTableIndex << 1;
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) &= ~0xFFF;//VTIM
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) |= vlan.vid;//VTIM
	}
	else
	{
		vlanTableIndexReg = (vlanTableIndex - 1) << 1;
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) &= ~(0xFFF << 12);//VTIM
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x100 + vlanTableIndexReg) |= vlan.vid << 12;//VTIM
	}
	RTL8367_DEBUG("MT7620AddVlan index=%d, vid=%d, ", vlanTableIndex, vlan.vid);
	
	if (vlan.vlanPurpose < LAN_END)/* LAN VLAN  */
	{
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = vlanWrData1RegVal + (portMap << 16); //VAWD1
		RTL8367_DEBUG("mbr=%x\r\n", portMap);

		udelay(5000);
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = vlanTableCtlRegVal + vlanTableIndex;//vlan.vid - 1;//VTCR
	}
	else/* WAN VLAN  */
	{
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x94) = vlanWrData1RegVal + (portMap << 16); //VAWD1
		RTL8367_DEBUG("mbr=%x\r\n", portMap);

		udelay(5000);
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x90) = vlanTableCtlRegVal + vlanTableIndex;//VTCR
	}
	vlanTableIndex++;
	IsSwitchVlanTableBusy();

	return RT_ERR_OK;
}

rtk_api_ret_t MT7620SetPort(rtk_uint32 port, MT7620PortType portType)
{
	rtk_uint32 vlanCtlReg = 0x2010;
	rtk_uint32 portCtlReg = 0x2004;
	rtk_api_ret_t ret = RT_ERR_OK;
	u32 data = 0;
	
	switch(portType)
	{
	case USER_PORT:
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE + vlanCtlReg + (port << 8)) = 0x81000000; 
		data = *(volatile unsigned long *)(RALINK_ETH_SW_BASE + portCtlReg + (port << 8));

		data &= ~(0x3 << 28);
		data &= ~(0xff << 16);
		data &= ~(0x3);
		
		data |= (0x2 << 28);
		data |= (0xff << 16); 
		data |= 0x1; /* fall back mode, hwnat needs it*/
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE + portCtlReg + (port << 8)) = data;//0x20ff0003; //Egress VLAN Tag Attribution=tagged
		RTL8367_DEBUG("MT7620SetPort port=%d, user port, tagged\r\n", port);
		
		break;
	case STACK_PORT:
		RTL8367_DEBUG("set port %d as stack port...\n", port);
		
		break;
	case TRANSLATION_PORT:
		RTL8367_DEBUG("set port %d as translation port...\n", port);
		
		break;
	case TRANSPARENT_PORT:
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE + vlanCtlReg + (port << 8)) = 0x810000c0; 
		data = *(volatile unsigned long *)(RALINK_ETH_SW_BASE + portCtlReg + (port << 8));

		data &= ~(0x3 << 28);
		data &= ~(0xff << 16);
		data &= ~(0x3);
		
		data |= (0xff << 16);
		data |= 0x1; /* fall back mode, hwnat needs it*/
		*(volatile unsigned long *)(RALINK_ETH_SW_BASE + portCtlReg + (port << 8)) = data;//0x00ff0003; //Egress VLAN Tag Attribution=untagged
		RTL8367_DEBUG("MT7620SetPort port=%d, transparent port, untagged\r\n", port);

		break;
	default:
		RTL8367_ERROR("unknown port type %d...\n", portType);
		ret = RT_ERR_INPUT;
		
		break;
	}

	return ret;
}

rtk_api_ret_t MT7620SetVlan(rtk_uint32 portUsed, struct vlanInfo * vlan)
{
	rtk_uint32 port = 0;
	rtk_uint32 index = 0;
	rtk_api_ret_t ret = RT_ERR_OK;
	rtk_uint32 portType = USER_PORT;

	for (index = 0; index < RTK_MAX_NUM_OF_PORT; index++)
	{
		port = portUsed & (1 << index);
		if (port)
		{
			/* for C20i, C20 & C50, port 1~5 should be treat as transparent port.
			*   for C2, all used ports are user ports.
			*/
			if ((ret = MT7620SetPort(index, portType)) != RT_ERR_OK)
			{
				RTL8367_ERROR("set MT7620 port %d error: 0x%08x...\n", index, ret);
				return ret;
			}
		}
	}

	for (index = 0; vlan[index].vid != '\0'; index++)
	{
		if (vlan[index].vlanPurpose == INTERNET_WAN)
		{
			if (hwNatWanVid)
			{
				*hwNatWanVid = vlan[index].vid;/* for HW nat and fast path  */
				wanVid = vlan[index].vid;
				RTL8367_DEBUG("set wan_vid %d for HW NAT...\n", *hwNatWanVid);
			}
			else
			{
				wanVid = vlan[index].vid;
				RTL8367_DEBUG("HWNAT is not enable, set wanVid %d...\n", wanVid);
			}
		}

		if ((ret = MT7620AddVlan(vlan[index], portUsed)) != RT_ERR_OK)
		{
			RTL8367_ERROR("add MT7620 VLAN %d portMap 0x%x error: 0x%08x...\n", vlan[index].vid, vlan[index].portMap, ret);
			return ret;
		}
	}

	return RT_ERR_OK;
}

rtk_api_ret_t RTL8367ClearVlanConfig()
{
	rtk_api_ret_t ret;
	rtk_uint32 address=0;
	rtk_l2_ucastAddr_t ucastAddr;
	rtk_l2_ipMcastAddr_t ipMcastAddr;

	if(CHIP_RTL8367D != g_switch_chip)
	{
		u8 index = 0;
		rtl8367c_vlanconfiguser vlanMC;
		for (index = 0; index <= RTL8367C_CVIDXMAX; index++)
		{
			vlanMC.evid = 0;
			vlanMC.mbr = 0;
			vlanMC.fid_msti = 0;
			vlanMC.envlanpol = 0;
			vlanMC.meteridx = 0;
			vlanMC.vbpen = 0;
			vlanMC.vbpri = 0;
			if ((ret = rtl8367c_setAsicVlanMemberConfig(index, &vlanMC)) != RT_ERR_OK)
		   	{
				RTL8367_ERROR("clear VLAN %d config error: 0x%08x...\n", index, ret);
				return ret;
			}
		}
	}

	/* flush unicast table */
	address=0;
	while(1)
	{
		if(RT_ERR_OK != rtk_l2_addr_next_get(READMETHOD_NEXT_L2UC, UTP_PORT0, &address, &ucastAddr))
		{
			break;
		}
		if(RT_ERR_OK != rtk_l2_addr_del(&ucastAddr.mac, &ucastAddr))
		{
			RTL8367_ERROR("rtk_l2_addr_del fail address=%d\r\n", address);
			address++;
		}
	}

	/* flush multicast table */
	address=0;
	while(1)
	{
		if(RT_ERR_OK != rtk_l2_ipMcastAddr_next_get(&address, &ipMcastAddr))
		{
			break;
		}

		ipMcastAddr.dip |= 0xe0000000;
		
		if(RT_ERR_OK != rtk_l2_ipMcastAddr_del(&ipMcastAddr))
		{
			RTL8367_ERROR("rtk_l2_ipMcastAddr_del fail address=%d\r\n", address);
			address++;
		}
	}

	return RT_ERR_OK;
}

rtk_api_ret_t RTL8367AddVlan(rtk_vlan_t vid, rtk_uint32 portMap, rtk_uint32 untag)
{
	rtk_api_ret_t ret;

	rtk_vlan_cfg_t vlanCfg;
	memset(&vlanCfg, 0x00, sizeof(rtk_vlan_cfg_t));

	vlanCfg.mbr.bits[0] = portMap;
#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
	vlanCfg.untag.bits[0] = untag ? ((~((1 << EXT_PORT1)|(1 << EXT_PORT2))) & portMap) : 0x0;
#else
	vlanCfg.untag.bits[0] = untag ? ((~((1 << EXT_PORT0)|(1 << EXT_PORT1)|(1 << EXT_PORT2))) & portMap) : 0x0;
#endif
	vlanCfg.ivl_en = ENABLED;

	RTL8367_DEBUG("RTL8367AddVlan vid=%d, mbr=%x, untag=%x\r\n", vid, vlanCfg.mbr.bits[0], vlanCfg.untag.bits[0]);
	if ((ret = rtk_vlan_set(vid, &vlanCfg)) != RT_ERR_OK)
	{
		RTL8367_ERROR("set RTL8367 VLAN %d portMap 0x%x error: 0x%08x...\n", vid, portMap, ret);
		return ret;
	}
	
	return RT_ERR_OK;
}

rtk_api_ret_t RTL8367SetPort(rtk_uint32 portMap, rtk_vlan_t portVID)
{
	rtk_api_ret_t ret;
	u8 index = 0;
	rtk_uint32 port = 0;

	for (index = 0; index < 5; index++)
	{
		port = portMap & (0x1 << index);

		if (port)
		{
			RTL8367_DEBUG("RTL8367SetPort port=%d, pvid=%d\n", index, portVID);
			if ((ret = rtk_vlan_portPvid_set(index, portVID, 0)) != RT_ERR_OK)
			{
				RTL8367_ERROR("set RTL8367 port %d PVID %d error: 0x%08x...\n", port, portVID, ret);
				return ret;
			}
		}
	}
	
	return RT_ERR_OK;
}

rtk_api_ret_t RTL8367SetVlan(struct vlanInfo * vlan)
{

	rtk_uint32 index = 0;
	rtk_api_ret_t ret;
	rtk_vlan_t iptvVid = 0;
	rtk_pri_t iptvPri = 0;
	rtk_vlan_t multiCastVid = 0;
	rtk_pri_t multiCastPri = 0;
	extern rtk_api_ret_t (*multiCastVlanRxHook)(struct sk_buff *skb);
	extern rtk_api_ret_t (*multiCastVlanTxHook)(struct sk_buff *skb);

	for (index = 0; vlan[index].vid != '\0'; index++)
	{
		if ((ret = RTL8367AddVlan(vlan[index].vid, vlan[index].portMap, vlan[index].untag)) != RT_ERR_OK)
		{
			RTL8367_ERROR("add RTL8367 VLAN %d portMap 0x%x error: 0x%08x...\n", vlan[index].vid, vlan[index].portMap, ret);
			return ret;
		}
	}

	for (index = 0; vlan[index].vid != '\0'; index++)
	{
		if (vlan[index].vlanPurpose == IPTV_WAN)
		{
			iptvVid = vlan[index].vid;
			iptvPri = vlan[index].pri;
		}

		if (vlan[index].vlanPurpose == IPTV_MULTICAST_WAN)/* Multicast frame's ingress VLAN ID  */
		{
			multiCastVid = vlan[index].vid;
			multiCastPri = vlan[index].pri;
		}
		
		if (vlan[index].untag && vlan[index].vlanPurpose != IPTV_MULTICAST_LAN)
		{
			if ((ret = RTL8367SetPort(vlan[index].portMap, vlan[index].vid)) != RT_ERR_OK)
			{
				RTL8367_ERROR("set RTL8367 port %d PVID %d error: 0x%08x...\n", index, vlan[index].vid, ret);
				return ret;
			}
		}
	}
	
	return RT_ERR_OK;
}

rtk_api_ret_t addMultiCastVlanTag(struct sk_buff *skb)
{
	rtk_api_ret_t ret;
	struct vlanHdr *vlanHdr;
	rtk_uint16 iptvTci;
	rtk_uint16 multiCastTci;
	
	vlanHdr = (struct vlanHdr *)(skb->data - 2);
	iptvTci = (rtk_uint16)((iptvPriority << 13) + iptvVlanID);
	multiCastTci = (rtk_uint16)((multiCastPriority << 13) + multiCastVlanID);

	//RTL8367_DEBUG("skb: %2.2x %2.2x %2.2x %2.2x %2.2x\n", *(skb->data - 2), *(skb->data - 1), skb->data[0], skb->data[1], skb->data[2]);
	
	if ((*(skb->data - 14) == 0x01) && (*(skb->data - 13) == 0x00) && (*(skb->data - 12) == 0x5E)/* multiCast dst MAC  */
		&& ntohs(vlanHdr->tpid) == 0x8100 && ntohs(vlanHdr->tci) == iptvTci)
	{
		vlanHdr->tci = htons(multiCastTci);/* replace iptv tag with multiCast tag  */
		RTL8367_DEBUG("replace iptv tci: %d with multiCast tci: %d.\n", iptvTci, multiCastTci);
	}

	return RT_ERR_OK;
}

rtk_api_ret_t setVlan(struct vlanInfo * vlan)
{
	rtk_api_ret_t ret;
	rtk_uint32 portUsed;
	
	u8 index= 0;
	for (index = 0; vlan[index].vid != '\0'; index++)
	{
		printk("index: %d	vid:%d	pri:%d	untag:%d	portMap:0x%x\n", index, vlan[index].vid, vlan[index].pri, vlan[index].untag, vlan[index].portMap);
	}


	/* port 4,5,6,7 used  */
	if ((ret = MT7620ClearVlanConfig()) != RT_ERR_OK)
	{
		RTL8367_ERROR("MT7620ClearVlanConfig error: 0x%08x...\n", ret);
		return ret;
	}
	RTL8367_DEBUG("MT7620ClearVlanConfig success...\n");
	
	portUsed = 0xE0;
	if ((ret = MT7620SetVlan(portUsed, vlan)) != RT_ERR_OK)
	{
		RTL8367_ERROR("MT7620SetVlan error: 0x%08x...\n", ret);
		return ret;
	}
	RTL8367_DEBUG("MT7620SetVlan success...\n");

	if ((ret = RTL8367ClearVlanConfig()) != RT_ERR_OK)
	{
		RTL8367_ERROR("RTL8367ClearVlanConfig error: 0x%08x...\n", ret);
		return ret;
	}
	RTL8367_DEBUG("RTL8367ClearVlanConfig success...\n");

	if ((ret = RTL8367SetVlan(vlan)) != RT_ERR_OK)
	{
		RTL8367_ERROR("RTL8367SetVlan error: 0x%08x...\n", ret);
		return ret;
	}
	RTL8367_DEBUG("RTL8367SetVlan success...\n");


	return RT_ERR_OK;
}

struct vlanInfo vlan[16];

int vlanSetCtl(struct sock *sk, int cmd, void __user *user, unsigned int len)
{
	int ret = 0;
	
	RTL8367_DEBUG("received a cmd from user.\n");
	switch(cmd)
	{
	case VLAN_SET:
		RTL8367_DEBUG("cmd is set vlan ...\n");

		if (user == NULL)
		{
			ret = -1;
			break;
		}
			
		copy_from_user(vlan, user, len);
		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("setVlanDslEnable error: 0x%08x...\n", ret);
			ret = -1;
			break;
		}
			
		break;
	default:
		RTL8367_ERROR("received an unknown set ctl command\n");
		ret = -1;
		
		break;
	}
	
	return ret;	
}


static size_t eth_vlan_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	int i;
	int len=0;
	
	if (*ppos > 0)
	    return 0;
	
	for(i=0;i<16 && vlan[i].vid; i++)
	{
		len += sprintf(eth_vlan_ret_buf+len, "vlan=%d port=0x%x, untag=%d, purpose=%d\r\n", 
			vlan[i].vid, vlan[i].portMap, vlan[i].untag, vlan[i].vlanPurpose);
	}

    if (len > size)
        len = size;
    else if (len < 0)
        len = 0;

	copy_to_user(buf, eth_vlan_ret_buf, len);
	
	*ppos += len;

	return len;
}


static int eth_vlan_write_proc(struct file *file, const char *buffer,	
	unsigned long count, void *data)
{
	char val_string[16];
	int val;
	int ret = 0;
	
	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	if (sscanf(val_string, "%d", &val) != 1)
	{
		printk("usage: <action>\n");
		return count;
	}
	switch (val)
	{
	case 0:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
#if defined(CONFIG_TP_MODEL_C5V4)
        vlan[0].portMap = 0x2000f;
#else
		vlan[0].portMap = 0x20007;
#endif

		vlan[1].vid = 2;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= INTERNET_WAN;
#if defined(CONFIG_TP_MODEL_C5V4)
        vlan[1].portMap = 0x20010;
#else
		vlan[1].portMap = 0x20008;
#endif

		vlan[2].vid = '\0';
		RTL8367_DEBUG("set LAN: eth0.3 	WAN:eth0.2\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("setVlanDslEnable error: 0x%08x...\n", ret);
			break;
		}
		
		break;
	case 1:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
		vlan[0].portMap = 0x2000e;

		vlan[1].vid = 4;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= IPTV_LAN;
		vlan[1].portMap = 0x20001;

		vlan[2].vid = 100;
		vlan[2].pri = 0;
		vlan[2].untag = 0;
		vlan[2].vlanPurpose= INTERNET_WAN;
		vlan[2].portMap = 0x20010;

		vlan[3].vid = 101;
		vlan[3].pri = 0;
		vlan[3].untag = 0;
		vlan[3].vlanPurpose= IPTV_WAN;
		vlan[3].portMap = 0x20010;

		vlan[4].vid = '\0';
		
		RTL8367_DEBUG("set LAN: eth0.3, eth0.4	 	WAN:eth0.100 as Internet tagged, eth0.101 as IPTV tagged\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("setVlanDslEnable error: 0x%08x...\n", ret);
			break;
		}
			
		break;
	case 2:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
		vlan[0].portMap = 0x46;//0100, 0110

		vlan[1].vid = 4;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= IPTV_LAN;
		vlan[1].portMap = 0x58;//0101, 1000

		vlan[2].vid = 2;
		vlan[2].pri = 0;
		vlan[2].untag = 1;
		vlan[2].vlanPurpose= INTERNET_WAN;
		vlan[2].portMap = 0x81;//1000, 0001

		vlan[3].vid = 2;
		vlan[3].pri = 0;
		vlan[3].untag = 1;
		vlan[3].vlanPurpose= INTERNET_WAN;
		vlan[3].portMap = 0x81;//1000, 0001

		vlan[4].vid = '\0';
		
		RTL8367_DEBUG("set LAN: eth0.3, eth0.4		WAN:eth0.2_1 as Internet untagged, eth0.2_2 as IPTV untagged\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("setVlanDslEnable error: 0x%08x...\n", ret);
			break;
		}
		
		break;
	case 3:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
		vlan[0].portMap = 0x46;//0100, 0110

		vlan[1].vid = 4;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= IPTV_LAN;
		vlan[1].portMap = 0x48;//0100, 1000

		vlan[2].vid = 5;
		vlan[2].pri = 0;
		vlan[2].untag = 1;
		vlan[2].vlanPurpose= IPPHONE_LAN;
		vlan[2].portMap = 0x50;//0101, 0000

		vlan[3].vid = 100;
		vlan[3].pri = 0;
		vlan[3].untag = 0;
		vlan[3].vlanPurpose= INTERNET_WAN;
		vlan[3].portMap = 0x81;//1000, 0001

		vlan[4].vid = 101;
		vlan[4].pri = 0;
		vlan[4].untag = 0;
		vlan[4].vlanPurpose= IPTV_WAN;
		vlan[4].portMap = 0x81;//1000, 0001

		vlan[5].vid = 102;
		vlan[5].pri = 0;
		vlan[5].untag = 0;
		vlan[5].vlanPurpose= IPPHONE_WAN;
		vlan[5].portMap = 0x81;//1000, 0001

		vlan[6].vid = '\0';
		
		RTL8367_DEBUG("set LAN: eth0.3, eth0.4, eth0.5		WAN:eth0.100 as Internet tagged, eth0.101 as IPTV tagged, eth0.102 as IP-Phone tagged\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("setVlanDslEnable error: 0x%08x...\n", ret);
			break;
		}

		break;
	case 4:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
		vlan[0].portMap = 0x42;//0100, 0010

		vlan[1].vid = 4;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= IPTV_LAN;
		vlan[1].portMap = 0x44;//0100, 0100

		vlan[2].vid = 5;
		vlan[2].pri = 0;
		vlan[2].untag = 1;
		vlan[2].vlanPurpose= IPPHONE_LAN;
		vlan[2].portMap = 0x48;//0100, 1000

		vlan[3].vid = 6;
		vlan[3].pri = 0;
		vlan[3].untag = 1;
		vlan[3].vlanPurpose= VOIP_LAN;
		vlan[3].portMap = 0x50;//0101, 0000

		vlan[4].vid = 100;
		vlan[4].pri = 0;
		vlan[4].untag = 0;
		vlan[4].vlanPurpose= INTERNET_WAN;
		vlan[4].portMap = 0x81;//1000, 0001

		vlan[5].vid = 101;
		vlan[5].pri = 0;
		vlan[5].untag = 0;
		vlan[5].vlanPurpose= IPTV_WAN;
		vlan[5].portMap = 0x81;//1000, 0001

		vlan[6].vid = 102;
		vlan[6].pri = 0;
		vlan[6].untag = 0;
		vlan[6].vlanPurpose= IPPHONE_WAN;
		vlan[6].portMap = 0x81;//1000, 0001

		vlan[7].vid = 103;
		vlan[7].pri = 0;
		vlan[7].untag = 0;
		vlan[7].vlanPurpose= VOIP_WAN;
		vlan[7].portMap = 0x81;//1000, 0001

		vlan[8].vid = '\0';
		
		RTL8367_DEBUG("set LAN: eth0.3, eth0.4, eth0.5, eth0.6		WAN:eth0.100 as Internet tagged, eth0.101 as IPTV tagged, eth0.102 as IP-Phone tagged, eth0.103 as VOIP tagged\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("setVlanDslEnable error: 0x%08x...\n", ret);
			break;
		}
			
		break;
	case 5:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
		vlan[0].portMap = 0x42;//0100, 0010

		vlan[1].vid = 4;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= IPTV_LAN;
		vlan[1].portMap = 0x44;//0100, 0100

		vlan[2].vid = 5;
		vlan[2].pri = 0;
		vlan[2].untag = 1;
		vlan[2].vlanPurpose= IPPHONE_LAN;
		vlan[2].portMap = 0x48;//0100, 1000

		vlan[3].vid = 6;
		vlan[3].pri = 0;
		vlan[3].untag = 1;
		vlan[3].vlanPurpose= VOIP_LAN;
		vlan[3].portMap = 0x50;//0101, 0000

		vlan[4].vid = 8;
		vlan[4].pri = 0;
		vlan[4].untag = 1;
		vlan[4].vlanPurpose= IPTV_MULTICAST_LAN;
		vlan[4].portMap = 0x44;//0100, 0100

		vlan[5].vid = 100;
		vlan[5].pri = 0;
		vlan[5].untag = 0;
		vlan[5].vlanPurpose= INTERNET_WAN;
		vlan[5].portMap = 0x81;//1000, 0001

		vlan[6].vid = 101;
		vlan[6].pri = 0;
		vlan[6].untag = 0;
		vlan[6].vlanPurpose= IPTV_WAN;
		vlan[6].portMap = 0x81;//1000, 0001

		vlan[7].vid = 102;
		vlan[7].pri = 0;
		vlan[7].untag = 0;
		vlan[7].vlanPurpose= IPPHONE_WAN;
		vlan[7].portMap = 0x81;//1000, 0001

		vlan[8].vid = 103;
		vlan[8].pri = 0;
		vlan[8].untag = 0;
		vlan[8].vlanPurpose= VOIP_WAN;
		vlan[8].portMap = 0x81;//1000, 0001

		vlan[9].vid = 104;
		vlan[9].pri = 0;
		vlan[9].untag = 0;
		vlan[9].vlanPurpose= IPTV_MULTICAST_WAN;
		vlan[9].portMap = 0x81;//1000, 0001

		vlan[10].vid = '\0';
		
		RTL8367_DEBUG("set LAN: eth0.3, eth0.4, eth0.5, eth0.6, eth0.8		WAN:eth0.100 as Internet tagged, eth0.101 as IPTV tagged, eth0.102 as IP-Phone tagged, eth0.103 as VOIP tagged, eth0.104 as Multicast-IPTV\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("setVlanDslEnable error: 0x%08x...\n", ret);
			break;
		}
			
		break;
	case 6:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
		vlan[0].portMap = 0x20007;

		vlan[1].vid = 2;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= INTERNET_WAN;
		vlan[1].portMap = 0x20008;

		vlan[2].vid = 7;
		vlan[2].pri = 0;
		vlan[2].untag = 1;
		vlan[2].vlanPurpose= INTERNET_WAN;
		vlan[2].portMap = 0x10000;

		vlan[3].vid = '\0';
		RTL8367_DEBUG("set LAN: eth0.3 	WAN:eth0.2\n");
		printk("\nSet EWAN vlan 2(WAN), SFP vlan 7\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("Case 6 error: 0x%08x...\n", ret);
			break;
		}
		
		break;
	case 7:
		vlan[0].vid = 3;
		vlan[0].pri = 0;
		vlan[0].untag = 1;
		vlan[0].vlanPurpose= INTERNET_LAN;
		vlan[0].portMap = 0x20007;

		vlan[1].vid = 2;
		vlan[1].pri = 0;
		vlan[1].untag = 1;
		vlan[1].vlanPurpose= INTERNET_WAN;
		vlan[1].portMap = 0x30000;

		vlan[2].vid = 7;
		vlan[2].pri = 0;
		vlan[2].untag = 1;
		vlan[2].vlanPurpose= INTERNET_WAN;
		vlan[2].portMap = 0x8;

		vlan[3].vid = '\0';
		RTL8367_DEBUG("set LAN: eth0.3 	WAN:eth0.2\n");
		printk("\nSet EWAN vlan 7, SFP vlan 2(WAN)\n");

		if ((ret = setVlan(vlan)) != RT_ERR_OK)
		{
			RTL8367_ERROR("Case 7 error: 0x%08x...\n", ret);
			break;
		}
		
		break;
	defualt:
		RTL8367_ERROR("Unknown command...\n");

		break;
	}
	
	return count;
}

static struct file_operations eth_vlan_fops = {
        .owner          = THIS_MODULE,
        .read           = eth_vlan_read_proc,
        .write          = eth_vlan_write_proc
};

void init_raVlan_tplink(void)
{
        struct proc_dir_entry *eth_proc;

        eth_proc = proc_create("tplink/eth_vlan", 0, NULL, &eth_vlan_fops);
}
/* vlan add end  */
#endif

#ifdef TP_AP_MODE

#define LAN_PORT_NUM 5
#define MAX_REG_CHECK 3
#define UDELAY_TIME g_uDelayTime

static int g_uDelayTime = 50000;

int switchPortStatus(int port, int down)
{
	int regChecks = 0;
	u32 read_data = 0, check_data = 0;

	mii_mgr_read(port, 0xd00, &read_data);
	if (down)
		read_data = read_data | (0x1 << 11);
	else
		read_data = read_data & ~(0x1 << 11);
	RTL8367_ERROR("port %d: 0xd00 = %#x\n", port, read_data);
	mii_mgr_write(port, 0xd00, read_data);
	udelay(UDELAY_TIME);
	mii_mgr_read(port, 0xd00, &check_data);
	while ((check_data != read_data) && (regChecks++ < MAX_REG_CHECK))
	{
		RTL8367_ERROR("down: write(%#x) & check(%#x) UNMATCH!\n", read_data, check_data);
		mii_mgr_write(port, 0xd00, read_data);
		udelay(UDELAY_TIME);
		mii_mgr_read(port, 0xd00, &check_data);
	}

	return (regChecks < MAX_REG_CHECK);
}

int phySetCtl(struct sock *sk, int cmd, void __user *user, unsigned int len)
{
	int ret = 0;
	unsigned char gwMac[6] = {0}, gwPort = 0;
	int port = 0;
	u32 read_data = 0, check_data = 0;
	int regChecks = 0;

	RTL8367_DEBUG("received a phy set ctrl cmd(%d) from user.\n", cmd);
	
	switch(cmd)
	{
	case PHYRESET_SET:
		RTL8367_ERROR("cmd is reset phy with delay time = %d(usec) ...\n", g_uDelayTime);

		if (NULL != user)
		{
			copy_from_user(gwMac, user, len);
			mtk_l2_addr_get(gwMac, &gwPort);
		}
		
		for (port = 0; port < LAN_PORT_NUM; ++port)
		{
			if ((NULL != user) && (gwPort == (1 << port)))
			{
				continue;
			}

			if ((port != 0) && (port != 3))
			{
				continue;
			}
			
			/* Down */
			mii_mgr_read(port, 0xd00, &read_data);
			read_data = read_data | (0x1 << 11);
			RTL8367_ERROR("port %d: 0xd00 = %#x\n", port, read_data);
			mii_mgr_write(port, 0xd00, read_data);
			udelay(UDELAY_TIME);
			mii_mgr_read(port, 0xd00, &check_data);
			regChecks = 0;
			while ((check_data != read_data) && (regChecks++ < MAX_REG_CHECK))
			{
				RTL8367_ERROR("down: write(%#x) & check(%#x) UNMATCH!\n", read_data, check_data);
				mii_mgr_write(port, 0xd00, read_data);
				udelay(UDELAY_TIME);
				mii_mgr_read(port, 0xd00, &check_data);
			}

			/* Up */
			mii_mgr_read(port, 0xd00, &read_data);
			read_data = read_data & ~(0x1 << 11);
			RTL8367_ERROR("port %d: 0xd00 = %#x\n", port, read_data);
			mii_mgr_write(port, 0xd00, read_data);
			udelay(UDELAY_TIME);
			mii_mgr_read(port, 0xd00, &check_data);
			regChecks = 0;
			while ((check_data != read_data) && (regChecks++ < MAX_REG_CHECK))
			{
				RTL8367_ERROR("up: write(%#x) & check(%#x) UNMATCH!\n", read_data, check_data);
				mii_mgr_write(port, 0xd00, read_data);
				udelay(UDELAY_TIME);
				mii_mgr_read(port, 0xd00, &check_data);
			}
		}

		break;

	case PHY_UP_PORT:
		if (user == NULL)
		{
			RTL8367_ERROR("user parameter is NULL!\n");
			ret = -1;
			break;
		}

		copy_from_user(&port, user, len);

		mii_mgr_read(port, 0xd00, &read_data);
		read_data = read_data & ~(0x1 << 11);
		RTL8367_ERROR("port %d: 0xd00 = %#x\n", port, read_data);
		mii_mgr_write(port, 0xd00, read_data);
		udelay(UDELAY_TIME);
		
		break;

	case PHY_DOWN_PORT:
		if (user == NULL)
		{
			RTL8367_ERROR("user parameter is NULL!\n");
			ret = -1;
			break;
		}
		
		copy_from_user(&port, user, len);
		
		mii_mgr_read(port, 0xd00, &read_data);
		read_data = read_data | (0x1 << 11);
		RTL8367_ERROR("port %d: 0xd00 = %#x\n", port, read_data);
		mii_mgr_write(port, 0xd00, read_data);
		udelay(UDELAY_TIME);
		
		break;
		
	case PHY_DELAY:
		if (NULL != user)
		{
			copy_from_user(&g_uDelayTime, user, len);
			RTL8367_ERROR("Set phy delay time to %d(usec)\n", g_uDelayTime);
		}
		break;
		
	default:
		RTL8367_ERROR("received an unknown set ctl command\n");
		ret = -1;
		
		break;
	}
	
	return ret;	
}

/* add by wanghao for C20iSD  */
void startingConfig(void)
{
	int regVal = 0;
	/* disable port 1,2 and 4 */	
	mii_mgr_read(1, 0xd00, &regVal);
	regVal = regVal | (0x1 << 11);
	mii_mgr_write(1, 0xd00, regVal);

	udelay(50 * 1000);
	
	mii_mgr_read(2, 0xd00, &regVal);
	regVal = regVal | (0x1 << 11);
	mii_mgr_write(2, 0xd00, regVal);

	udelay(50 * 1000);
	
	mii_mgr_read(4, 0xd00, &regVal);
	regVal = regVal | (0x1 << 11);
	mii_mgr_write(4, 0xd00, regVal);
	
	/* set DSCP tag , set port 0,3,6 and 7 */
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x44) = 0x171111; 

	regVal = *(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2004); 
	regVal |= 0x1 << 12;
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2004) = regVal;

	regVal = *(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2304); 
	regVal |= 0x1 << 12;
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2304) = regVal;

	regVal = *(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2604); 
	regVal |= 0x1 << 12;
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2604) = regVal;

	regVal = *(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2704); 
	regVal |= 0x1 << 12;
	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x2704) = regVal;

	*(volatile unsigned long *)(RALINK_ETH_SW_BASE+0x48) = 0x8080256;
}
#endif


static size_t port_status_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	int len=0;
	u32 regData = 0;
	int count = 0;
	
	char ret_buf[64];
	int rtl8367_port0_status_reg = (CHIP_RTL8367D == g_switch_chip) ? RTL8367D_REG_PORT0_STATUS :RTL8367C_REG_PORT0_STATUS;

	if (*ppos > 0)
	    return 0;

#if defined(CONFIG_TP_MODEL_C5V4)
	for (count = 0; count <= 4; count++)
#else
	for (count = 0; count <= 3; count++)
#endif
	{
		RT_MAPPER->smi_read(rtl8367_port0_status_reg + count, &regData);

		 len += sprintf(ret_buf+len, "0x%x ", regData&0x1f);
	}

	len += sprintf(ret_buf+len, "\n");
	
    if (len > size)
        len = size;
    else if (len < 0)
        len = 0;

	copy_to_user(buf, ret_buf, len);
	
	*ppos += len;
		
    return len;
}


#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
static int port_status_write_proc(struct file *file, const char *buffer,
	unsigned long count, void *data)
{
	char val_string[8];
	int port_num = 0, port_status_val = 0;
    int port_status_argc = 0;
    rtk_uint32 port_status_data;
    rtk_api_ret_t retVal;

	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

    port_status_argc = sscanf(val_string, "%d %d", &port_num, &port_status_val);
    if(port_status_argc!=2)
    {
 		printk("\nUsage: echo <port num> <port setting> > /proc/tplink/eth_port_status\n");
		printk("<port num>: UTP PORT is 0~3\n");
		printk("<port setting>: 1 as enable, 0 as disable\n");
		printk("  e.g. echo 1 0 > /proc/tplink/eth_port_stat_table\n");
        return count;
    }

    if(port_num <= UTP_PORT3)
    {    
        if ((retVal = rtk_port_phyReg_get(UTP_PORT3, PHY_CONTROL_REG, &port_status_data)) != RT_ERR_OK)
            return retVal;

        if(port_status_val)
        {
            port_status_data &= 0xF7FF;
            port_status_data |= 0x0200;
        }else{
            port_status_data |= 0x0800;
        }
        if ((retVal = rtk_port_phyReg_set(UTP_PORT3, PHY_CONTROL_REG, port_status_data)) != RT_ERR_OK)
            return retVal;
    }
    else
    {
 		printk("usage: echo <port num> <port setting> > /proc/tplink/eth_port_status\n");
		printk("<port num>: UTP PORT is 0~3, EXT_PORT is 16\n");
		printk("<port setting>: 1 as enable, 0 as disable\n");
		printk("  e.g. echo 1 > /proc/tplink/eth_port_stat_table\n");
        return count;
    }

	return count;
}
#endif

static struct file_operations port_status_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= port_status_read_proc,
#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
	.write		= port_status_write_proc
#else
    .write      = NULL
#endif
};

void init_port_status_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_port_status", 0, NULL, &port_status_fops);

	return;
}

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
#if 0 /* For Debug EC220-G5sV1 */
static size_t sgmii_status_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	int len=0;
	u32 regData = 0;
	int count = 0;
	char ret_buf[64];

    rtk_port_t port = EXT_PORT0;
    rtk_data_t SignalDetect;
    rtk_data_t Sync;
    rtk_port_linkStatus_t Link;

	if (*ppos > 0)
	    return 0;

    _rtk_port_sgmiiLinkStatus_get(port, &SignalDetect, &Sync, &Link);

    len += sprintf(ret_buf+len, "SignalDetect=0x%x, Sync=0x%x, Link=%d\n", SignalDetect, Sync, Link);
	
    if (len > size)
        len = size;
    else if (len < 0)
        len = 0;

	copy_to_user(buf, ret_buf, len);
	
	*ppos += len;
		
    return len;
}

static struct file_operations sgmii_status_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= sgmii_status_read_proc,
	.write		= NULL
};

void init_sgmii_status_proc(void)
{
	struct proc_dir_entry *sgmii_proc;

	sgmii_proc = proc_create("tplink/sgmii_status", 0, NULL, &sgmii_status_fops);

	return;
}

static size_t sgmii_speed_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
    /*
     * Speed   | 0: 10M, 1: 100M, 2: 1000M
     * Duplex  | 0: Half, 1: Full
     * Link    | 0: Down, 1: Up
     */

	int len=0;
	u32 regData = 0;
	int count = 0;
	char ret_buf[64];

    rtk_port_t port = EXT_PORT0;
    rtk_mode_ext_t mode = MODE_EXT_1000X;
    rtk_port_mac_ability_t portability;


	if (*ppos > 0)
	    return 0;

    _rtk_port_macForceLinkExt_get(port, &mode, &portability);

    len += sprintf(ret_buf+len, "Link=%x,Speed=%x,Duplex=%x\n", portability.link, portability.speed, portability.duplex);

    if (len > size)
        len = size;
    else if (len < 0)
        len = 0;

	copy_to_user(buf, ret_buf, len);

	*ppos += len;

    return len;
}
#endif
static int sgmii_speed_write_proc(struct file *file, const char *buffer,
	unsigned long count, void *data)
{
	char val_string[128];
	rtk_uint32 val;
    int port, speed;
    int argc=0;
    rtk_mode_ext_t mode;
    rtk_port_mac_ability_t portability;


	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

    argc = sscanf(val_string, "%d %d", &port, &speed);
	if(argc!=2)
    {
		printk("usage: echo <port_num> <sgmii_speed_case> > /proc/tplink/sgmii_speed\n");
		printk("<port_num>\n");
        printk("<sgmii_speed_case>\n");
        printk("  0: MODE_EXT_1000X_100FX\n");
        printk("  1: MODE_EXT_100FX\n");
        printk("  2: MODE_EXT_1000X\n");
        printk("  3: MODE_EXT_SGMII\n");
		printk("  e.g. echo 16 1 > /proc/tplink/sgmii_speed\n");
		return count;
	}

	printk("\nSet %d to speed case %d\n", port, speed);
    portability.forcemode = MAC_FORCE;
    portability.speed     = PORT_SPEED_1000M;
    portability.duplex    = PORT_FULL_DUPLEX;
    portability.link      = PORT_LINKUP;
    portability.nway      = DISABLED;
    portability.txpause   = ENABLED;
    portability.rxpause   = ENABLED;

    switch(speed)
    {
        case 0:
            mode = MODE_EXT_1000X_100FX;
            portability.speed = PORT_SPEED_1000M;
            break;
        case 1:
            mode = MODE_EXT_100FX;
            portability.speed = PORT_SPEED_100M;
            break;
        case 2:
            mode = MODE_EXT_1000X;
            portability.speed = PORT_SPEED_1000M;
            break;
        default:
            mode = MODE_EXT_SGMII;
            portability.speed = PORT_SPEED_1000M; 
            break;
    }

    //_rtk_port_macForceLinkExt_set(port, mode, &portability);
    rt_rtl8367_enableSgmii(port, mode, &portability);

	return count;
}

static struct file_operations sgmii_speed_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= NULL,
	.write		= sgmii_speed_write_proc
};

void init_sgmii_speed_proc(void)
{
	struct proc_dir_entry *sgmii_speed_proc;

	sgmii_speed_proc = proc_create("tplink/sgmii_speed", 0, NULL, &sgmii_speed_fops);

	return;
}
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */



int igmp_snooping = 0;

static size_t igmp_snooping_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	int len=0;
	
	char ret_buf[64];

	if (*ppos > 0)
	    return 0;
	
	len += sprintf(ret_buf+len, "%d\n", igmp_snooping);
	
    if (len > size)
        len = size;
    else if (len < 0)
        len = 0;

	copy_to_user(buf, ret_buf, len);
	
	*ppos += len;
	
    return len;
}

static int igmp_snooping_write_proc(struct file *file, const char *buffer,	
	unsigned long count, void *data)
{
	char val_string[128];
	int val;
	int ret = 0;
	rtk_l2_ipmc_lookup_type_t type;
	rtk_portmask_t portmask;
	
	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	if (sscanf(val_string, "%d", &val) != 1)
	{
		printk("usage: <action>\n");
		return count;
	}
	
	igmp_snooping = val;
	
	if(igmp_snooping)
	{
		rtk_igmp_state_set(ENABLED);
		
		/* RTL8367C_REG_UNKNOWN_IPV4_MULTICAST_CTRL0 | RTL8367D_REG_UNKNOWN_IPV4_MULTICAST_CTRL0*/
		//if(RT_ERR_OK != rtl8367c_setAsicReg(0x08c9, 0xffff))
		if(RT_ERR_OK != RT_MAPPER->asic_setAsicReg(0x08c9, 0xffff))
		{
			RTL8367_ERROR("rtl8367c_setAsicReg error\r\n");
		}
		
#if defined(CONFIG_TP_MODEL_C5V4)
		portmask.bits[0]= ((1<<EXT_PORT1)|(1<<UTP_PORT4));
#elif defined(CONFIG_TP_MODEL_EC220_G5sV1)
        portmask.bits[0]= ((1<<EXT_PORT0)|(1<<EXT_PORT1)|(1<<UTP_PORT3));
#elif defined(CONFIG_TP_MODEL_EC220_G5V2)
		portmask.bits[0]= ((1<<EXT_PORT1)|(1<<UTP_PORT3));
#else
		#error TP_MODEL not defined
#endif
		if(RT_ERR_OK != rtk_igmp_static_router_port_set(&portmask))
		{
			RTL8367_ERROR("rtk_igmp_static_router_port_set error\r\n");
		}
	}
	else
	{
		rtk_igmp_state_set(DISABLED);
		/* RTL8367C_REG_UNKNOWN_IPV4_MULTICAST_CTRL0 | RTL8367D_REG_UNKNOWN_IPV4_MULTICAST_CTRL0*/
		if(RT_ERR_OK != RT_MAPPER->asic_setAsicReg(0x08c9, 0x0000))
		{
			RTL8367_ERROR("rtl8367c_setAsicReg error\r\n");
		}
	}
	
	return count;
}

static struct file_operations igmp_snooping_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= igmp_snooping_read_proc,
	.write		= igmp_snooping_write_proc
};

void init_igmp_snooping_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_igmp_snooping", 0, NULL, &igmp_snooping_fops);

	return;
}

static size_t mcast_table_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	int len=0;
	rtk_uint32 address=0;
	rtk_l2_ipMcastAddr_t ipMcastAddr;
	
	if (*ppos > 0)
	    return 0;

	while(1)
	{
		if(RT_ERR_OK != rtk_l2_ipMcastAddr_next_get(&address, &ipMcastAddr))
		{
			break;
		}

		ipMcastAddr.dip |= 0xe0000000;
		
		len += sprintf(mcast_ret_buf+len, "dip=0x%08x, sip=0x%08x, port=0x%08x\n", 
			ipMcastAddr.dip, ipMcastAddr.sip, ipMcastAddr.portmask.bits[0]);
		
		if(len>sizeof(mcast_ret_buf)-128)
		{
			len += sprintf(mcast_ret_buf+len, "...\n");
			break;
		}
		address++;
	}

    if (len > size)
        len = size;
    else if (len < 0)
        len = 0;

	copy_to_user(buf, mcast_ret_buf, len);
	
	*ppos += len;
	
    return len;
}

static int mcast_table_write_proc(struct file *file, const char *buffer,	
	unsigned long count, void *data)
{
	char val_string[128];
	rtk_uint32 val;

	rtk_uint32 address=0;
	rtk_l2_ipMcastAddr_t ipMcastAddr;
	int ret = 0;
	
	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	if (sscanf(val_string, "%d", &val) != 1)
	{
		printk("usage: <action>\n");
		return count;
	}
	
	memset(&ipMcastAddr, 0x0, sizeof(ipMcastAddr));
	
	while(1)
	{
		address = 0;
		if(RT_ERR_OK != rtk_l2_ipMcastAddr_next_get(&address, &ipMcastAddr))
		{
			break;
		}

		ipMcastAddr.dip |= 0xe0000000;
		
		if(RT_ERR_OK != rtk_l2_ipMcastAddr_del(&ipMcastAddr))
		{
			RTL8367_ERROR("rtk_l2_ipMcastAddr_del fail\r\n");
		}
	}
	
	return count;
}

static struct file_operations mcast_table_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= mcast_table_read_proc,
	.write		= mcast_table_write_proc
};

void init_mcast_table_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_mcast_table", 0, NULL, &mcast_table_fops);

	return;
}

static size_t ucast_table_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	int len=0;
	rtk_uint32 address=0;
	rtk_l2_ucastAddr_t ucastAddr;
	
	if (*ppos > 0)
	    return 0;

	while(1)
	{
		if(RT_ERR_OK != rtk_l2_addr_next_get(READMETHOD_NEXT_L2UC, UTP_PORT0, &address, &ucastAddr))
		{
			break;
		}

#if defined(CONFIG_TP_MODEL_C5V4)
        if(ucastAddr.port <= 4)
#else
        if(ucastAddr.port < 4) // for EC220-G5, only 0 ~ 3 is Ether port
#endif
        {
            len += sprintf(ucast_ret_buf+len,
                "mac=%02x-%02x-%02x-%02x-%02x-%02x, ivl=%d, fid=%d, static=%d, cvid=%d, port=%d\n",
                ucastAddr.mac.octet[0], 
                ucastAddr.mac.octet[1],
                ucastAddr.mac.octet[2],
                ucastAddr.mac.octet[3],
                ucastAddr.mac.octet[4],
                ucastAddr.mac.octet[5],
                ucastAddr.ivl,
                ucastAddr.fid,
                ucastAddr.is_static,
                ucastAddr.cvid,
                ucastAddr.port);
        }

#if 0
		len += sprintf(ret_buf+len, 
			"mac=%02x-%02x-%02x-%02x-%02x-%02x, ivl=%d, fid=%d, static=%d, cvid=%d, port=%d\n", 
			ucastAddr.mac.octet[0], 
			ucastAddr.mac.octet[1],
			ucastAddr.mac.octet[2],
			ucastAddr.mac.octet[3],
			ucastAddr.mac.octet[4],
			ucastAddr.mac.octet[5],
			ucastAddr.ivl,
			ucastAddr.fid,
			ucastAddr.is_static,
			ucastAddr.cvid,
			ucastAddr.port);
#endif
		if(len>sizeof(ucast_ret_buf)-128)
		{
			len += sprintf(ucast_ret_buf+len, "...\n");
			break;
		}
		address++;
	}
	
    if (len > size)
        len = size;
    else if (len < 0)
        len = 0;

	copy_to_user(buf, ucast_ret_buf, len);
	
	*ppos += len;
	
    return len;
}

static int ucast_table_write_proc(struct file *file, const char *buffer,	
	unsigned long count, void *data)
{
	char val_string[128];
	rtk_uint32 val;
	rtk_uint32 address=0;
	rtk_l2_ucastAddr_t ucastAddr;
	
	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	if (sscanf(val_string, "%d", &val) != 1)
	{
		printk("usage: <action>\n");
		return count;
	}

	while(1)
	{
		address=0;
		if(RT_ERR_OK != rtk_l2_addr_next_get(READMETHOD_NEXT_L2UC, UTP_PORT0, &address, &ucastAddr))
		{
			break;
		}
		rtk_l2_addr_del(&ucastAddr.mac, &ucastAddr);
	}
	
	return count;
}

static struct file_operations ucast_table_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= ucast_table_read_proc,
	.write		= ucast_table_write_proc
};

void init_ucast_table_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_ucast_table", 0, NULL, &ucast_table_fops);

	return;
}

static size_t eth_port_stat_read_proc(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	int len = 0, count = 0;
#if defined(CONFIG_TP_MODEL_C5V4)
	int max_port_num = 5; //number of all ethernet port, including WAN
#else
	int max_port_num = 4;
#endif

	rtk_stat_counter_t byte_tx; //unsigned long long, byte
	rtk_stat_counter_t byte_rx;
	rtk_stat_counter_t pkt_tx;
	rtk_stat_counter_t pkt_rx;
	rtk_stat_counter_t err_tx;
	rtk_stat_counter_t err_rx;

	rtk_stat_counter_t ifOutBroadcastPkts;
	rtk_stat_counter_t ifOutMulticastPkts;
	rtk_stat_counter_t ifOutUcastPkts;

	rtk_stat_counter_t ifInBroadcastPkts;
	rtk_stat_counter_t ifInMulticastPkts;
	rtk_stat_counter_t ifInUcastPkts;

	rtk_stat_counter_t dot3StatsSymbolErrors;
	rtk_stat_counter_t dot3StatsFCSErrors;
	rtk_stat_counter_t etherStatsFragments;
	rtk_stat_counter_t InIgmpChecksumError;
	rtk_stat_counter_t InMldChecksumError;

	if (*ppos > 0)
		return 0;

	for (count = 0; count < max_port_num; count++)
	{
		rtk_stat_port_get(UTP_PORT0+count, STAT_IfInOctets, &byte_tx);
		rtk_stat_port_get(UTP_PORT0+count, STAT_IfOutOctets, &byte_rx);

		rtk_stat_port_get(UTP_PORT0+count, STAT_IfOutBroadcastPkts, &ifOutBroadcastPkts);
		rtk_stat_port_get(UTP_PORT0+count, STAT_IfOutMulticastPkts, &ifOutMulticastPkts);
		rtk_stat_port_get(UTP_PORT0+count, STAT_IfOutUcastPkts, &ifOutUcastPkts);
		pkt_tx = ifOutBroadcastPkts + ifOutMulticastPkts + ifOutUcastPkts;

		rtk_stat_port_get(UTP_PORT0+count, STAT_IfInBroadcastPkts, &ifInBroadcastPkts);
		rtk_stat_port_get(UTP_PORT0+count, STAT_IfInMulticastPkts, &ifInMulticastPkts);
		rtk_stat_port_get(UTP_PORT0+count, STAT_IfInUcastPkts, &ifInUcastPkts);
		pkt_rx = ifInBroadcastPkts + ifInMulticastPkts + ifInUcastPkts;

		err_tx = 0;

		rtk_stat_port_get(UTP_PORT0+count, STAT_Dot3StatsSymbolErrors, &dot3StatsSymbolErrors);
		rtk_stat_port_get(UTP_PORT0+count, STAT_Dot3StatsFCSErrors, &dot3StatsFCSErrors);
		rtk_stat_port_get(UTP_PORT0+count, STAT_EtherStatsFragments, &etherStatsFragments);
		rtk_stat_port_get(UTP_PORT0+count, STAT_InIgmpChecksumError, &InIgmpChecksumError);
		rtk_stat_port_get(UTP_PORT0+count, STAT_InMldChecksumError, &InMldChecksumError);
		err_rx = dot3StatsSymbolErrors + dot3StatsFCSErrors + etherStatsFragments + InIgmpChecksumError + InMldChecksumError;

		len += sprintf(eth_port_ret_buf+len, 
						"port=%d,byte_tx=%llu,byte_rx=%llu, pkt_tx=%llu, pkt_rx=%llu, err_tx=%llu, err_rx=%llu\n",
						count, byte_tx, byte_rx, pkt_tx, pkt_rx, err_tx, err_rx);
	}

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    /* get SFP port(EXT_PORT0) stat */
    {
        rtk_stat_port_get(EXT_PORT0, STAT_IfInOctets, &byte_tx);
        rtk_stat_port_get(EXT_PORT0, STAT_IfOutOctets, &byte_rx);

        rtk_stat_port_get(EXT_PORT0, STAT_IfOutBroadcastPkts, &ifOutBroadcastPkts);
        rtk_stat_port_get(EXT_PORT0, STAT_IfOutMulticastPkts, &ifOutMulticastPkts);
        rtk_stat_port_get(EXT_PORT0, STAT_IfOutUcastPkts, &ifOutUcastPkts);
        pkt_tx = ifOutBroadcastPkts + ifOutMulticastPkts + ifOutUcastPkts;

        rtk_stat_port_get(EXT_PORT0, STAT_IfInBroadcastPkts, &ifInBroadcastPkts);
        rtk_stat_port_get(EXT_PORT0, STAT_IfInMulticastPkts, &ifInMulticastPkts);
        rtk_stat_port_get(EXT_PORT0, STAT_IfInUcastPkts, &ifInUcastPkts);
        pkt_rx = ifInBroadcastPkts + ifInMulticastPkts + ifInUcastPkts;

        err_tx = 0;

        rtk_stat_port_get(EXT_PORT0, STAT_Dot3StatsSymbolErrors, &dot3StatsSymbolErrors);
        rtk_stat_port_get(EXT_PORT0, STAT_Dot3StatsFCSErrors, &dot3StatsFCSErrors);
        rtk_stat_port_get(EXT_PORT0, STAT_EtherStatsFragments, &etherStatsFragments);
        rtk_stat_port_get(EXT_PORT0, STAT_InIgmpChecksumError, &InIgmpChecksumError);
        rtk_stat_port_get(EXT_PORT0, STAT_InMldChecksumError, &InMldChecksumError);
        err_rx = dot3StatsSymbolErrors + dot3StatsFCSErrors + etherStatsFragments + InIgmpChecksumError + InMldChecksumError;

        len += sprintf(eth_port_ret_buf+len,
                        "port=%d,byte_tx=%llu,byte_rx=%llu, pkt_tx=%llu, pkt_rx=%llu, err_tx=%llu, err_rx=%llu\n",
                        EXT_PORT0, byte_tx, byte_rx, pkt_tx, pkt_rx, err_tx, err_rx);
    }
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */

	if (len > size)
		len = size;
	else if (len < 0)
		len = 0;

	copy_to_user(buf, eth_port_ret_buf, len);

	*ppos += len;

	return len;
}

static int eth_port_stat_write_proc(struct file *file, const char *buffer,
	unsigned long count, void *data)
{
	char val_string[128];
	rtk_uint32 val;
	int max_port_num = 5; //number of all ethernet port, including WAN

	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	if (sscanf(val_string, "%d", &val) != 1)
	{
		printk("usage: echo <port_num> > /proc/tplink/eth_port_stat_table\n");
		printk("<port_num>\n");
		printk("  e.g. echo 1 > /proc/tplink/eth_port_stat_table\n");
		return count;
	}

	if((val < 0) || (val >= max_port_num))
	{
		printk("usage: echo <port_num> > /proc/tplink/eth_port_stat_table\n");
		printk("<port_num>\n");
		printk("  e.g. echo 1 > /proc/tplink/eth_port_stat_table\n");
		return count;
	}

	rtk_stat_port_reset(UTP_PORT0+val);
	printk("Reset MIB counters of ports %d!\n", val);

	return count;
}

static struct file_operations eth_port_stat_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= eth_port_stat_read_proc,
	.write		= eth_port_stat_write_proc
};

void init_eth_port_stat_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_port_stat_table", 0, NULL, &eth_port_stat_fops);

	return;
}


static int switch_reg_write_proc(struct file *file, const char *buffer,	
	unsigned long count, void *data)
{
	char val_string[128];
	rtk_uint32 reg, val;
	int argc=0;
	rtk_l2_ipMcastAddr_t ipMcastAddr;
	int ret = 0;
	
	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	argc=sscanf(val_string, "%x %x", &reg, &val);
	if(argc!=1 && argc!=2)
	{
		printk("usage: <action> \n");
		return count;
	}

	if(argc==2)
	{
		if(RT_ERR_OK != RT_MAPPER->asic_setAsicReg(reg, val))
		{
			RTL8367_ERROR("rtl8367c_setAsicReg error\r\n");
		}
	}
	
	if(RT_ERR_OK != RT_MAPPER->asic_getAsicReg(reg, &val))
	{
		RTL8367_ERROR("rtl8367c_getAsicReg error\r\n");
	}
	printk("reg[%08x]=%08x\r\n", reg, val);
	
	return count;
}

static struct file_operations switch_reg_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= NULL,
	.write		= switch_reg_write_proc
};

void init_switch_reg_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_switch_reg", 0, NULL, &switch_reg_fops);

	return;
}

static int shared_meter_write_proc(struct file *file, const char *buffer,	
	unsigned long count, void *data)
{
	char val_string[128];
	rtk_uint32 rate, bucket;
	int argc=0;
	rtk_l2_ipMcastAddr_t ipMcastAddr;
	int ret = 0;
	
	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	argc=sscanf(val_string, "%d %d", &rate, &bucket);
	if(argc!=2)
	{
		printk("usage: <action> \n");
		return count;
	}

	/*Share meter setting*/
	if (rtk_rate_shareMeter_set(0, METER_TYPE_KBPS, rate, ENABLED)!= RT_ERR_OK)
	{
		RTL8367_ERROR("set share meter rate error\r\n");
	}
	
	if (RT_MAPPER->rate_shareMeterBucket_set(0, bucket) != RT_ERR_OK)
	{
		RTL8367_ERROR("set share meter bucket size error\r\n");
	}

	return count;
}

static struct file_operations shared_meter_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= NULL,
	.write		= shared_meter_write_proc
};

void init_shared_meter_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_shared_meter", 0, NULL, &shared_meter_fops);

	return;
}

static int reboot_switch_write_proc(struct file *file, const char *buffer,	
	unsigned long count, void *data)
{
	char val_string[128];
	int val;
	int ret = 0;

	
	if (count > sizeof(val_string) - 1)
		return -EINVAL;
	if (copy_from_user(val_string, buffer, count))
		return -EFAULT;

	if (sscanf(val_string, "%d", &val) != 1)
	{
		printk("usage: <action>\n");
		return count;
	}
	if (val)
	{
		if(RT_ERR_OK != rtk_port_phyEnableAll_set(DISABLED))
		{
			RTL8367_ERROR("disable switch error\r\n");
		}
		msleep(1);
		if(RT_ERR_OK != rtk_port_phyEnableAll_set(ENABLED))
		{
			RTL8367_ERROR("enbable switch error\r\n");
		}
	}

	return count;
}


static struct file_operations reboot_switch_fops = {
	.owner 		= THIS_MODULE,
	.read	 	= NULL,
	.write		= reboot_switch_write_proc
};

void init_reboot_switch_proc(void)
{
	struct proc_dir_entry *eth_proc;

	eth_proc = proc_create("tplink/eth_reboot_switch", 0, NULL, &reboot_switch_fops);

	return;
}

void rt_rtl8367_init()
{
	RTL8367_DEBUG("switch init Begin\n");
	u32 data;
	u32 counter = 0;
	rtk_api_ret_t ret;
	rtk_portmask_t portMask;


#ifdef CONFIG_X_TP_VLAN
	/* register vlan operation socket, add by wanghao  */
	init_raVlan_tplink();
	ret = nf_register_sockopt(&vlanOptSockopts);
	if (ret < 0) 
	{
		RTL8367_ERROR("Unable to register vlanOptSockopts.\n");
	}
#endif

#ifdef TP_AP_MODE
	ret = nf_register_sockopt(&phyOptSockopts);
	if (ret < 0) 
	{
		RTL8367_ERROR("Unable to register phyOptSockopts.\n");
	}
#endif


#if 1
	while(1)
	{
		rtl_smi_read(0x2002, &data);
		if (0x1c == data)
		{
			break;
		}
		else if (0x70 == data)
		{
			RTL8367_DEBUG("MT7620 SMI Init ERROR\n");
			return;
		}
		
		if (counter == 0)
		{
			printf("Wait for RTL8367C Ready\n");
		}
		else if (counter >= 100)
		{
			/* about 10s */
			printf("\nTimeout\n");
			return;
		}
		udelay (10000 * 10);
		printf(".");
		counter++;
	};
	printf("\nRTL8367C is ready now!\n");
#endif

	if ((ret = rtk_switch_init()) != RT_ERR_OK)
	{
		RTL8367_ERROR("init switch error: %x...\n", ret);
		return;
	}

#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
	printf("\n[RTL8367C] rt_rtl8367_enableSgmii()...\n");
    int port = EXT_PORT0;
    rtk_mode_ext_t mode = MODE_EXT_1000X;
    rtk_port_mac_ability_t portability;

    portability.forcemode = MAC_FORCE;
    portability.speed     = PORT_SPEED_1000M;
    portability.duplex    = PORT_FULL_DUPLEX;
    portability.link      = PORT_LINKUP;
    portability.nway      = DISABLED;
    portability.txpause   = ENABLED;
    portability.rxpause   = ENABLED;


    rt_rtl8367_enableSgmii(port, mode, &portability);
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */

	/*rtk_port_phyEnableAll_set(ENABLED);*/

	
	if(CHIP_RTL8367D == g_switch_chip)
	{
		/* RTL8367D_REG_EXT1_RGMXF */
		RT_MAPPER->smi_write(0x1307, 0xc);
	}
	else
	{
		/*RTL8367C_REG_EXT2_RGMXF*/
		RT_MAPPER->smi_write(0x13c5, 0xc);
	}
	
	rt_rtl8367_enableRgmii();

	if ((ret = rt_rtl8367_initVlan()) != RT_ERR_OK)
	{
		RTL8367_ERROR("init vlan error: 0x%08x...\n", ret);
		return;
	}

	if ((ret = setVlanRtl8367()) != RT_ERR_OK)
	{
		RTL8367_ERROR("set vlan 8367 error: 0x%08x...\n", ret);
		return;
	}

	if ((ret = setVlanInner()) != RT_ERR_OK)
	{
		RTL8367_ERROR("set vlan inner error: 0x%08x...\n", ret);
		return;
	}

	if(CHIP_RTL8367D != g_switch_chip)
	{
		if ((ret = rtk_igmp_init()) != RT_ERR_OK)
		{
			RTL8367_ERROR("igmp init error: 0x%08x...\n", ret);
			return;
		}
		rtk_igmp_state_set(DISABLED);
	}

	rtk_igmp_state_set(DISABLED);

#ifdef CONFIG_TPLINK_QOS_FOR_IPTV
	if ((ret = rt_rtl8367_initQoS()) != RT_ERR_OK)
	{
		RTL8367_ERROR("Qos init error: 0x%08x...\n", ret);
		return;
	}
#endif

	if ((ret = disableEthForward()) != RT_ERR_OK)
	{
		RTL8367_ERROR("disable switch forward error: 0x%08x...\n", ret);
		return;
	}

	if ((ret = resetPHY()) != RT_ERR_OK)
	{
		RTL8367_ERROR("reset PHY error: 0x%08x...\n", ret);
		return;
	}

	init_port_status_proc();
#if defined(CONFIG_TP_MODEL_EC220_G5sV1)
    //init_sgmii_status_proc();
    init_sgmii_speed_proc();
#endif /* CONFIG_TP_MODEL_EC220_G5sV1 */

	if(CHIP_RTL8367D != g_switch_chip)
	{
		init_igmp_snooping_proc();
	}
	
	init_mcast_table_proc();
	init_ucast_table_proc();
    init_eth_port_stat_proc();
	init_switch_reg_proc();
	init_shared_meter_proc();
	init_reboot_switch_proc();
}

